﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop
{
    internal class Settings
    {
        static string DefaultPath = @"C:\Users\MohammadMahdi\Desktop\BackEnd\CoffeeShop\";
        public static string PathFileStates = DefaultPath + @"Data\State\State.txt";
        public static string PathFileCategories = DefaultPath + @"Data\Categories\Categories.txt";
        public static string PathFileCountCategories = DefaultPath + @"Data\Counts\CategoryID.txt";
        public static string pathFileCustomerCode = DefaultPath + @"Data\Counts\CustomerID.txt";
        public static string pathFileProductID = DefaultPath + @"Data\Counts\ProductID.txt";
        public static string pathFileFactorID = DefaultPath + @"Data\Counts\FactorID.txt";
        public static string pathFileManegerAcount = DefaultPath + @"Data\Managment\ManagerAcount.txt";

        public static string pathFolderProductsImage = DefaultPath + @"Data\Picture\ProductImage";
        public static string pathFolderCategoriesImage = DefaultPath + @"Data\Picture\CategoryImage";
        public static string ImageFilename = string.Empty;

        public static string pathFileExampleJson = DefaultPath + @"Data\ExampleJson\json.txt";
    }
}
