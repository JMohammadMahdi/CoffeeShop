﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Products
{
    public partial class AddProductsPopup : Form
    {
        public AddProductsPopup()
        {
            InitializeComponent();
        }

        private void AddProductsPopup_Load(object sender, EventArgs e)
        {
            string[] CategoryReaded = File.ReadAllLines(Settings.PathFileCategories);
            foreach (var File in CategoryReaded)
                if (File != "")
                    P_Category.Items.Add(File);
        }

        private void SaveData_Click(object sender, EventArgs e)
        {
            string Price = P_Price.Text.Replace(",", "");
            AddProduct(P_Name.Text, P_Description.Text, Price, Settings.ImageFilename, (P_Category.SelectedIndex + 201).ToString());
        }
        private void AddProduct(string ProductName, string Description, string Price, string Image, string CategoryID)
        {
            int ProductID = Convert.ToInt32(File.ReadAllText(Settings.pathFileProductID)) + 1;

            string url = "http://localhost:5000/Add_Product";

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("ProductID", ProductID.ToString()));
            postData.Add(new KeyValuePair<string, string>("ProductName", ProductName));
            postData.Add(new KeyValuePair<string, string>("Description", Description));
            postData.Add(new KeyValuePair<string, string>("Price", Price));
            postData.Add(new KeyValuePair<string, string>("Image", Image));
            postData.Add(new KeyValuePair<string, string>("CategoryID", CategoryID));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                File.WriteAllText(Settings.pathFileProductID, ProductID.ToString());

                // remove text in text boxes:
                P_Name.Text = P_Category.Text = P_Description.Text = P_Price.Text = null;

                DialogResult dialogResult = MessageBox.Show(this, $"محصول مورد نظر با کد {ProductID} با موفقیت ایجاد شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.OK)
                {
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }

        private void P_Price_TextChanged(object sender, EventArgs e)
        {
            if (P_Price.Text != string.Empty)
            {
                P_Price.Text = string.Format("{0:N0}", double.Parse(P_Price.Text.Replace(",", "")));
                P_Price.Select(P_Price.TextLength, 0);
            }
        }
        private void UploadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = Settings.pathFolderProductsImage;
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                P_image.Image = Image.FromFile(openFileDialog.FileName);
                Settings.ImageFilename = openFileDialog.FileName;
            }
        }
        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
