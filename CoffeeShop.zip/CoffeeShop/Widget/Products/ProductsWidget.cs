﻿using CoffeeShop.Widget.Users;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Products
{
    public partial class ProductsWidget : UserControl
    {
        public ProductsWidget()
        {
            InitializeComponent();
        }

        DataTable Table = new DataTable();
        private void ProductsWidget_Load(object sender, EventArgs e)
        {
            AddDataToProductsTable();
        }
        private async void AddDataToProductsTable()
        {
            string Selecting_Products = "http://localhost:5000/GetProducts";

            Table.Columns.Add("کدمحصول", typeof(string));
            Table.Columns.Add("نام‌محصول", typeof(string));
            Table.Columns.Add("توضیحات", typeof(string));
            Table.Columns.Add("قیمت", typeof(string));
            Table.Columns.Add("آدرس تصویر", typeof(string));
            Table.Columns.Add("کددسته‌بندی", typeof(string));
            Table.Columns.Add("نام‌دسته‌بندی", typeof(string));

            Products_view.DataSource = Table;
            Products_view.Columns["آدرس تصویر"].Visible = false;
            Products_view.Columns["کددسته‌بندی"].Visible = false;

            Products_view.Columns["کدمحصول"].Width = 75;
            Products_view.Columns["نام‌محصول"].Width = 200;
            Products_view.Columns["قیمت"].Width = 75;

            Products_view.Columns["قیمت"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);


            HttpClient client = new HttpClient();

            // Get: 
            string Result = await client.GetStringAsync(Selecting_Products);

            List<ProductsClass> All_Products = JsonConvert.DeserializeObject<List<ProductsClass>>(Result);

            for (int i = 0; i < All_Products.Count; i++) {
                Table.Rows.Add(All_Products[i].ProductID, All_Products[i].ProductName, All_Products[i].Description, All_Products[i].Price, All_Products[i].Image, All_Products[i].CategoryID, All_Products[i].CategoryName);
            }
        }

        private void Users_view_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Products_view.ClearSelection(); // clear previous selections
                Products_view.Rows[e.RowIndex].Selected = true; // select the clicked row

                ContextMenuStrip recordMenu = new ContextMenuStrip();
                ToolStripMenuItem addItem = new ToolStripMenuItem("افزودن");
                ToolStripMenuItem editItem = new ToolStripMenuItem("ویرایش");
                ToolStripMenuItem deleteItem = new ToolStripMenuItem("حذف");

                addItem.Font = new Font("IRANSansXFaNum", 9);
                editItem.Font = new Font("IRANSansXFaNum", 9);
                deleteItem.Font = new Font("IRANSansXFaNum", 9);

                addItem.Click += new EventHandler(addItem_Click);
                editItem.Click += new EventHandler(editItem_Click);
                deleteItem.Click += new EventHandler(deleteItem_Click);

                recordMenu.Items.Add(editItem);
                recordMenu.Items.Add(deleteItem);
                recordMenu.Items.Add(addItem);

                recordMenu.Show(Cursor.Position);
            }
        }
        private void editItem_Click(object sender, EventArgs e)
        {
            if (Products_view.SelectedRows.Count == 1)
            {
                saveProducts.ProductID = Products_view.CurrentRow?.Cells[0]?.Value?.ToString() ?? "default value";
                saveProducts.ProductName = Products_view.CurrentRow?.Cells[1]?.Value?.ToString() ?? "default value";
                saveProducts.Description = Products_view.CurrentRow?.Cells[2]?.Value?.ToString() ?? "default value";
                saveProducts.Price = Products_view.CurrentRow?.Cells[3]?.Value?.ToString() ?? "default value";
                saveProducts.Image = Products_view.CurrentRow?.Cells[4]?.Value?.ToString() ?? "default value";
                saveProducts.CategoryID = Products_view.CurrentRow?.Cells[5]?.Value?.ToString() ?? "default value";
                saveProducts.CategoryName = Products_view.CurrentRow?.Cells[6]?.Value?.ToString() ?? "default value";

                EditProductsWidget editProductsWidget = new EditProductsWidget();
                editProductsWidget.Show();
            }
        }
        private void addItem_Click(object sender, EventArgs e)
        {
            AddProductsPopup addProductsPopupForm = new AddProductsPopup();
            addProductsPopupForm.Show();
        }
        private void deleteItem_Click(object sender, EventArgs e)
        {
            if (Products_view.SelectedRows.Count == 1)
            {
                string ProductID = Products_view.CurrentRow?.Cells[0]?.Value?.ToString() ?? "default value";

                DialogResult dialogResult = MessageBox.Show(this, $"آیا مایل به حذف کالای موردنظر با کد {ProductID} هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.Yes)
                {
                    string url = $"http://localhost:5000/DeleteProducts/{ProductID}";

                    HttpClient client = new HttpClient();
                    var response = client.DeleteAsync(url).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        // remove row in table:
                        int rowIndex = Products_view.SelectedRows[0].Index;
                        Products_view.Rows.RemoveAt(rowIndex);

                        string textWarning = "عملیات با موفقیت انجام شد" + Environment.NewLine + $"دقت داشته باشید کد محصول {ProductID} قابل استفاده نیست";
                        MessageBox.Show(this, textWarning, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    } else {
                        MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                }
            }
        }
        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("table", "products"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));
            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<ProductsClass> All_Products = JsonConvert.DeserializeObject<List<ProductsClass>>(Result);

            Table.Clear();
            for (int i = 0; i < All_Products.Count; i++) {
                Table.Rows.Add(All_Products[i].ProductID, All_Products[i].ProductName, All_Products[i].Description, All_Products[i].Price, All_Products[i].Image, All_Products[i].CategoryID, All_Products[i].CategoryName);
            }
        }
        private void SearchInTable_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search.PerformClick();
            }
        }

        private void Products_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Products_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        private void Products_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Products_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
