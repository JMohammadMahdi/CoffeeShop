﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Products
{
    public partial class EditProductsWidget : Form
    {
        public EditProductsWidget()
        {
            InitializeComponent();
        }

        private void EditProductsWidget_Load(object sender, EventArgs e)
        {
            string[] stateReaded = File.ReadAllLines(Settings.PathFileCategories);
            foreach (var File in stateReaded)
                if (File != "")
                    P_Category.Items.Add(File);


            P_ID.Text = saveProducts.ProductID;
            P_Name.Text = saveProducts.ProductName;
            P_Description.Text = saveProducts.Description;
            P_Price.Text = saveProducts.Price;
            P_image.Image = (saveProducts.Image != "") ? P_image.Image = Image.FromFile(saveProducts.Image) : null;
            P_Category.SelectedIndex = P_Category.FindStringExact(saveProducts.CategoryName);
        }

        private void P_Price_TextChanged(object sender, EventArgs e)
        {
            if (P_Price.Text != string.Empty)
            {
                P_Price.Text = string.Format("{0:N0}", double.Parse(P_Price.Text.Replace(",", "")));
                P_Price.Select(P_Price.TextLength, 0);
            }
        }

        private void SaveData_Click(object sender, EventArgs e)
        {
            String price = P_Price.Text.Replace(",", "");
            UpdateProdct(P_ID.Text, P_Name.Text, P_Description.Text, price, Settings.ImageFilename, (P_Category.SelectedIndex + 201).ToString());
        }
        private void UpdateProdct(string ProductID, string ProductName, string Description, string Price, string Image, string CategoryID)
        {
            string url = "http://localhost:5000/UpdateProducts";

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("ProductID", ProductID));
            postData.Add(new KeyValuePair<string, string>("ProductName", ProductName));
            postData.Add(new KeyValuePair<string, string>("Description", Description));
            postData.Add(new KeyValuePair<string, string>("Price", Price));
            postData.Add(new KeyValuePair<string, string>("Image", Image));
            postData.Add(new KeyValuePair<string, string>("CategoryID", CategoryID));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PutAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                // remove text in text boxes:
                P_ID.Text = P_Name.Text = P_Category.Text = P_Description.Text = P_Price.Text = null;
                
                DialogResult dialogResult = MessageBox.Show(this, "اطلاعات محصول با موفقیت ویرایش شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.OK)
                {
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void UploadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = Settings.pathFolderProductsImage;
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                P_image.Image = Image.FromFile(openFileDialog.FileName);
                Settings.ImageFilename = openFileDialog.FileName;
            }
        }
    }
}
