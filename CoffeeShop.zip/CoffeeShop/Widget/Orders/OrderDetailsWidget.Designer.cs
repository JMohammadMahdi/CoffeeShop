﻿namespace CoffeeShop.Widget.Orders
{
    partial class OrderDetailsWidget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderDetailsWidget));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.DateFactor = new System.Windows.Forms.Label();
            this.CustomerName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.FactorID = new System.Windows.Forms.Label();
            this.FirstnameGuide = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TotalFactor = new System.Windows.Forms.Label();
            this.ClosePage = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.OrderDetails_view = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderDetails_view)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.DateFactor);
            this.panel1.Controls.Add(this.CustomerName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.FactorID);
            this.panel1.Controls.Add(this.FirstnameGuide);
            this.panel1.Location = new System.Drawing.Point(12, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(856, 79);
            this.panel1.TabIndex = 93;
            // 
            // DateFactor
            // 
            this.DateFactor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DateFactor.AutoSize = true;
            this.DateFactor.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DateFactor.Location = new System.Drawing.Point(29, 11);
            this.DateFactor.Name = "DateFactor";
            this.DateFactor.Size = new System.Drawing.Size(87, 24);
            this.DateFactor.TabIndex = 100;
            this.DateFactor.Text = "1401/12/25";
            this.DateFactor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CustomerName
            // 
            this.CustomerName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomerName.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CustomerName.Location = new System.Drawing.Point(487, 42);
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.Size = new System.Drawing.Size(250, 22);
            this.CustomerName.TabIndex = 98;
            this.CustomerName.Text = "محمد مهدی جلالی";
            this.CustomerName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(743, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 22);
            this.label3.TabIndex = 97;
            this.label3.Text = "اطلاعات حساب";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FactorID
            // 
            this.FactorID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FactorID.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FactorID.Location = new System.Drawing.Point(487, 12);
            this.FactorID.Name = "FactorID";
            this.FactorID.Size = new System.Drawing.Size(250, 22);
            this.FactorID.TabIndex = 96;
            this.FactorID.Text = "1015";
            this.FactorID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FirstnameGuide
            // 
            this.FirstnameGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FirstnameGuide.AutoSize = true;
            this.FirstnameGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FirstnameGuide.Location = new System.Drawing.Point(743, 12);
            this.FirstnameGuide.Name = "FirstnameGuide";
            this.FirstnameGuide.Size = new System.Drawing.Size(85, 22);
            this.FirstnameGuide.TabIndex = 95;
            this.FirstnameGuide.Text = "شماره فاکتور";
            this.FirstnameGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 433);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 22);
            this.label1.TabIndex = 101;
            this.label1.Text = "مبلغ قابل پرداخت:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalFactor
            // 
            this.TotalFactor.AutoSize = true;
            this.TotalFactor.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalFactor.Location = new System.Drawing.Point(134, 432);
            this.TotalFactor.Name = "TotalFactor";
            this.TotalFactor.Size = new System.Drawing.Size(79, 24);
            this.TotalFactor.TabIndex = 101;
            this.TotalFactor.Text = "2,570,000";
            this.TotalFactor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ClosePage
            // 
            this.ClosePage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ClosePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClosePage.Image = ((System.Drawing.Image)(resources.GetObject("ClosePage.Image")));
            this.ClosePage.Location = new System.Drawing.Point(836, 12);
            this.ClosePage.Name = "ClosePage";
            this.ClosePage.Size = new System.Drawing.Size(32, 32);
            this.ClosePage.TabIndex = 102;
            this.ClosePage.TabStop = false;
            this.ClosePage.Click += new System.EventHandler(this.ClosePage_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(880, 480);
            this.panel2.TabIndex = 103;
            // 
            // OrderDetails_view
            // 
            this.OrderDetails_view.AllowUserToAddRows = false;
            this.OrderDetails_view.AllowUserToDeleteRows = false;
            this.OrderDetails_view.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.OrderDetails_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.OrderDetails_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.OrderDetails_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.OrderDetails_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.OrderDetails_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OrderDetails_view.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OrderDetails_view.DefaultCellStyle = dataGridViewCellStyle2;
            this.OrderDetails_view.Location = new System.Drawing.Point(12, 148);
            this.OrderDetails_view.Name = "OrderDetails_view";
            this.OrderDetails_view.ReadOnly = true;
            this.OrderDetails_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.OrderDetails_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.OrderDetails_view.RowTemplate.Height = 25;
            this.OrderDetails_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.OrderDetails_view.Size = new System.Drawing.Size(856, 264);
            this.OrderDetails_view.TabIndex = 104;
            this.OrderDetails_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.OrderDetails_view_RowPostPaint);
            this.OrderDetails_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.OrderDetails_view_RowPrePaint);
            // 
            // OrderDetailsWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(880, 480);
            this.Controls.Add(this.OrderDetails_view);
            this.Controls.Add(this.ClosePage);
            this.Controls.Add(this.TotalFactor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OrderDetailsWidget";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OrderDetailsWidget";
            this.Load += new System.EventHandler(this.OrderDetailsWidget_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderDetails_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Panel panel1;
        private Label FirstnameGuide;
        private Label FactorID;
        private Label CustomerName;
        private Label label3;
        private Label DateFactor;
        private Label label1;
        private Label TotalFactor;
        private PictureBox ClosePage;
        private Panel panel2;
        private DataGridView OrderDetails_view;
    }
}