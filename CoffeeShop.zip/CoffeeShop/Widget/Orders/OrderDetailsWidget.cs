﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Orders
{
    public partial class OrderDetailsWidget : Form
    {
        public OrderDetailsWidget()
        {
            InitializeComponent();
        }
        DataTable Table = new DataTable();

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void OrderDetailsWidget_Load(object sender, EventArgs e)
        {
            Table.Columns.Add("کد‌محصول", typeof(string));
            Table.Columns.Add("نام‌محصول", typeof(string));
            Table.Columns.Add("تعداد", typeof(string));
            Table.Columns.Add("مبلغ‌فی", typeof(string));
            Table.Columns.Add("تخفیف", typeof(string));
            Table.Columns.Add("مبلغ‌کل", typeof(string));
            Table.Columns.Add("توضیحات", typeof(string));

            OrderDetails_view.DataSource = Table;

            OrderDetails_view.Columns["نام‌محصول"].Width = 200;
            OrderDetails_view.Columns["تعداد"].Width = 50;
            OrderDetails_view.Columns["مبلغ‌فی"].Width = 100;


            AddDataToProductsTable();

            DateFactor.Text = FactorClass.OrderDate;
            FactorID.Text = FactorClass.OrderID;
            CustomerName.Text = FactorClass.CustomerOrder;
            TotalFactor.Text = SeparateDigits(FactorClass.TotalFac) + " تومان";
        }
        private async void AddDataToProductsTable()
        {
            string SearchURL = "http://localhost:5000/GetOrderDetails";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("OrderID", FactorClass.OrderID));
            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            // convert to JSON:
            List<OrderDetailsClass> ResultObject = JsonConvert.DeserializeObject<List<OrderDetailsClass>>(Result);

            Table.Clear();
            for (int i = 0; i < ResultObject.Count; i++) {
                Table.Rows.Add(ResultObject[i].ProductID, ResultObject[i].ProductName, ResultObject[i].Quantity, ResultObject[i].ItemPrice, ResultObject[i].ItemDiscount, ResultObject[i].ItemTotal, ResultObject[i].ItemNotes);
            }
        }
        public string SeparateDigits(string numberStr)
        {
            // Reverse the string so we can work from right to left
            char[] reversedChars = numberStr.Reverse().ToArray();

            // Create a list to store the groups of three digits
            List<string> groupsOfThree = new List<string>();

            // Iterate over the reversed characters, adding them to the current group of three
            string currentGroup = "";
            for (int i = 0; i < reversedChars.Length; i++)
            {
                currentGroup = reversedChars[i] + currentGroup;
                if ((i + 1) % 3 == 0)
                {
                    groupsOfThree.Add(currentGroup);
                    currentGroup = "";
                }
            }

            // If there are any remaining characters, add them to a final group
            if (currentGroup.Length > 0)
            {
                groupsOfThree.Add(currentGroup);
            }

            // Reverse the groups and join them with commas
            groupsOfThree.Reverse();
            return string.Join(",", groupsOfThree);
        }

        private void OrderDetails_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(OrderDetails_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }

        private void OrderDetails_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            OrderDetails_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }
    }
}
