﻿namespace CoffeeShop.Widget.Orders
{
    partial class GetCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Users_view = new System.Windows.Forms.DataGridView();
            this.SelectRowData = new System.Windows.Forms.Button();
            this.ClosePage = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Search = new System.Windows.Forms.Button();
            this.SearchInTable = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Users_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).BeginInit();
            this.SuspendLayout();
            // 
            // Users_view
            // 
            this.Users_view.AllowUserToAddRows = false;
            this.Users_view.AllowUserToDeleteRows = false;
            this.Users_view.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Users_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Users_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Users_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Users_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.Users_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Users_view.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Users_view.DefaultCellStyle = dataGridViewCellStyle5;
            this.Users_view.Location = new System.Drawing.Point(12, 50);
            this.Users_view.Name = "Users_view";
            this.Users_view.ReadOnly = true;
            this.Users_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Users_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Users_view.RowTemplate.Height = 25;
            this.Users_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Users_view.Size = new System.Drawing.Size(361, 209);
            this.Users_view.TabIndex = 107;
            this.Users_view.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Users_view_CellDoubleClick);
            this.Users_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Users_view_RowPostPaint);
            // 
            // SelectRowData
            // 
            this.SelectRowData.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.SelectRowData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SelectRowData.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.SelectRowData.FlatAppearance.BorderSize = 0;
            this.SelectRowData.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectRowData.Font = new System.Drawing.Font("IRANSansXFaNum", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SelectRowData.ForeColor = System.Drawing.Color.White;
            this.SelectRowData.Location = new System.Drawing.Point(135, 265);
            this.SelectRowData.Name = "SelectRowData";
            this.SelectRowData.Size = new System.Drawing.Size(115, 32);
            this.SelectRowData.TabIndex = 110;
            this.SelectRowData.Text = "انتخاب";
            this.SelectRowData.UseVisualStyleBackColor = false;
            this.SelectRowData.Click += new System.EventHandler(this.SelectRowData_Click);
            // 
            // ClosePage
            // 
            this.ClosePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClosePage.Image = global::CoffeeShop.Properties.Resources.close;
            this.ClosePage.Location = new System.Drawing.Point(341, 12);
            this.ClosePage.Name = "ClosePage";
            this.ClosePage.Size = new System.Drawing.Size(32, 32);
            this.ClosePage.TabIndex = 111;
            this.ClosePage.TabStop = false;
            this.ClosePage.Click += new System.EventHandler(this.ClosePage_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(385, 300);
            this.label1.TabIndex = 112;
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Window;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Image = global::CoffeeShop.Properties.Resources.search;
            this.Search.Location = new System.Drawing.Point(18, 15);
            this.Search.Margin = new System.Windows.Forms.Padding(0);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(25, 25);
            this.Search.TabIndex = 114;
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // SearchInTable
            // 
            this.SearchInTable.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SearchInTable.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SearchInTable.Location = new System.Drawing.Point(12, 13);
            this.SearchInTable.Multiline = true;
            this.SearchInTable.Name = "SearchInTable";
            this.SearchInTable.PlaceholderText = "  کاربر مورد نظر را جست و جو کنید";
            this.SearchInTable.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.SearchInTable.Size = new System.Drawing.Size(265, 30);
            this.SearchInTable.TabIndex = 113;
            // 
            // GetCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 300);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.SearchInTable);
            this.Controls.Add(this.ClosePage);
            this.Controls.Add(this.SelectRowData);
            this.Controls.Add(this.Users_view);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GetCustomer";
            this.Text = "GetCustomer";
            this.Load += new System.EventHandler(this.GetCustomer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Users_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView Users_view;
        private Button SelectRowData;
        private PictureBox ClosePage;
        private Label label1;
        private Button Search;
        private TextBox SearchInTable;
    }
}