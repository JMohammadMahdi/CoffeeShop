﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Orders
{
    public partial class EditOrderWidget : Form
    {
        public EditOrderWidget()
        {
            InitializeComponent();
        }

        DataTable Products = new DataTable();
        DataTable OrderDetails = new DataTable();
        DataTable Table = new DataTable();
        private void EditOrderWidget_Load(object sender, EventArgs e)
        {
            GetCustomerData();
            GetOrderDetail();
            GetProducts();

            UpdateTotalAmount();
        }
        public static string GetPersianDate(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            int year = pc.GetYear(date);
            int month = pc.GetMonth(date);
            int day = pc.GetDayOfMonth(date);
            string persianDate = $"{year:0000}/{month:00}/{day:00}";

            return persianDate;
        }
        private async void GetCustomerData()
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("table", "users"));
            postData.Add(new KeyValuePair<string, string>("textSearch", FactorClass.CustomerID));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<CustomersClass> ResultObject = JsonConvert.DeserializeObject<List<CustomersClass>>(Result);

            CustomerID.Text = ResultObject[0].CustomerID.ToString();
            CustomerFName.Text = $"{ResultObject[0].FirstName} {ResultObject[0].LastName}";
            CustomerAddress.Text = ResultObject[0].Address;
            CustomerPhone.Text = ResultObject[0].PhoneNumber;
            FactorID.Text = FactorClass.OrderID;
        }
        private async void GetProducts()
        {
            string url = "http://localhost:5000/GetProducts";

            Products.Columns.Add("کدمحصول", typeof(string));
            Products.Columns.Add("نام‌محصول", typeof(string));
            Products.Columns.Add("توضیحات", typeof(string));
            Products.Columns.Add("قیمت", typeof(string));
            Products.Columns.Add("آدرس تصویر", typeof(string));
            Products.Columns.Add("کددسته‌بندی", typeof(string));
            Products.Columns.Add("نام‌دسته‌بندی", typeof(string));

            Products_view.DataSource = Products;
            Products_view.Columns["آدرس تصویر"].Visible = false;
            Products_view.Columns["کددسته‌بندی"].Visible = false;
            Products_view.Columns["توضیحات"].Visible = false;

            Products_view.Columns["کدمحصول"].Width = 50;
            Products_view.Columns["قیمت"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);

            // request:
            HttpClient client = new HttpClient();

            // Get: 
            string Result = await client.GetStringAsync(url);

            List<ProductsClass> All_Products = JsonConvert.DeserializeObject<List<ProductsClass>>(Result);

            for (int i = 0; i < All_Products.Count; i++) {
                Products.Rows.Add(All_Products[i].ProductID, All_Products[i].ProductName, All_Products[i].Description, All_Products[i].Price, All_Products[i].Image, All_Products[i].CategoryID, All_Products[i].CategoryName);
            }
        }
        private async void GetOrderDetail()
        {
            string SearchURL = "http://localhost:5000/GetOrderDetails";

            OrderDetails.Columns.Add("کدمحصول", typeof(string));
            OrderDetails.Columns.Add("نام‌محصول", typeof(string));
            OrderDetails.Columns.Add("تعداد", typeof(string));
            OrderDetails.Columns.Add("قیمت", typeof(string));
            OrderDetails.Columns.Add("مبلغ‌کل", typeof(string));

            Cart_view.DataSource = OrderDetails;
            Cart_view.Columns["کدمحصول"].Visible = false;
            Cart_view.Columns["تعداد"].Width = 85;

            Cart_view.Columns["قیمت"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);
            Cart_view.Columns["مبلغ‌کل"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);

            // request:
            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("OrderID", FactorClass.OrderID));
            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            // convert to JSON:
            List<OrderDetailsClass> ResultObject = JsonConvert.DeserializeObject<List<OrderDetailsClass>>(Result);

            OrderDetails.Clear();
            for (int i = 0; i < ResultObject.Count; i++) {
                OrderDetails.Rows.Add(ResultObject[i].ProductID, ResultObject[i].ProductName, ResultObject[i].Quantity, ResultObject[i].ItemPrice, ResultObject[i].ItemTotal);
            }

            if (Cart_view.Rows.Count > 0) {
                SendData.Enabled = true;
            }
        }
        private void Products_view_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // دریافت سطر انتخاب شده در جدول محصولات
            DataGridViewRow selectedRow = Products_view.Rows[e.RowIndex];

            // چک کردن مقدار سلول "نام‌محصول" انتخاب شده که خالی نباشد
            if (selectedRow.Cells["نام‌محصول"].Value != null)
            {
                string productName = selectedRow.Cells["نام‌محصول"].Value.ToString();
                decimal productPrice = Convert.ToDecimal(selectedRow.Cells["قیمت"].Value);

                // بررسی کردن اینکه آیا محصول قبلاً به سبد خرید اضافه شده است یا خیر
                DataRow[] existingProductRows = OrderDetails.Select("نام‌محصول = '" + productName + "'");
                if (existingProductRows.Length > 0)
                {
                    // اگر محصول قبلاً به سبد خرید اضافه شده است، تعداد آن را یکی افزایش دهید و مبلغ کل را با توجه به تعداد جدید محاسبه کنید
                    int newQuantity = Convert.ToInt32(existingProductRows[0]["تعداد"]) + 1;
                    decimal newTotalPrice = productPrice * newQuantity;
                    existingProductRows[0]["تعداد"] = newQuantity;
                    existingProductRows[0]["مبلغ‌کل"] = newTotalPrice.ToString();
                }
                else
                {
                    // اگر محصول قبلاً به سبد خرید اضافه نشده است، به جدول OrderDetails اضافه شود
                    DataRow newRow = OrderDetails.NewRow();
                    newRow["کدمحصول"] = selectedRow.Cells["کدمحصول"].Value.ToString(); // افزودن کد محصول به جدول سبد خرید
                    newRow["نام‌محصول"] = productName;
                    newRow["تعداد"] = 1;
                    newRow["قیمت"] = productPrice.ToString();
                    newRow["مبلغ‌کل"] = productPrice.ToString();
                    OrderDetails.Rows.Add(newRow);
                }
                if (OrderDetails.Rows.Count > 0)
                {
                    // size & location:
                    Products_view.Width = 622;
                    Products_view.Location = new Point(341, 34);
                    SendData.Location = new Point(548, 422);
                    SendData.Enabled = true;
                    //show tables:
                    Cart_viewGuide.Visible = true;
                    Cart_view.Visible = true;
                    RemoveCount.Visible = true;

                    Products_view.AutoResizeColumn(0, DataGridViewAutoSizeColumnMode.AllCells);
                }
            }
            UpdateTotalAmount();
        }
        private void RemoveCount_Click(object sender, EventArgs e)
        {
            // دریافت ردیف انتخاب شده از جدول Cart_view
            int rowIndex = Cart_view.SelectedRows[0].Index;

            // دریافت مقدار تعداد محصول مورد نظر از ستون "تعداد"
            int quantity = Convert.ToInt32(Cart_view.Rows[rowIndex].Cells["تعداد"].Value);

            // کاهش مقدار تعداد محصول مورد نظر
            quantity--;

            // اگر تعداد محصول برابر با صفر شد، ردیف مورد نظر را از جدول حذف می‌کنیم
            if (quantity == 0)
            {
                Cart_view.Rows.RemoveAt(rowIndex);
            }
            // در غیر این صورت، مقدار تعداد را در جدول به روزرسانی می‌کنیم و مبلغ کل را مجدداً محاسبه کرده و در جدول قرار می‌دهیم
            else
            {
                Cart_view.Rows[rowIndex].Cells["تعداد"].Value = quantity;

                // دریافت مقدار قیمت محصول از ستون "قیمت"
                int price = Convert.ToInt32(Cart_view.Rows[rowIndex].Cells["قیمت"].Value);

                // محاسبه مبلغ کل با توجه به تعداد محصول
                int totalPrice = price * quantity;

                // قرار دادن مبلغ کل در ستون "مبلغ"
                Cart_view.Rows[rowIndex].Cells["مبلغ‌کل"].Value = totalPrice.ToString();
            }

            if (OrderDetails.Rows.Count == 0)
            {
                // size & location:
                Products_view.Width = 963;
                Products_view.Location = new Point(0, 34);
                SendData.Location = new Point(407, 422);
                SendData.Enabled = false;

                //show tables:
                Cart_viewGuide.Visible = false;
                Cart_view.Visible = false;
                RemoveCount.Visible = false;
            }
            UpdateTotalAmount();
        }

        private void RemoveCount_DoubleClick(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(this, "آیا مایل به خالی کردن سبدخرید خود هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            if (dialogResult == DialogResult.Yes)
            {
                OrderDetails.Rows.Clear();

                // size & location:
                Products_view.Width = 963;
                Products_view.Location = new Point(0, 34);
                SendData.Location = new Point(407, 422);
                SendData.Enabled = false;

                //show tables:
                Cart_viewGuide.Visible = false;
                Cart_view.Visible = false;
                RemoveCount.Visible = false;
            }
            UpdateTotalAmount();
        }

        private void TotalAmount_TextChanged(object sender, EventArgs e)
        {
            if (TotalAmount.Text != string.Empty)
            {
                TotalAmount.Text = string.Format("{0:N0}", double.Parse(TotalAmount.Text.Replace(",", "")));
                TotalAmount.Select(TotalAmount.TextLength, 0);
            }
        }
        private void UpdateTotalAmount()
        {
            int totalAmount = 0;
            foreach (DataGridViewRow row in Cart_view.Rows)
            {
                if (row.Cells["مبلغ‌کل"].Value != null && int.TryParse(row.Cells["مبلغ‌کل"].Value.ToString(), out int price))
                {
                    totalAmount += price;
                }
            }
            TotalAmount.Text = totalAmount.ToString();
        }
        private void SendData_Click(object sender, EventArgs e)
        {
            if (CustomerID.Text != "" && CustomerFName.Text != "") {
                int orderID = Convert.ToInt32(FactorClass.OrderID);
                PutOrder(orderID);
            }
            else {
                MessageBox.Show(this, "لطفاً مشخص کنید که فاکتور به‌نام کدام مشتری ثبت شود!", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }
        private void PutOrder(int orderID)
        {
            string url = "http://localhost:5000/UpdateOrders";
            string Total = TotalAmount.Text.Replace(",", "");

            List<RowData> rowsData = new List<RowData>();
            foreach (DataGridViewRow row in Cart_view.Rows)
            {
                rowsData.Add(new RowData
                {
                    ID = row.Cells["کدمحصول"]?.Value?.ToString() ?? "default value",
                    Name = row.Cells["نام‌محصول"]?.Value?.ToString() ?? "default value",
                    Count = row.Cells["تعداد"]?.Value?.ToString() ?? "default value",
                    Price = row.Cells["قیمت"]?.Value?.ToString() ?? "default value",
                    TotalAmount = row.Cells["مبلغ‌کل"]?.Value?.ToString() ?? "default value"
                });
            }

            string Json = JsonConvert.SerializeObject(rowsData);

            var OrderData = new List<KeyValuePair<string, string>>();
            OrderData.Add(new KeyValuePair<string, string>("Cart", Json));
            OrderData.Add(new KeyValuePair<string, string>("OrderID", orderID.ToString()));
            OrderData.Add(new KeyValuePair<string, string>("CustomerID", CustomerID.Text));
            OrderData.Add(new KeyValuePair<string, string>("TotalAmount", Total));

            HttpClient client = new HttpClient();
            HttpContent Requestcontent = new FormUrlEncodedContent(OrderData);
            var Order_response = client.PutAsync(url, Requestcontent).Result;

            if (Order_response.IsSuccessStatusCode)
            {
                MessageBox.Show(this, ".تغییرات با موفقیت ثبت شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                this.Hide();
            }
        }
        private void Products_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Products_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
        private void Cart_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Cart_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
        private void showCustomerList_Click(object sender, EventArgs e)
        {
            if (!SetCustomerPanel.Visible) {
                SetCustomerPanel.Visible = true;
                AddDataToCustomersTable();
            }
        }

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void Cart_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Cart_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }
        private void Products_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Products_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        // CustoemerList:
        private void CloseList_Click(object sender, EventArgs e)
        {
            SetCustomerPanel.Visible = false;
        }
        bool IsNotAddColumns = false;
        private async void AddDataToCustomersTable()
        {
            string Selectin_Customers = "http://localhost:5000/GetCustomers";

            if (!IsNotAddColumns)
            {
                Table.Columns.Add("کد‌کابری", typeof(string));
                Table.Columns.Add("نام و نام خانوادگی", typeof(string));
                Table.Columns.Add("ایمیل", typeof(string));
                Table.Columns.Add("تلفن", typeof(string));
                Table.Columns.Add("آدرس", typeof(string));
                Table.Columns.Add("استان", typeof(string));
                Table.Columns.Add("کشور", typeof(string));
                Table.Columns.Add("کدپستی", typeof(string));
                Table.Columns.Add("رمزعبور", typeof(string));

                Users_view.DataSource = Table;
                Users_view.Columns["ایمیل"].Visible = Users_view.Columns["تلفن"].Visible = Users_view.Columns["آدرس"].Visible = Users_view.Columns["استان"].Visible = Users_view.Columns["کشور"].Visible = Users_view.Columns["کدپستی"].Visible = Users_view.Columns["رمزعبور"].Visible = false;
                Users_view.Columns["کد‌کابری"].Width = 75;

                IsNotAddColumns = true;
            }

            HttpClient client = new HttpClient();

            // Get: 
            string BestSaleProductBYNumber = await client.GetStringAsync(Selectin_Customers);

            List<CustomersClass> All_Customers = JsonConvert.DeserializeObject<List<CustomersClass>>(BestSaleProductBYNumber);

            Table.Clear();
            for (int i = 0; i < All_Customers.Count; i++) {
                Table.Rows.Add(All_Customers[i].CustomerID, $"{All_Customers[i].FirstName} {All_Customers[i].LastName}", All_Customers[i].Email, All_Customers[i].PhoneNumber, All_Customers[i].Address, All_Customers[i].City, All_Customers[i].State, All_Customers[i].PostalCode, All_Customers[i].Password);
            }
        }

        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("table", "users"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<CustomersClass> ResultObject = JsonConvert.DeserializeObject<List<CustomersClass>>(Result);

            Table.Clear();
            for (int i = 0; i < ResultObject.Count; i++) {
                Table.Rows.Add(ResultObject[i].CustomerID, $"{ResultObject[i].FirstName} {ResultObject[i].LastName}", ResultObject[i].Email, ResultObject[i].PhoneNumber, ResultObject[i].Address, ResultObject[i].City, ResultObject[i].State, ResultObject[i].PostalCode, ResultObject[i].Password);
            }
        }

        private void SelectRowData_Click(object sender, EventArgs e)
        {
            CustomerID.Text = Users_view.CurrentRow?.Cells["کد‌کابری"]?.Value?.ToString() ?? "default value";
            CustomerFName.Text = Users_view.CurrentRow?.Cells["نام و نام خانوادگی"]?.Value?.ToString() ?? "default value";
            CustomerPhone.Text = Users_view.CurrentRow?.Cells["تلفن"]?.Value?.ToString() ?? "default value";
            CustomerAddress.Text = Users_view.CurrentRow?.Cells["آدرس"]?.Value?.ToString() ?? "default value";

            SetCustomerPanel.Visible = false;
        }

        private void Users_view_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            SelectRowData.PerformClick();
        }
    }
}
