﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Orders
{
    public partial class GetCustomer : Form
    {
        public GetCustomer()
        {
            InitializeComponent();
        }

        DataTable Table = new DataTable();
        private void GetCustomer_Load(object sender, EventArgs e)
        {
            AddDataToCustomersTable();
        }
        private async void AddDataToCustomersTable()
        {
            string Selectin_Customers = "http://localhost:5000/GetCustomers";

            Table.Columns.Add("کد‌کابری", typeof(string));
            Table.Columns.Add("نام و نام خانوادگی", typeof(string));
            Table.Columns.Add("ایمیل", typeof(string));
            Table.Columns.Add("تلفن", typeof(string));
            Table.Columns.Add("آدرس", typeof(string));
            Table.Columns.Add("استان", typeof(string));
            Table.Columns.Add("کشور", typeof(string));
            Table.Columns.Add("کدپستی", typeof(string));
            Table.Columns.Add("رمزعبور", typeof(string));

            Users_view.DataSource = Table;
            Users_view.Columns["ایمیل"].Visible = Users_view.Columns["تلفن"].Visible = Users_view.Columns["آدرس"].Visible = Users_view.Columns["استان"].Visible = Users_view.Columns["کشور"].Visible = Users_view.Columns["کدپستی"].Visible = Users_view.Columns["رمزعبور"].Visible = false;
            Users_view.Columns["کد‌کابری"].Width = 75;

            HttpClient client = new HttpClient();

            // Get: 
            string BestSaleProductBYNumber = await client.GetStringAsync(Selectin_Customers);

            List<CustomersClass> All_Customers = JsonConvert.DeserializeObject<List<CustomersClass>>(BestSaleProductBYNumber);

            for (int i = 0; i < All_Customers.Count; i++) {
                Table.Rows.Add(All_Customers[i].CustomerID, $"{All_Customers[i].FirstName} {All_Customers[i].LastName}", All_Customers[i].Email, All_Customers[i].PhoneNumber, All_Customers[i].Address, All_Customers[i].City, All_Customers[i].State, All_Customers[i].PostalCode, All_Customers[i].Password);
            }
        }
        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("table", "users"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<CustomersClass> ResultObject = JsonConvert.DeserializeObject<List<CustomersClass>>(Result);

            Table.Clear();
            for (int i = 0; i < ResultObject.Count; i++) {
                Table.Rows.Add(ResultObject[i].CustomerID, $"{ResultObject[i].FirstName} {ResultObject[i].LastName}", ResultObject[i].Email, ResultObject[i].PhoneNumber, ResultObject[i].Address, ResultObject[i].City, ResultObject[i].State, ResultObject[i].PostalCode, ResultObject[i].Password);
            }
        }
        private void SelectRowData_Click(object sender, EventArgs e)
        {
            saveCustomer.CustomerID = Users_view.CurrentRow?.Cells["کد‌کابری"]?.Value?.ToString() ?? "default value";
            saveCustomer.FullName = Users_view.CurrentRow?.Cells["نام و نام خانوادگی"]?.Value?.ToString() ?? "default value";
            saveCustomer.Phone = Users_view.CurrentRow?.Cells["تلفن"]?.Value?.ToString() ?? "default value";
            saveCustomer.Address = Users_view.CurrentRow?.Cells["آدرس"]?.Value?.ToString() ?? "default value";
            this.Hide();
        }

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Users_view_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectRowData.PerformClick();
        }

        private void Users_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Users_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
