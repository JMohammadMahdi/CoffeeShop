﻿namespace CoffeeShop.Widget
{
    partial class OrdersWidget
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Search = new System.Windows.Forms.Button();
            this.SearchInTable = new System.Windows.Forms.TextBox();
            this.Orders_view = new System.Windows.Forms.DataGridView();
            this.awaitingConfirmation = new System.Windows.Forms.TabControl();
            this.none1 = new System.Windows.Forms.TabPage();
            this.Waiting = new System.Windows.Forms.TabPage();
            this.awaitingOrders_view = new System.Windows.Forms.DataGridView();
            this.Orders_viewGuide = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Orders_view)).BeginInit();
            this.awaitingConfirmation.SuspendLayout();
            this.none1.SuspendLayout();
            this.Waiting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.awaitingOrders_view)).BeginInit();
            this.SuspendLayout();
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Window;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Image = global::CoffeeShop.Properties.Resources.search;
            this.Search.Location = new System.Drawing.Point(250, 28);
            this.Search.Margin = new System.Windows.Forms.Padding(0);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(25, 25);
            this.Search.TabIndex = 93;
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            this.Search.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Search_KeyDown);
            // 
            // SearchInTable
            // 
            this.SearchInTable.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SearchInTable.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SearchInTable.Location = new System.Drawing.Point(244, 26);
            this.SearchInTable.Multiline = true;
            this.SearchInTable.Name = "SearchInTable";
            this.SearchInTable.PlaceholderText = "  فاکتور مورد نظر را جست و جو کنید";
            this.SearchInTable.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.SearchInTable.Size = new System.Drawing.Size(451, 30);
            this.SearchInTable.TabIndex = 92;
            this.SearchInTable.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SearchInTable_KeyDown);
            // 
            // Orders_view
            // 
            this.Orders_view.AllowUserToAddRows = false;
            this.Orders_view.AllowUserToDeleteRows = false;
            this.Orders_view.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Orders_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Orders_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Orders_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Orders_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Orders_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Orders_view.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Orders_view.Location = new System.Drawing.Point(6, 6);
            this.Orders_view.Name = "Orders_view";
            this.Orders_view.ReadOnly = true;
            this.Orders_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Orders_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Orders_view.RowTemplate.Height = 25;
            this.Orders_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Orders_view.Size = new System.Drawing.Size(893, 366);
            this.Orders_view.TabIndex = 91;
            this.Orders_view.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Orders_view_CellMouseDown);
            this.Orders_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Orders_view_RowPostPaint);
            this.Orders_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Orders_view_RowPrePaint);
            this.Orders_view.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Orders_view_MouseDoubleClick);
            // 
            // awaitingConfirmation
            // 
            this.awaitingConfirmation.Controls.Add(this.none1);
            this.awaitingConfirmation.Controls.Add(this.Waiting);
            this.awaitingConfirmation.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.awaitingConfirmation.Location = new System.Drawing.Point(14, 62);
            this.awaitingConfirmation.Name = "awaitingConfirmation";
            this.awaitingConfirmation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.awaitingConfirmation.SelectedIndex = 0;
            this.awaitingConfirmation.Size = new System.Drawing.Size(913, 415);
            this.awaitingConfirmation.TabIndex = 94;
            this.awaitingConfirmation.MouseClick += new System.Windows.Forms.MouseEventHandler(this.awaitingConfirmation_MouseClick);
            // 
            // none1
            // 
            this.none1.Controls.Add(this.Orders_view);
            this.none1.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.none1.Location = new System.Drawing.Point(4, 33);
            this.none1.Name = "none1";
            this.none1.Padding = new System.Windows.Forms.Padding(3);
            this.none1.Size = new System.Drawing.Size(905, 378);
            this.none1.TabIndex = 0;
            this.none1.Text = "  فاکتور های فروش  ";
            this.none1.UseVisualStyleBackColor = true;
            // 
            // Waiting
            // 
            this.Waiting.Controls.Add(this.awaitingOrders_view);
            this.Waiting.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Waiting.Location = new System.Drawing.Point(4, 33);
            this.Waiting.Name = "Waiting";
            this.Waiting.Padding = new System.Windows.Forms.Padding(3);
            this.Waiting.Size = new System.Drawing.Size(905, 378);
            this.Waiting.TabIndex = 1;
            this.Waiting.Text = "  سفارشات در انتظار  ";
            this.Waiting.UseVisualStyleBackColor = true;
            // 
            // awaitingOrders_view
            // 
            this.awaitingOrders_view.AllowUserToAddRows = false;
            this.awaitingOrders_view.AllowUserToDeleteRows = false;
            this.awaitingOrders_view.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.awaitingOrders_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.awaitingOrders_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.awaitingOrders_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.awaitingOrders_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.awaitingOrders_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.awaitingOrders_view.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.awaitingOrders_view.DefaultCellStyle = dataGridViewCellStyle4;
            this.awaitingOrders_view.Location = new System.Drawing.Point(6, 6);
            this.awaitingOrders_view.Name = "awaitingOrders_view";
            this.awaitingOrders_view.ReadOnly = true;
            this.awaitingOrders_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.awaitingOrders_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.awaitingOrders_view.RowTemplate.Height = 25;
            this.awaitingOrders_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.awaitingOrders_view.Size = new System.Drawing.Size(893, 366);
            this.awaitingOrders_view.TabIndex = 92;
            this.awaitingOrders_view.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.awaitingOrders_view_CellMouseDown);
            this.awaitingOrders_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.awaitingOrders_view_RowPostPaint);
            this.awaitingOrders_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Orders_view_RowPrePaint);
            this.awaitingOrders_view.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.awaitingOrders_view_MouseDoubleClick);
            // 
            // Orders_viewGuide
            // 
            this.Orders_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Orders_viewGuide.AutoSize = true;
            this.Orders_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Orders_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Orders_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Orders_viewGuide.Location = new System.Drawing.Point(768, 30);
            this.Orders_viewGuide.Name = "Orders_viewGuide";
            this.Orders_viewGuide.Size = new System.Drawing.Size(148, 28);
            this.Orders_viewGuide.TabIndex = 90;
            this.Orders_viewGuide.Text = "سفارشات فروشگاه";
            // 
            // OrdersWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Controls.Add(this.awaitingConfirmation);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.SearchInTable);
            this.Controls.Add(this.Orders_viewGuide);
            this.Name = "OrdersWidget";
            this.Size = new System.Drawing.Size(939, 489);
            this.Load += new System.EventHandler(this.OrdersWidget_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Orders_view)).EndInit();
            this.awaitingConfirmation.ResumeLayout(false);
            this.none1.ResumeLayout(false);
            this.Waiting.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.awaitingOrders_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button Search;
        private TextBox SearchInTable;
        private DataGridView Orders_view;
        private TabControl awaitingConfirmation;
        private TabPage none1;
        private TabPage Waiting;
        private DataGridView awaitingOrders_view;
        private Label Orders_viewGuide;
    }
}
