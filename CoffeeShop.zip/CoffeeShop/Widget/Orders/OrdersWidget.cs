﻿using CoffeeShop.Widget.Orders;
using CoffeeShop.Widget.Products;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget
{
    public partial class OrdersWidget : UserControl
    {
        public OrdersWidget()
        {
            InitializeComponent();
        }

        private void OrdersWidget_Load(object sender, EventArgs e)
        {
            AddDataTable();
        }
        DataTable Table = new DataTable();
        DataTable tableWaiting = new DataTable();

        private async void AddDataTable()
        {
            string Selecting_Orders = "http://localhost:5000/GetOrders";

            Table.Columns.Add("شماره‌فاکتور", typeof(string));
            Table.Columns.Add("شماره‌‌مشتری", typeof(string));
            Table.Columns.Add("عنوان", typeof(string));
            Table.Columns.Add("تاریخ‌ثبت", typeof(string));
            Table.Columns.Add("جمع‌کل", typeof(string));
            Table.Columns.Add("شیوه‌پرداخت", typeof(string));
            Table.Columns.Add("وضعیت", typeof(string));

            Orders_view.DataSource = Table;
            Orders_view.Columns["شماره‌‌مشتری"].Visible = false;
            Orders_view.Columns["وضعیت"].Visible = false;

            // set size column's:
            Orders_view.Columns["شماره‌فاکتور"].Width = 100;
            Orders_view.Columns["عنوان"].Width = 200;
            Orders_view.Columns["تاریخ‌ثبت"].Width = 80;

            Orders_view.Columns["جمع‌کل"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);

            tableWaiting.Columns.Add("شماره‌فاکتور", typeof(string));
            tableWaiting.Columns.Add("شماره‌‌مشتری", typeof(string));
            tableWaiting.Columns.Add("عنوان", typeof(string));
            tableWaiting.Columns.Add("تاریخ‌ثبت", typeof(string));
            tableWaiting.Columns.Add("جمع‌کل", typeof(string));
            tableWaiting.Columns.Add("شیوه‌پرداخت", typeof(string));
            tableWaiting.Columns.Add("وضعیت", typeof(string));

            awaitingOrders_view.DataSource = tableWaiting;
            awaitingOrders_view.Columns["شماره‌‌مشتری"].Visible = false;

            awaitingOrders_view.Columns["جمع‌کل"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);

            HttpClient client = new HttpClient();

            // Post:
            var postDataOrders = new List<KeyValuePair<string, string>>();
            var postDataWaiting = new List<KeyValuePair<string, string>>();

            postDataOrders.Add(new KeyValuePair<string, string>("Status", "تایید"));
            postDataWaiting.Add(new KeyValuePair<string, string>("Status", "بررسی"));

            HttpContent contentOrders = new FormUrlEncodedContent(postDataOrders);
            HttpContent contentWaiting = new FormUrlEncodedContent(postDataWaiting);

            var responseOrders = client.PostAsync(Selecting_Orders, contentOrders).Result;
            var responseWaiting = client.PostAsync(Selecting_Orders, contentWaiting).Result;

            string ResultOrders = await responseOrders.Content.ReadAsStringAsync();
            string ResultWaiting = await responseWaiting.Content.ReadAsStringAsync();

            List<OrdersClass> All_Orders = JsonConvert.DeserializeObject<List<OrdersClass>>(ResultOrders);
            List<OrdersClass> All_Wating = JsonConvert.DeserializeObject<List<OrdersClass>>(ResultWaiting);

            if (responseOrders.IsSuccessStatusCode && responseWaiting.IsSuccessStatusCode)
            {
                for (int i = 0; i < All_Orders.Count; i++) {
                    Table.Rows.Add(All_Orders[i].OrderID, All_Orders[i].CustomerID, All_Orders[i].FullName, All_Orders[i].OrderDate, All_Orders[i].TotalAmount, All_Orders[i].PaymentType, All_Orders[i].Status);
                }
                for (int i = 0; i < All_Wating.Count; i++) {
                    tableWaiting.Rows.Add(All_Wating[i].OrderID, All_Wating[i].CustomerID, All_Wating[i].FullName, All_Wating[i].OrderDate, All_Wating[i].TotalAmount, All_Wating[i].PaymentType, All_Wating[i].Status);
                }
            }
        }
        private void awaitingConfirmation_MouseClick(object sender, MouseEventArgs e)
        {
            //set size column's:
            awaitingOrders_view.Columns["شماره‌فاکتور"].Width = 100;
            awaitingOrders_view.Columns["عنوان"].Width = 200;
            awaitingOrders_view.Columns["تاریخ‌ثبت"].Width = 80;
        }
        private void Orders_view_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (Orders_view.SelectedRows.Count == 1)
            {
                FactorClass.OrderID = Orders_view.CurrentRow?.Cells["شماره‌فاکتور"]?.Value?.ToString() ?? "default value";
                FactorClass.OrderDate = Orders_view.CurrentRow?.Cells["تاریخ‌ثبت"]?.Value?.ToString() ?? "default value";
                FactorClass.CustomerOrder = Orders_view.CurrentRow?.Cells["عنوان"]?.Value?.ToString() ?? "default value";
                FactorClass.TotalFac = Orders_view.CurrentRow?.Cells["جمع‌کل"]?.Value?.ToString() ?? "default value";


                OrderDetailsWidget orderDetailsWidgetForm = new OrderDetailsWidget();
                orderDetailsWidgetForm.Show();
            }
        }
        private void Search_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search.PerformClick();
            }
        }
        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("table", "orders"));
            postData.Add(new KeyValuePair<string, string>("Status", "تایید"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));
            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<OrdersClass> All_Orders = JsonConvert.DeserializeObject<List<OrdersClass>>(Result);

            Table.Clear();
            for (int i = 0; i < All_Orders.Count; i++) {
                Table.Rows.Add(All_Orders[i].OrderID, All_Orders[i].FullName, All_Orders[i].OrderDate, All_Orders[i].TotalAmount, All_Orders[i].PaymentType, All_Orders[i].Status);
            }
        }

        private void SearchInTable_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search.PerformClick();
            }
        }
        private void Orders_view_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Orders_view.ClearSelection(); // clear previous selections
                Orders_view.Rows[e.RowIndex].Selected = true; // select the clicked row

                ContextMenuStrip recordMenu = new ContextMenuStrip();
                ToolStripMenuItem editItem = new ToolStripMenuItem("ویرایش");
                ToolStripMenuItem deleteItem = new ToolStripMenuItem("حذف");

                deleteItem.Font = editItem.Font = new Font("IRANSansXFaNum", 9);

                deleteItem.Click += new EventHandler(deleteItem_Click);
                editItem.Click += new EventHandler(editItem_Click);

                recordMenu.Items.Add(deleteItem);
                recordMenu.Items.Add(editItem);

                recordMenu.Show(Cursor.Position);
            }
        }
        private void editItem_Click(object sender, EventArgs e)
        {
            FactorClass.OrderID = Orders_view.CurrentRow?.Cells["شماره‌فاکتور"]?.Value?.ToString() ?? "default value";
            FactorClass.CustomerID = Orders_view.CurrentRow?.Cells["شماره‌‌مشتری"]?.Value?.ToString() ?? "default value";

            EditOrderWidget editOrderWidgetForm = new EditOrderWidget();
            editOrderWidgetForm.Show();
        }
        private void deleteItem_Click(object sender, EventArgs e)
        {
            if (Orders_view.SelectedRows.Count == 1)
            {
                string OrderID = Orders_view.CurrentRow?.Cells["شماره‌فاکتور"]?.Value?.ToString() ?? "default value";
                DialogResult dialogResult = MessageBox.Show(this, $"آیا مایل به حذف فاکتور موردنظر با کد {OrderID} هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                if (dialogResult == DialogResult.Yes)
                {
                    string url = $"http://localhost:5000/DeleteOrders/{OrderID}";

                    HttpClient client = new HttpClient();
                    var response = client.DeleteAsync(url).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        // remove row in table:
                        int rowIndex = Orders_view.SelectedRows[0].Index;
                        Orders_view.Rows.RemoveAt(rowIndex);

                        string textWarning = "عملیات با موفقیت انجام شد" + Environment.NewLine + $"دقت داشته باشید کد سفارش {OrderID} قابل استفاده نیست";
                        MessageBox.Show(this, textWarning, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    } else {
                        MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                }
            }
        }
        private void awaitingOrders_view_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                awaitingOrders_view.ClearSelection(); // clear previous selections
                awaitingOrders_view.Rows[e.RowIndex].Selected = true; // select the clicked row

                ContextMenuStrip recordMenu = new ContextMenuStrip();
                ToolStripMenuItem confirmation = new ToolStripMenuItem("تایید سفارش");
                ToolStripMenuItem disapproval = new ToolStripMenuItem("لغو سفارش");

                confirmation.Font = new Font("IRANSansXFaNum", 9);
                disapproval.Font = new Font("IRANSansXFaNum", 9);

                confirmation.Click += new EventHandler(confirmation_Click);
                disapproval.Click += new EventHandler(disapproval_Click);

                recordMenu.Items.Add(confirmation);
                recordMenu.Items.Add(disapproval);

                recordMenu.Show(Cursor.Position);
            }
        }
        private void awaitingOrders_view_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (awaitingOrders_view.SelectedRows.Count == 1)
            {
                FactorClass.OrderID = Orders_view.CurrentRow?.Cells["شماره‌فاکتور"]?.Value?.ToString() ?? "default value";
                FactorClass.OrderDate = Orders_view.CurrentRow?.Cells["تاریخ‌ثبت"]?.Value?.ToString() ?? "default value";
                FactorClass.CustomerOrder = Orders_view.CurrentRow?.Cells["عنوان"]?.Value?.ToString() ?? "default value";
                FactorClass.TotalFac = Orders_view.CurrentRow?.Cells["جمع‌کل"]?.Value?.ToString() ?? "default value";


                OrderDetailsWidget orderDetailsWidgetForm = new OrderDetailsWidget();
                orderDetailsWidgetForm.Show();
            }
        }
        private void confirmation_Click(object sender, EventArgs e)
        {
            UpdateOrders("تایید");
        }
        private void disapproval_Click(object sender, EventArgs e)
        {
            UpdateOrders("عدم‌تایید");
        }
        private void UpdateOrders(string Status)
        {
            if (Orders_view.SelectedRows.Count == 1)
            {
                string OrderID = awaitingOrders_view.CurrentRow?.Cells["شماره‌فاکتور"]?.Value?.ToString() ?? "default value";

                DialogResult dialogResult = new DialogResult();
                if (Status == "تایید") {
                    dialogResult = MessageBox.Show(this, $"آیا مایل به تایید فاکتور موردنظر با کد {OrderID} هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                } else if (Status == "عدم‌تایید") {
                    dialogResult = MessageBox.Show(this, $"آیا مایل به لغو فاکتور موردنظر با کد {OrderID} هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                }
                if (dialogResult == DialogResult.Yes)
                {
                    string url = "http://localhost:5000/SetStatusOrders";

                    HttpClient client = new HttpClient();
                    var postData = new List<KeyValuePair<string, string>>();

                    postData.Add(new KeyValuePair<string, string>("OrderID", OrderID));
                    postData.Add(new KeyValuePair<string, string>("Status", Status));

                    HttpContent content = new FormUrlEncodedContent(postData);

                    var response = client.PutAsync(url, content).Result;
                    if (response.IsSuccessStatusCode) {
                        // remove row in table:
                        int rowIndex = Orders_view.SelectedRows[0].Index;
                        Orders_view.Rows.RemoveAt(rowIndex);

                        string textWarning = "عملیات با موفقیت انجام شد";
                        MessageBox.Show(this, textWarning, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                    else {
                        MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                }
            }
        }

        private void Orders_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Orders_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        private void Orders_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Orders_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }

        private void awaitingOrders_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(awaitingOrders_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
