﻿namespace CoffeeShop.Widget.Orders
{
    partial class AddOrderWidget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Default_Page = new System.Windows.Forms.Panel();
            this.TotalAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RemoveCount = new System.Windows.Forms.PictureBox();
            this.Cart_viewGuide = new System.Windows.Forms.Label();
            this.SendData = new System.Windows.Forms.Button();
            this.Products_viewGuide = new System.Windows.Forms.Label();
            this.Cart_view = new System.Windows.Forms.DataGridView();
            this.Products_view = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.ClosePage = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.CustomerFName = new System.Windows.Forms.TextBox();
            this.CustomerID = new System.Windows.Forms.TextBox();
            this.CustomerAddress = new System.Windows.Forms.TextBox();
            this.CustomerPhone = new System.Windows.Forms.TextBox();
            this.showCustomerList = new System.Windows.Forms.Button();
            this.Date = new System.Windows.Forms.Label();
            this.SetCustomerPanel = new System.Windows.Forms.Panel();
            this.Search = new System.Windows.Forms.Button();
            this.SearchInTable = new System.Windows.Forms.TextBox();
            this.CloseList = new System.Windows.Forms.PictureBox();
            this.SelectRowData = new System.Windows.Forms.Button();
            this.Users_view = new System.Windows.Forms.DataGridView();
            this.Default_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RemoveCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cart_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Products_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).BeginInit();
            this.SetCustomerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CloseList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Users_view)).BeginInit();
            this.SuspendLayout();
            // 
            // Default_Page
            // 
            this.Default_Page.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Default_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Default_Page.Controls.Add(this.TotalAmount);
            this.Default_Page.Controls.Add(this.label2);
            this.Default_Page.Controls.Add(this.RemoveCount);
            this.Default_Page.Controls.Add(this.Cart_viewGuide);
            this.Default_Page.Controls.Add(this.SendData);
            this.Default_Page.Controls.Add(this.Products_viewGuide);
            this.Default_Page.Controls.Add(this.Cart_view);
            this.Default_Page.Controls.Add(this.Products_view);
            this.Default_Page.Location = new System.Drawing.Point(30, 120);
            this.Default_Page.Name = "Default_Page";
            this.Default_Page.Size = new System.Drawing.Size(963, 468);
            this.Default_Page.TabIndex = 106;
            // 
            // TotalAmount
            // 
            this.TotalAmount.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.TotalAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.TotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TotalAmount.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalAmount.Location = new System.Drawing.Point(142, 427);
            this.TotalAmount.Name = "TotalAmount";
            this.TotalAmount.ReadOnly = true;
            this.TotalAmount.Size = new System.Drawing.Size(136, 29);
            this.TotalAmount.TabIndex = 105;
            this.TotalAmount.Text = "0";
            this.TotalAmount.TextChanged += new System.EventHandler(this.TotalAmount_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label2.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label2.Location = new System.Drawing.Point(3, 427);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 28);
            this.label2.TabIndex = 103;
            this.label2.Text = "(تومان) جمع‌کل: ";
            // 
            // RemoveCount
            // 
            this.RemoveCount.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.RemoveCount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RemoveCount.Image = global::CoffeeShop.Properties.Resources.remove;
            this.RemoveCount.Location = new System.Drawing.Point(303, 426);
            this.RemoveCount.Name = "RemoveCount";
            this.RemoveCount.Size = new System.Drawing.Size(32, 32);
            this.RemoveCount.TabIndex = 102;
            this.RemoveCount.TabStop = false;
            this.RemoveCount.Visible = false;
            this.RemoveCount.Click += new System.EventHandler(this.RemoveCount_Click);
            this.RemoveCount.DoubleClick += new System.EventHandler(this.RemoveCount_DoubleClick);
            // 
            // Cart_viewGuide
            // 
            this.Cart_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Cart_viewGuide.AutoSize = true;
            this.Cart_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Cart_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cart_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Cart_viewGuide.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Cart_viewGuide.Location = new System.Drawing.Point(249, 3);
            this.Cart_viewGuide.Name = "Cart_viewGuide";
            this.Cart_viewGuide.Size = new System.Drawing.Size(86, 28);
            this.Cart_viewGuide.TabIndex = 101;
            this.Cart_viewGuide.Text = "سبد خرید";
            this.Cart_viewGuide.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Cart_viewGuide.Visible = false;
            // 
            // SendData
            // 
            this.SendData.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.SendData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(183)))), ((int)(((byte)(10)))));
            this.SendData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SendData.Enabled = false;
            this.SendData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.SendData.FlatAppearance.BorderSize = 0;
            this.SendData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SendData.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SendData.ForeColor = System.Drawing.Color.White;
            this.SendData.Location = new System.Drawing.Point(548, 422);
            this.SendData.Name = "SendData";
            this.SendData.Size = new System.Drawing.Size(208, 41);
            this.SendData.TabIndex = 100;
            this.SendData.Text = "ثبت سفارش";
            this.SendData.UseVisualStyleBackColor = false;
            this.SendData.Click += new System.EventHandler(this.SendData_Click);
            // 
            // Products_viewGuide
            // 
            this.Products_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Products_viewGuide.AutoSize = true;
            this.Products_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Products_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Products_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Products_viewGuide.Location = new System.Drawing.Point(822, 3);
            this.Products_viewGuide.Name = "Products_viewGuide";
            this.Products_viewGuide.Size = new System.Drawing.Size(140, 28);
            this.Products_viewGuide.TabIndex = 98;
            this.Products_viewGuide.Text = "لیست محصولات";
            // 
            // Cart_view
            // 
            this.Cart_view.AllowUserToAddRows = false;
            this.Cart_view.AllowUserToDeleteRows = false;
            this.Cart_view.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Cart_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Cart_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Cart_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Cart_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Cart_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Cart_view.DefaultCellStyle = dataGridViewCellStyle2;
            this.Cart_view.Location = new System.Drawing.Point(0, 34);
            this.Cart_view.Name = "Cart_view";
            this.Cart_view.ReadOnly = true;
            this.Cart_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Cart_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Cart_view.RowTemplate.Height = 25;
            this.Cart_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Cart_view.Size = new System.Drawing.Size(335, 382);
            this.Cart_view.TabIndex = 99;
            this.Cart_view.Visible = false;
            this.Cart_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Cart_view_RowPostPaint);
            this.Cart_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Cart_view_RowPrePaint);
            // 
            // Products_view
            // 
            this.Products_view.AllowUserToAddRows = false;
            this.Products_view.AllowUserToDeleteRows = false;
            this.Products_view.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Products_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Products_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Products_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Products_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.Products_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Products_view.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Products_view.DefaultCellStyle = dataGridViewCellStyle5;
            this.Products_view.Location = new System.Drawing.Point(341, 34);
            this.Products_view.Name = "Products_view";
            this.Products_view.ReadOnly = true;
            this.Products_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Products_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Products_view.RowTemplate.Height = 25;
            this.Products_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Products_view.Size = new System.Drawing.Size(622, 382);
            this.Products_view.TabIndex = 1;
            this.Products_view.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_view_CellDoubleClick);
            this.Products_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Products_view_RowPostPaint);
            this.Products_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Products_view_RowPrePaint);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(30, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(963, 101);
            this.label1.TabIndex = 107;
            // 
            // ClosePage
            // 
            this.ClosePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClosePage.Image = global::CoffeeShop.Properties.Resources.close;
            this.ClosePage.Location = new System.Drawing.Point(1006, 12);
            this.ClosePage.Name = "ClosePage";
            this.ClosePage.Size = new System.Drawing.Size(32, 32);
            this.ClosePage.TabIndex = 108;
            this.ClosePage.TabStop = false;
            this.ClosePage.Click += new System.EventHandler(this.ClosePage_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label3.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label3.Location = new System.Drawing.Point(922, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 24);
            this.label3.TabIndex = 106;
            this.label3.Text = "مشتری";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label4.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label4.Location = new System.Drawing.Point(922, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 24);
            this.label4.TabIndex = 109;
            this.label4.Text = "آدرس";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label5.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label5.Location = new System.Drawing.Point(922, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 24);
            this.label5.TabIndex = 110;
            this.label5.Text = "تلفن";
            // 
            // CustomerFName
            // 
            this.CustomerFName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CustomerFName.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CustomerFName.ForeColor = System.Drawing.Color.DimGray;
            this.CustomerFName.Location = new System.Drawing.Point(531, 20);
            this.CustomerFName.Multiline = true;
            this.CustomerFName.Name = "CustomerFName";
            this.CustomerFName.ReadOnly = true;
            this.CustomerFName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CustomerFName.Size = new System.Drawing.Size(269, 24);
            this.CustomerFName.TabIndex = 111;
            // 
            // CustomerID
            // 
            this.CustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CustomerID.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CustomerID.ForeColor = System.Drawing.Color.DimGray;
            this.CustomerID.Location = new System.Drawing.Point(806, 20);
            this.CustomerID.Multiline = true;
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CustomerID.Size = new System.Drawing.Size(110, 24);
            this.CustomerID.TabIndex = 112;
            // 
            // CustomerAddress
            // 
            this.CustomerAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CustomerAddress.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CustomerAddress.ForeColor = System.Drawing.Color.DimGray;
            this.CustomerAddress.Location = new System.Drawing.Point(531, 51);
            this.CustomerAddress.Multiline = true;
            this.CustomerAddress.Name = "CustomerAddress";
            this.CustomerAddress.ReadOnly = true;
            this.CustomerAddress.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CustomerAddress.Size = new System.Drawing.Size(385, 24);
            this.CustomerAddress.TabIndex = 113;
            // 
            // CustomerPhone
            // 
            this.CustomerPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CustomerPhone.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CustomerPhone.ForeColor = System.Drawing.Color.DimGray;
            this.CustomerPhone.Location = new System.Drawing.Point(531, 82);
            this.CustomerPhone.Multiline = true;
            this.CustomerPhone.Name = "CustomerPhone";
            this.CustomerPhone.ReadOnly = true;
            this.CustomerPhone.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CustomerPhone.Size = new System.Drawing.Size(385, 24);
            this.CustomerPhone.TabIndex = 114;
            // 
            // showCustomerList
            // 
            this.showCustomerList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.showCustomerList.Image = global::CoffeeShop.Properties.Resources.Down;
            this.showCustomerList.Location = new System.Drawing.Point(534, 23);
            this.showCustomerList.Name = "showCustomerList";
            this.showCustomerList.Size = new System.Drawing.Size(20, 18);
            this.showCustomerList.TabIndex = 115;
            this.showCustomerList.UseVisualStyleBackColor = true;
            this.showCustomerList.Click += new System.EventHandler(this.showCustomerList_Click);
            // 
            // Date
            // 
            this.Date.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Date.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Date.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Date.Location = new System.Drawing.Point(46, 19);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(82, 24);
            this.Date.TabIndex = 117;
            this.Date.Text = "1401/01/21";
            // 
            // SetCustomerPanel
            // 
            this.SetCustomerPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SetCustomerPanel.Controls.Add(this.Search);
            this.SetCustomerPanel.Controls.Add(this.SearchInTable);
            this.SetCustomerPanel.Controls.Add(this.CloseList);
            this.SetCustomerPanel.Controls.Add(this.SelectRowData);
            this.SetCustomerPanel.Controls.Add(this.Users_view);
            this.SetCustomerPanel.Location = new System.Drawing.Point(531, 45);
            this.SetCustomerPanel.Name = "SetCustomerPanel";
            this.SetCustomerPanel.Size = new System.Drawing.Size(385, 300);
            this.SetCustomerPanel.TabIndex = 135;
            this.SetCustomerPanel.Visible = false;
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Window;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Image = global::CoffeeShop.Properties.Resources.search;
            this.Search.Location = new System.Drawing.Point(18, 16);
            this.Search.Margin = new System.Windows.Forms.Padding(0);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(25, 25);
            this.Search.TabIndex = 120;
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // SearchInTable
            // 
            this.SearchInTable.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SearchInTable.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SearchInTable.Location = new System.Drawing.Point(12, 14);
            this.SearchInTable.Multiline = true;
            this.SearchInTable.Name = "SearchInTable";
            this.SearchInTable.PlaceholderText = "  کاربر مورد نظر را جست و جو کنید";
            this.SearchInTable.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.SearchInTable.Size = new System.Drawing.Size(265, 30);
            this.SearchInTable.TabIndex = 119;
            // 
            // CloseList
            // 
            this.CloseList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseList.Image = global::CoffeeShop.Properties.Resources.multiply;
            this.CloseList.Location = new System.Drawing.Point(348, 17);
            this.CloseList.Name = "CloseList";
            this.CloseList.Size = new System.Drawing.Size(24, 24);
            this.CloseList.TabIndex = 117;
            this.CloseList.TabStop = false;
            this.CloseList.Click += new System.EventHandler(this.CloseList_Click);
            // 
            // SelectRowData
            // 
            this.SelectRowData.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.SelectRowData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SelectRowData.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.SelectRowData.FlatAppearance.BorderSize = 0;
            this.SelectRowData.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectRowData.Font = new System.Drawing.Font("IRANSansXFaNum", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SelectRowData.ForeColor = System.Drawing.Color.White;
            this.SelectRowData.Location = new System.Drawing.Point(134, 262);
            this.SelectRowData.Name = "SelectRowData";
            this.SelectRowData.Size = new System.Drawing.Size(115, 32);
            this.SelectRowData.TabIndex = 116;
            this.SelectRowData.Text = "انتخاب";
            this.SelectRowData.UseVisualStyleBackColor = false;
            this.SelectRowData.Click += new System.EventHandler(this.SelectRowData_Click);
            // 
            // Users_view
            // 
            this.Users_view.AllowUserToAddRows = false;
            this.Users_view.AllowUserToDeleteRows = false;
            this.Users_view.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Users_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Users_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Users_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Users_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.Users_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Users_view.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Users_view.DefaultCellStyle = dataGridViewCellStyle8;
            this.Users_view.Location = new System.Drawing.Point(11, 49);
            this.Users_view.MultiSelect = false;
            this.Users_view.Name = "Users_view";
            this.Users_view.ReadOnly = true;
            this.Users_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Users_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.Users_view.RowTemplate.Height = 25;
            this.Users_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Users_view.Size = new System.Drawing.Size(361, 209);
            this.Users_view.TabIndex = 115;
            this.Users_view.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Users_view_CellMouseDoubleClick);
            // 
            // AddOrderWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1050, 601);
            this.Controls.Add(this.SetCustomerPanel);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.showCustomerList);
            this.Controls.Add(this.CustomerPhone);
            this.Controls.Add(this.CustomerAddress);
            this.Controls.Add(this.CustomerID);
            this.Controls.Add(this.CustomerFName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ClosePage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Default_Page);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "AddOrderWidget";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddOrderWidget";
            this.Load += new System.EventHandler(this.AddOrderrrrrrWidget_Load);
            this.Default_Page.ResumeLayout(false);
            this.Default_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RemoveCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cart_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Products_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).EndInit();
            this.SetCustomerPanel.ResumeLayout(false);
            this.SetCustomerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CloseList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Users_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel Default_Page;
        private TextBox TotalAmount;
        private Label label2;
        private PictureBox RemoveCount;
        private Label Cart_viewGuide;
        private Button SendData;
        private Label Products_viewGuide;
        private DataGridView Cart_view;
        private DataGridView Products_view;
        private Label label1;
        private PictureBox ClosePage;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button showCustomerList;
        private Label Date;
        public TextBox CustomerFName;
        public TextBox CustomerID;
        public TextBox CustomerAddress;
        public TextBox CustomerPhone;
        private Panel SetCustomerPanel;
        private Button Search;
        private TextBox SearchInTable;
        private PictureBox CloseList;
        private Button SelectRowData;
        private DataGridView Users_view;
    }
}