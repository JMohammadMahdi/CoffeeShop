﻿using CoffeeShop.Widget.Products;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Categories
{
    public partial class CategoriesWidget : UserControl
    {
        public CategoriesWidget()
        {
            InitializeComponent();
        }

        DataTable Table = new DataTable();
        private void CategoriesWidget_Load(object sender, EventArgs e)
        {
            AddDataToCategories();
        }
        private async void AddDataToCategories()
        {
            string url = "http://localhost:5000/GetCategories";

            Table.Columns.Add("کد‌دسته‌بندی", typeof(string));
            Table.Columns.Add("نام‌دسته‌بندی", typeof(string));
            Table.Columns.Add("توضیحات‌دسته‌بندی", typeof(string));
            Table.Columns.Add("آدرس تصویر", typeof(string));

            Categories_view.DataSource = Table;
            Categories_view.Columns["آدرس تصویر"].Visible = false;

            Categories_view.Columns["کد‌دسته‌بندی"].Width = 100;

            HttpClient client = new HttpClient();

            // Get: 
            string Result = await client.GetStringAsync(url);

            List<CategoriesClass> Categories = JsonConvert.DeserializeObject<List<CategoriesClass>>(Result);

            for (int i = 0; i < Categories.Count; i++)
            {
                Table.Rows.Add(Categories[i].CategoryID, Categories[i].CategoryName, Categories[i].CategoryDescription, Categories[i].CategoryImage);
            }

            // UseWaitCursor is OFF:
            //Users_view.UseWaitCursor = false;
        }

        private void Categories_view_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Categories_view.ClearSelection(); // clear previous selections
                Categories_view.Rows[e.RowIndex].Selected = true; // select the clicked row

                ContextMenuStrip recordMenu = new ContextMenuStrip();
                ToolStripMenuItem addItem = new ToolStripMenuItem("افزودن");
                ToolStripMenuItem editItem = new ToolStripMenuItem("ویرایش");
                ToolStripMenuItem deleteItem = new ToolStripMenuItem("حذف");

                addItem.Font = new Font("IRANSansXFaNum", 9);
                editItem.Font = new Font("IRANSansXFaNum", 9);
                deleteItem.Font = new Font("IRANSansXFaNum", 9);

                addItem.Click += new EventHandler(addItem_Click);
                editItem.Click += new EventHandler(editItem_Click);
                deleteItem.Click += new EventHandler(deleteItem_Click);

                recordMenu.Items.Add(editItem);
                recordMenu.Items.Add(deleteItem);
                recordMenu.Items.Add(addItem);

                recordMenu.Show(Cursor.Position);
            }
        }
        private void editItem_Click(object sender, EventArgs e)
        {
            if (Categories_view.SelectedRows.Count == 1)
            {
                EditCategories.CategoryID = Categories_view.CurrentRow?.Cells[0]?.Value?.ToString() ?? "default value";
                EditCategories.CategoryName = Categories_view.CurrentRow?.Cells[1]?.Value?.ToString() ?? "default value";
                EditCategories.CategoryDescription = Categories_view.CurrentRow?.Cells[2]?.Value?.ToString() ?? "default value";
                EditCategories.CategoryImage = Categories_view.CurrentRow?.Cells[3]?.Value?.ToString() ?? "default value";

                EditCategoriesPopup editCategoriesPopupForm = new EditCategoriesPopup();
                editCategoriesPopupForm.Show();
            }
        }
        private void addItem_Click(object sender, EventArgs e)
        {
            AddCategoriesPopup addCategoriesPopupForm = new AddCategoriesPopup();
            addCategoriesPopupForm.Show();
        }
        private void deleteItem_Click(object sender, EventArgs e)
        {
            if (Categories_view.SelectedRows.Count == 1)
            {
                string CategoryID = Categories_view.CurrentRow?.Cells["کد‌دسته‌بندی"]?.Value?.ToString() ?? "default value";
                string CategoryName = Categories_view.CurrentRow?.Cells["نام‌دسته‌بندی"]?.Value?.ToString() ?? "default value";

                DialogResult dialogResult = MessageBox.Show(this, $"آیا مایل به حذف دسته‌بندی موردنظر با کد {CategoryID} هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.Yes)
                {
                    string url = $"http://localhost:5000/DeleteCategories/{CategoryID}";

                    HttpClient client = new HttpClient();
                    var response = client.DeleteAsync(url).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        string[] ArrayCategories = File.ReadAllLines(Settings.PathFileCategories);

                        int i = 0;
                        foreach (var item in ArrayCategories)
                        {
                            if (CategoryName == item) {
                                ArrayCategories[i] = String.Empty;
                                break;
                            }
                            i++;
                        }

                        File.WriteAllLines(Settings.PathFileCategories, ArrayCategories);

                        // remove row in table:
                        int rowIndex = Categories_view.SelectedRows[0].Index;
                        Categories_view.Rows.RemoveAt(rowIndex);

                        string textWarning = "عملیات با موفقیت انجام شد" + Environment.NewLine + $"دقت داشته باشید کد دسته‌بندی {CategoryID} قابل استفاده نیست";
                        MessageBox.Show(this, textWarning, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    } else {
                        MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                }
            }
        }

        private void Categories_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Categories_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("table", "categories"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));
            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<CategoriesClass> All_Categories = JsonConvert.DeserializeObject<List<CategoriesClass>>(Result);

            Table.Clear();
            for (int i = 0; i < All_Categories.Count; i++) {
                Table.Rows.Add(All_Categories[i].CategoryID, All_Categories[i].CategoryName, All_Categories[i].CategoryDescription, All_Categories[i].CategoryImage);
            }
        }

        private void Categories_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Categories_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
