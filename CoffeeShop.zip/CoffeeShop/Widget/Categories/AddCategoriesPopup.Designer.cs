﻿namespace CoffeeShop.Widget.Categories
{
    partial class AddCategoriesPopup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCategoriesPopup));
            this.UploadFile = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.SaveData = new System.Windows.Forms.Button();
            this.C_image = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Users_viewGuide = new System.Windows.Forms.Label();
            this.C_Description = new System.Windows.Forms.TextBox();
            this.ClosePage = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.FirstnameGuide = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.C_Category = new System.Windows.Forms.TextBox();
            this.LastnameGuide = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.C_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // UploadFile
            // 
            this.UploadFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UploadFile.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(204)))), ((int)(((byte)(205)))));
            this.UploadFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UploadFile.Image = ((System.Drawing.Image)(resources.GetObject("UploadFile.Image")));
            this.UploadFile.Location = new System.Drawing.Point(360, 355);
            this.UploadFile.Name = "UploadFile";
            this.UploadFile.Size = new System.Drawing.Size(50, 50);
            this.UploadFile.TabIndex = 4;
            this.UploadFile.UseVisualStyleBackColor = true;
            this.UploadFile.Click += new System.EventHandler(this.UploadFile_Click);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(360, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 24);
            this.label7.TabIndex = 80;
            this.label7.Text = "تصویر";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SaveData
            // 
            this.SaveData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.SaveData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(108)))), ((int)(((byte)(100)))));
            this.SaveData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(189)))), ((int)(((byte)(201)))));
            this.SaveData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveData.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SaveData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.SaveData.Location = new System.Drawing.Point(144, 449);
            this.SaveData.Name = "SaveData";
            this.SaveData.Size = new System.Drawing.Size(208, 41);
            this.SaveData.TabIndex = 5;
            this.SaveData.Text = "افزودن دسته‌بندی";
            this.SaveData.UseVisualStyleBackColor = false;
            this.SaveData.Click += new System.EventHandler(this.SaveData_Click);
            // 
            // C_image
            // 
            this.C_image.BackColor = System.Drawing.Color.Gainsboro;
            this.C_image.Location = new System.Drawing.Point(249, 305);
            this.C_image.Name = "C_image";
            this.C_image.Size = new System.Drawing.Size(100, 100);
            this.C_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C_image.TabIndex = 79;
            this.C_image.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::CoffeeShop.Properties.Resources.user_two;
            this.pictureBox1.Location = new System.Drawing.Point(470, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.TabIndex = 74;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(3, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(351, 20);
            this.label3.TabIndex = 72;
            this.label3.Text = "_________________________________________________________";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(365, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 24);
            this.label4.TabIndex = 73;
            this.label4.Text = "اطلاعات جامع";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Users_viewGuide
            // 
            this.Users_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Users_viewGuide.AutoSize = true;
            this.Users_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Users_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Users_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Users_viewGuide.Location = new System.Drawing.Point(267, 14);
            this.Users_viewGuide.Name = "Users_viewGuide";
            this.Users_viewGuide.Size = new System.Drawing.Size(150, 28);
            this.Users_viewGuide.TabIndex = 89;
            this.Users_viewGuide.Text = "افزودن دسته‌بندی";
            // 
            // C_Description
            // 
            this.C_Description.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.C_Description.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.C_Description.Location = new System.Drawing.Point(101, 150);
            this.C_Description.Multiline = true;
            this.C_Description.Name = "C_Description";
            this.C_Description.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.C_Description.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.C_Description.Size = new System.Drawing.Size(248, 125);
            this.C_Description.TabIndex = 3;
            // 
            // ClosePage
            // 
            this.ClosePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClosePage.Image = ((System.Drawing.Image)(resources.GetObject("ClosePage.Image")));
            this.ClosePage.Location = new System.Drawing.Point(640, 12);
            this.ClosePage.Name = "ClosePage";
            this.ClosePage.Size = new System.Drawing.Size(32, 32);
            this.ClosePage.TabIndex = 88;
            this.ClosePage.TabStop = false;
            this.ClosePage.Click += new System.EventHandler(this.ClosePage_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::CoffeeShop.Properties.Resources.user_two;
            this.pictureBox2.Location = new System.Drawing.Point(470, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(327, 20);
            this.label1.TabIndex = 41;
            this.label1.Text = "_____________________________________________________";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(343, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 24);
            this.label2.TabIndex = 43;
            this.label2.Text = "اطلاعات شناسایی";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FirstnameGuide
            // 
            this.FirstnameGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FirstnameGuide.AutoSize = true;
            this.FirstnameGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FirstnameGuide.Location = new System.Drawing.Point(360, 45);
            this.FirstnameGuide.Name = "FirstnameGuide";
            this.FirstnameGuide.Size = new System.Drawing.Size(75, 24);
            this.FirstnameGuide.TabIndex = 51;
            this.FirstnameGuide.Text = "دسته‌بندی";
            this.FirstnameGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.C_Category);
            this.panel1.Controls.Add(this.UploadFile);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.SaveData);
            this.panel1.Controls.Add(this.C_image);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.FirstnameGuide);
            this.panel1.Controls.Add(this.C_Description);
            this.panel1.Controls.Add(this.LastnameGuide);
            this.panel1.Location = new System.Drawing.Point(91, 120);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(502, 493);
            this.panel1.TabIndex = 90;
            // 
            // C_Category
            // 
            this.C_Category.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.C_Category.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.C_Category.Location = new System.Drawing.Point(101, 42);
            this.C_Category.Name = "C_Category";
            this.C_Category.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.C_Category.Size = new System.Drawing.Size(248, 31);
            this.C_Category.TabIndex = 82;
            // 
            // LastnameGuide
            // 
            this.LastnameGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LastnameGuide.AutoSize = true;
            this.LastnameGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LastnameGuide.Location = new System.Drawing.Point(360, 153);
            this.LastnameGuide.Name = "LastnameGuide";
            this.LastnameGuide.Size = new System.Drawing.Size(124, 24);
            this.LastnameGuide.TabIndex = 53;
            this.LastnameGuide.Text = "توضیحات‌محصول";
            this.LastnameGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(2, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(680, 728);
            this.panel2.TabIndex = 91;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label5.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label5.Location = new System.Drawing.Point(928, 685);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 28);
            this.label5.TabIndex = 85;
            this.label5.Text = "ویرایش محصول";
            // 
            // AddCategoriesPopup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(684, 731);
            this.Controls.Add(this.Users_viewGuide);
            this.Controls.Add(this.ClosePage);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddCategoriesPopup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddCategoriesPopup";
            ((System.ComponentModel.ISupportInitialize)(this.C_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button UploadFile;
        private Label label7;
        private Button SaveData;
        private PictureBox C_image;
        private PictureBox pictureBox1;
        private Label label3;
        private Label label4;
        private Label Users_viewGuide;
        private TextBox C_Description;
        private PictureBox ClosePage;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label2;
        private Label FirstnameGuide;
        private Panel panel1;
        private Label LastnameGuide;
        private TextBox C_Category;
        private Panel panel2;
        private Label label5;
    }
}