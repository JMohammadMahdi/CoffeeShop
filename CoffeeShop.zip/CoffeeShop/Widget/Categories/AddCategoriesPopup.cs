﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace CoffeeShop.Widget.Categories
{
    public partial class AddCategoriesPopup : Form
    {
        public AddCategoriesPopup()
        {
            InitializeComponent();
        }
        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void UploadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = Settings.pathFolderCategoriesImage;
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                C_image.Image = System.Drawing.Image.FromFile(openFileDialog.FileName);
                Settings.ImageFilename = openFileDialog.FileName;
            }
        }

        private void SaveData_Click(object sender, EventArgs e)
        {
            AddCategory(C_Category.Text, C_Description.Text, Settings.ImageFilename);
        }

        private void AddCategory(string CategoryName, string CategoryDescription, string CategoryImage)
        {
            string url = "http://localhost:5000/AddCategories";
            int CategoryID = Convert.ToInt32(File.ReadAllText(Settings.PathFileCountCategories)) + 1;

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("CategoryID", CategoryID.ToString()));
            postData.Add(new KeyValuePair<string, string>("CategoryName", CategoryName));
            postData.Add(new KeyValuePair<string, string>("CategoryDescription", CategoryDescription));
            postData.Add(new KeyValuePair<string, string>("CategoryImage", CategoryImage));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                // remove text in text boxes:
                C_Category.Text = C_Description.Text = null;

                // apend List Categori
                string[] ArrayCategories = File.ReadAllLines(Settings.PathFileCategories);
                ArrayCategories = ArrayCategories.Append(CategoryName).ToArray();
                File.WriteAllLines(Settings.PathFileCategories, ArrayCategories);

                // add count Categories
                File.WriteAllText(Settings.PathFileCountCategories, CategoryID.ToString());

                DialogResult dialogResult = MessageBox.Show(this, $"دسته‌بندی مورد نظر با کد {CategoryID} با موفقیت ایجاد شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.OK) {
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }
    }
}
