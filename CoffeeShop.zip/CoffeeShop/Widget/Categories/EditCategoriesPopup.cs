﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace CoffeeShop.Widget.Categories
{
    public partial class EditCategoriesPopup : Form
    {
        public EditCategoriesPopup()
        {
            InitializeComponent();
        }

        private void EditCategoriesPopup_Load(object sender, EventArgs e)
        {
            C_ID.Text = EditCategories.CategoryID;
            C_Description.Text = EditCategories.CategoryDescription;
            C_image.Image = (EditCategories.CategoryImage != "") ? C_image.Image = System.Drawing.Image.FromFile(EditCategories.CategoryImage) : null;
            C_Category.Text = EditCategories.CategoryName;
        }

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void UploadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = Settings.pathFolderCategoriesImage;
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                C_image.Image = System.Drawing.Image.FromFile(openFileDialog.FileName);
                Settings.ImageFilename = openFileDialog.FileName;
            }
        }
        private void SaveData_Click(object sender, EventArgs e)
        {
            UpdateCategory(C_ID.Text, C_Category.Text, C_Description.Text, Settings.ImageFilename);
        }
        private void UpdateCategory(string CategoryID, string CategoryName, string CategoryDescription, string CategoryImage)
        {
            string url = "http://localhost:5000/UpdateCategories";

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("CategoryID", CategoryID));
            postData.Add(new KeyValuePair<string, string>("CategoryName", CategoryName));
            postData.Add(new KeyValuePair<string, string>("CategoryDescription", CategoryDescription));
            postData.Add(new KeyValuePair<string, string>("CategoryImage", CategoryImage));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PutAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                // remove text in text boxes:
                C_ID.Text = C_Category.Text = C_Description.Text = null;

                string[] ArrayCategories = File.ReadAllLines(Settings.PathFileCategories);

                int i = 0;
                foreach (var item in ArrayCategories)
                {
                    if (EditCategories.CategoryName == item) {
                        ArrayCategories[i] = CategoryName;
                        break;
                    }
                    i++;
                }

                File.WriteAllLines(Settings.PathFileCategories, ArrayCategories);

                DialogResult dialogResult = MessageBox.Show(this, "اطلاعات دسته‌بندی با موفقیت ویرایش شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.OK) {
                    this.Hide();
                }
            } else {
                MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }
    }
}
