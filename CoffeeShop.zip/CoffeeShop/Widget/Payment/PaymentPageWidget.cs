﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace CoffeeShop.Widget.Payment
{
    public partial class PaymentPageWidget : Form
    {
        public PaymentPageWidget()
        {
            InitializeComponent();
        }

        private void Pay_Click(object sender, EventArgs e)
        {
            AddOrder(PaymentPage.ID);
        }
        public static string GetPersianDate(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            int year = pc.GetYear(date);
            int month = pc.GetMonth(date);
            int day = pc.GetDayOfMonth(date);
            string persianDate = $"{year:0000}/{month:00}/{day:00}";

            return persianDate;
        }
        private void AddOrder(int orderID)
        {
            string url = "http://localhost:5000/AddOrder";

            string orderdate = GetPersianDate(DateTime.Now);
            string totalAmount = PaymentPage.Total;

            // cart data to List:
            List<RowData> cart = PaymentPage.CartData;

            // Convert Cart to Json:
            string Json = JsonConvert.SerializeObject(cart);

            HttpClient client = new HttpClient();

            // Post:
            var Order = new List<KeyValuePair<string, string>>();
            // details data:
            Order.Add(new KeyValuePair<string, string>("Cart", Json));
            // order data:
            Order.Add(new KeyValuePair<string, string>("OrderID", orderID.ToString()));
            Order.Add(new KeyValuePair<string, string>("CustomerOrder", userLoggedIn.CustomerID.ToString()));
            Order.Add(new KeyValuePair<string, string>("OrderDate", orderdate));
            Order.Add(new KeyValuePair<string, string>("TotalAmount", totalAmount));

            HttpContent content = new FormUrlEncodedContent(Order);
            var response = client.PostAsync(url, content).Result;

            if (response.IsSuccessStatusCode)
            {
                File.WriteAllText(Settings.pathFileFactorID, Convert.ToString(orderID));
                MessageBox.Show(this, "سفارش شما با موفقیت ثبت شد؛ منتظر پاسخ مدیریت باشید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                this.Hide();
            }
            else
            {
                MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }
        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
