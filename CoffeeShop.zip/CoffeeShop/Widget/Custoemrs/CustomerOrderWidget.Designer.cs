﻿namespace CoffeeShop.Widget.Custoemrs
{
    partial class CustomerOrderWidget
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Orders_view = new System.Windows.Forms.DataGridView();
            this.Orders_viewGuide = new System.Windows.Forms.Label();
            this.EmptyBasket = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EmptyBasket_Panel = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Orders_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmptyBasket)).BeginInit();
            this.EmptyBasket_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Orders_view
            // 
            this.Orders_view.AllowUserToAddRows = false;
            this.Orders_view.AllowUserToDeleteRows = false;
            this.Orders_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Orders_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Orders_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Orders_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Orders_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Orders_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Orders_view.DefaultCellStyle = dataGridViewCellStyle2;
            this.Orders_view.Location = new System.Drawing.Point(0, 40);
            this.Orders_view.Name = "Orders_view";
            this.Orders_view.ReadOnly = true;
            this.Orders_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Orders_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Orders_view.RowTemplate.Height = 25;
            this.Orders_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Orders_view.Size = new System.Drawing.Size(1005, 425);
            this.Orders_view.TabIndex = 93;
            this.Orders_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Orders_view_RowPostPaint);
            this.Orders_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Orders_view_RowPrePaint);
            this.Orders_view.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Orders_view_MouseDoubleClick);
            // 
            // Orders_viewGuide
            // 
            this.Orders_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Orders_viewGuide.AutoSize = true;
            this.Orders_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Orders_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Orders_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Orders_viewGuide.Location = new System.Drawing.Point(887, 9);
            this.Orders_viewGuide.Name = "Orders_viewGuide";
            this.Orders_viewGuide.Size = new System.Drawing.Size(118, 28);
            this.Orders_viewGuide.TabIndex = 92;
            this.Orders_viewGuide.Text = "سفارشات اخیر";
            // 
            // EmptyBasket
            // 
            this.EmptyBasket.Image = global::CoffeeShop.Properties.Resources.empty_cart;
            this.EmptyBasket.Location = new System.Drawing.Point(66, 49);
            this.EmptyBasket.Name = "EmptyBasket";
            this.EmptyBasket.Size = new System.Drawing.Size(128, 128);
            this.EmptyBasket.TabIndex = 94;
            this.EmptyBasket.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label1.Location = new System.Drawing.Point(5, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 28);
            this.label1.TabIndex = 95;
            this.label1.Text = "!متأسفانه سفارشی ثبت نکرده اید";
            // 
            // EmptyBasket_Panel
            // 
            this.EmptyBasket_Panel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.EmptyBasket_Panel.Controls.Add(this.EmptyBasket);
            this.EmptyBasket_Panel.Controls.Add(this.label1);
            this.EmptyBasket_Panel.Location = new System.Drawing.Point(369, 164);
            this.EmptyBasket_Panel.Name = "EmptyBasket_Panel";
            this.EmptyBasket_Panel.Size = new System.Drawing.Size(265, 177);
            this.EmptyBasket_Panel.TabIndex = 96;
            this.EmptyBasket_Panel.Visible = false;
            // 
            // CustomerOrderWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Controls.Add(this.EmptyBasket_Panel);
            this.Controls.Add(this.Orders_view);
            this.Controls.Add(this.Orders_viewGuide);
            this.Name = "CustomerOrderWidget";
            this.Size = new System.Drawing.Size(1005, 489);
            this.Load += new System.EventHandler(this.OrderWidget_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Orders_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmptyBasket)).EndInit();
            this.EmptyBasket_Panel.ResumeLayout(false);
            this.EmptyBasket_Panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView Orders_view;
        private Label Orders_viewGuide;
        private PictureBox EmptyBasket;
        private Label label1;
        private Panel EmptyBasket_Panel;
    }
}
