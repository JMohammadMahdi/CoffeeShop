﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace CoffeeShop.Widget.Custoemrs.Product_Detailes
{
    public partial class ProductsDetailesWidget : Form
    {
        public ProductsDetailesWidget()
        {
            InitializeComponent();
        }

        private void ProductsDetailesWidget_Load(object sender, EventArgs e)
        {
            ProductID.Text = saveProducts.ProductID;
            ProductName.Text = saveProducts.ProductName;
            ProductDescription.Text = saveProducts.Description;
            ProductImage.Image = (saveProducts.Image != "") ? ProductImage.Image = System.Drawing.Image.FromFile(saveProducts.Image) : null;
        }

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
