﻿namespace CoffeeShop.Widget.Custoemrs.Product_Detailes
{
    partial class ProductsDetailesWidget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductsDetailesWidget));
            this.ProductImage = new System.Windows.Forms.PictureBox();
            this.ClosePage = new System.Windows.Forms.PictureBox();
            this.IDGuide = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ProductID = new System.Windows.Forms.Label();
            this.ProductName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ProductDescription = new System.Windows.Forms.TextBox();
            this.Users_viewGuide = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.allEleman = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.ProductImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).BeginInit();
            this.SuspendLayout();
            // 
            // ProductImage
            // 
            this.ProductImage.Location = new System.Drawing.Point(472, 75);
            this.ProductImage.Name = "ProductImage";
            this.ProductImage.Size = new System.Drawing.Size(200, 200);
            this.ProductImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ProductImage.TabIndex = 0;
            this.ProductImage.TabStop = false;
            // 
            // ClosePage
            // 
            this.ClosePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClosePage.Image = ((System.Drawing.Image)(resources.GetObject("ClosePage.Image")));
            this.ClosePage.Location = new System.Drawing.Point(640, 12);
            this.ClosePage.Name = "ClosePage";
            this.ClosePage.Size = new System.Drawing.Size(32, 32);
            this.ClosePage.TabIndex = 85;
            this.ClosePage.TabStop = false;
            this.ClosePage.Click += new System.EventHandler(this.ClosePage_Click);
            // 
            // IDGuide
            // 
            this.IDGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IDGuide.AutoSize = true;
            this.IDGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.IDGuide.Location = new System.Drawing.Point(323, 77);
            this.IDGuide.Name = "IDGuide";
            this.IDGuide.Size = new System.Drawing.Size(88, 24);
            this.IDGuide.TabIndex = 86;
            this.IDGuide.Text = ": کدمحصول";
            this.IDGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label7.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(431, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 196);
            this.label7.TabIndex = 87;
            this.label7.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProductID
            // 
            this.ProductID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ProductID.Font = new System.Drawing.Font("IRANSansXFaNum ExtraBold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ProductID.Location = new System.Drawing.Point(178, 77);
            this.ProductID.Name = "ProductID";
            this.ProductID.Size = new System.Drawing.Size(150, 24);
            this.ProductID.TabIndex = 88;
            this.ProductID.Text = "int";
            this.ProductID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ProductName
            // 
            this.ProductName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ProductName.Font = new System.Drawing.Font("IRANSansXFaNum ExtraBold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ProductName.Location = new System.Drawing.Point(28, 114);
            this.ProductName.Name = "ProductName";
            this.ProductName.Size = new System.Drawing.Size(300, 24);
            this.ProductName.TabIndex = 90;
            this.ProductName.Text = "string";
            this.ProductName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(323, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 24);
            this.label3.TabIndex = 89;
            this.label3.Text = ": نام محصول";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProductDescription
            // 
            this.ProductDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ProductDescription.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ProductDescription.Location = new System.Drawing.Point(12, 151);
            this.ProductDescription.Multiline = true;
            this.ProductDescription.Name = "ProductDescription";
            this.ProductDescription.ReadOnly = true;
            this.ProductDescription.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ProductDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ProductDescription.Size = new System.Drawing.Size(247, 148);
            this.ProductDescription.TabIndex = 91;
            this.ProductDescription.TabStop = false;
            // 
            // Users_viewGuide
            // 
            this.Users_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Users_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Users_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum ExtraBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Users_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Users_viewGuide.Location = new System.Drawing.Point(222, 14);
            this.Users_viewGuide.Name = "Users_viewGuide";
            this.Users_viewGuide.Size = new System.Drawing.Size(241, 28);
            this.Users_viewGuide.TabIndex = 92;
            this.Users_viewGuide.Text = "جزئیات محصول";
            this.Users_viewGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(278, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 24);
            this.label5.TabIndex = 93;
            this.label5.Text = ": توضیحات محصول";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // allEleman
            // 
            this.allEleman.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.allEleman.Location = new System.Drawing.Point(3, 3);
            this.allEleman.Name = "allEleman";
            this.allEleman.Size = new System.Drawing.Size(678, 305);
            this.allEleman.TabIndex = 94;
            // 
            // ProductsDetailesWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(684, 311);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Users_viewGuide);
            this.Controls.Add(this.ProductDescription);
            this.Controls.Add(this.ProductName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ProductID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.IDGuide);
            this.Controls.Add(this.ClosePage);
            this.Controls.Add(this.ProductImage);
            this.Controls.Add(this.allEleman);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductsDetailesWidget";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductsDetailesWidget";
            this.Load += new System.EventHandler(this.ProductsDetailesWidget_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ProductImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox ProductImage;
        private PictureBox ClosePage;
        private Label IDGuide;
        private Label label7;
        private Label ProductID;
        private Label ProductName;
        private Label label3;
        private TextBox ProductDescription;
        private Label Users_viewGuide;
        private Label label5;
        private Panel allEleman;
    }
}