﻿using CoffeeShop.Widget.Orders;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Custoemrs
{
    public partial class CustomerOrderWidget : UserControl
    {
        public CustomerOrderWidget()
        {
            InitializeComponent();
        }

        DataTable Table = new DataTable();
        private void OrderWidget_Load(object sender, EventArgs e)
        {
            AddDataToProductsTable();
        }
        private async void AddDataToProductsTable()
        {
            string Selecting_Orders = "http://localhost:5000/ShowCustomerOrders";

            Table.Columns.Add("ردیف", typeof(string));
            Table.Columns.Add("شماره‌فاکتور", typeof(string));
            Table.Columns.Add("خریدار", typeof(string));
            Table.Columns.Add("تاریخ‌ثبت", typeof(string));
            Table.Columns.Add("جمع‌کل", typeof(string));
            Table.Columns.Add("شیوه‌پرداخت", typeof(string));
            Table.Columns.Add("وضعیت", typeof(string));

            Orders_view.DataSource = Table;
            Orders_view.Columns[0].Width = 50;
            Orders_view.Columns[1].Width = 100;
            Orders_view.Columns[2].Width = 250;
            Orders_view.Columns[3].Width = 100;

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("CustomerID", userLoggedIn.CustomerID.ToString()));

            HttpContent content = new FormUrlEncodedContent(postData);
            var response = client.PostAsync(Selecting_Orders, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<OrdersClass> All_Orders = JsonConvert.DeserializeObject<List<OrdersClass>>(Result);

            for (int i = 0; i < All_Orders.Count; i++)
            {
                Table.Rows.Add(i + 1, All_Orders[i].OrderID, All_Orders[i].FullName, All_Orders[i].OrderDate, All_Orders[i].TotalAmount, All_Orders[i].PaymentType, All_Orders[i].Status);
            }


            for (int i = 0; i < Orders_view.Rows.Count - 1; i++)
            {
                if (Orders_view.Rows[i].Cells["وضعیت"].Value.ToString() == "تایید")
                {
                    Orders_view.Rows[i].DefaultCellStyle.BackColor = Color.Green;
                }
            }

            if (Table.Rows.Count == 0) {
                EmptyBasket_Panel.Visible = true;
            }
            // UseWaitCursor is OFF:
            //Users_view.UseWaitCursor = false;
        }

        private void Orders_view_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (Orders_view.SelectedRows.Count == 1)
            {
                FactorClass.OrderID = Orders_view.CurrentRow?.Cells[1]?.Value?.ToString() ?? "default value";
                FactorClass.CustomerOrder = Orders_view.CurrentRow?.Cells[2]?.Value?.ToString() ?? "default value";
                FactorClass.OrderDate = Orders_view.CurrentRow?.Cells[3]?.Value?.ToString() ?? "default value";
                FactorClass.TotalFac = Orders_view.CurrentRow?.Cells[4]?.Value?.ToString() ?? "default value";

                OrderDetailsWidget orderDetailsWidgetForm = new OrderDetailsWidget();
                orderDetailsWidgetForm.Show();
            }
        }

        private void Orders_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Orders_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        private void Orders_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Orders_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
