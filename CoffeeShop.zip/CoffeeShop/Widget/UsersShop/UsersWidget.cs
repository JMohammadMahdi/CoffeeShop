﻿using CoffeeShop.Widget.Users;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace CoffeeShop.Widget
{
    public partial class UsersWidget : UserControl
    {
        public UsersWidget()
        {
            InitializeComponent();
        }
        DataTable Table = new DataTable();
        private void UsersWidget_Load(object sender, EventArgs e)
        {
            AddDataToCustomersTable();
        }
        private async void AddDataToCustomersTable()
        {
            string url = "http://localhost:5000/GetCustomers";

            Table.Columns.Add("کد‌کابری", typeof(string));
            Table.Columns.Add("نام", typeof(string));
            Table.Columns.Add("نام‌خانوادگی", typeof(string));
            Table.Columns.Add("ایمیل", typeof(string));
            Table.Columns.Add("تلفن", typeof(string));
            Table.Columns.Add("آدرس", typeof(string));
            Table.Columns.Add("استان", typeof(string));
            Table.Columns.Add("کشور", typeof(string));
            Table.Columns.Add("کدپستی", typeof(string));
            Table.Columns.Add("رمزعبور", typeof(string));

            Users_view.DataSource = Table;
            Users_view.Columns["رمزعبور"].Visible = false;

            HttpClient client = new HttpClient();

            // Get: 
            string Customers = await client.GetStringAsync(url);

            List<CustomersClass> All_Customers = JsonConvert.DeserializeObject<List<CustomersClass>>(Customers);

            for (int i = 0; i < All_Customers.Count; i++) {
                Table.Rows.Add(All_Customers[i].CustomerID, All_Customers[i].FirstName, All_Customers[i].LastName, All_Customers[i].Email, All_Customers[i].PhoneNumber, All_Customers[i].Address, All_Customers[i].City, All_Customers[i].State, All_Customers[i].PostalCode, All_Customers[i].Password);
            }
        }
        private void Users_view_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Users_view.ClearSelection(); // clear previous selections
                Users_view.Rows[e.RowIndex].Selected = true; // select the clicked row

                ContextMenuStrip recordMenu = new ContextMenuStrip();
                ToolStripMenuItem addItem = new ToolStripMenuItem("افزودن");
                ToolStripMenuItem editItem = new ToolStripMenuItem("ویرایش");
                ToolStripMenuItem deleteItem = new ToolStripMenuItem("حذف");

                addItem.Font = new Font("IRANSansXFaNum", 9);
                editItem.Font = new Font("IRANSansXFaNum", 9);
                deleteItem.Font = new Font("IRANSansXFaNum", 9);

                addItem.Click += new EventHandler(addItem_Click);
                editItem.Click += new EventHandler(editItem_Click);
                deleteItem.Click += new EventHandler(deleteItem_Click);

                recordMenu.Items.Add(editItem);
                recordMenu.Items.Add(deleteItem);
                recordMenu.Items.Add(addItem);

                recordMenu.Show(Cursor.Position);
            }
        }

        private void editItem_Click(object sender, EventArgs e)
        {
            if (Users_view.SelectedRows.Count == 1)
            {
                EditCustomers.CustomerID = Users_view.CurrentRow?.Cells[0]?.Value?.ToString() ?? "default value";
                EditCustomers.FirstName = Users_view.CurrentRow?.Cells[1]?.Value?.ToString() ?? "default value";
                EditCustomers.LastName = Users_view.CurrentRow?.Cells[2]?.Value?.ToString() ?? "default value";
                EditCustomers.Email = Users_view.CurrentRow?.Cells[3]?.Value?.ToString() ?? "default value";
                EditCustomers.PhoneNumber = Users_view.CurrentRow?.Cells[4]?.Value?.ToString() ?? "default value";
                EditCustomers.Address = Users_view.CurrentRow?.Cells[5]?.Value?.ToString() ?? "default value";
                EditCustomers.City = Users_view.CurrentRow?.Cells[6]?.Value?.ToString() ?? "default value";
                EditCustomers.State = Users_view.CurrentRow?.Cells[7]?.Value?.ToString() ?? "default value";
                EditCustomers.PostalCode = Users_view.CurrentRow?.Cells[8]?.Value?.ToString() ?? "default value";
                EditCustomers.Password = Users_view.CurrentRow?.Cells[9]?.Value?.ToString() ?? "default value";

                EditUsersPopup EditUsersWidgetForm = new EditUsersPopup();
                EditUsersWidgetForm.Show();
            }
        }
        private void addItem_Click(object sender, EventArgs e)
        {
            AddUsersPopup addUsersPopupFrom = new AddUsersPopup();
            addUsersPopupFrom.Show();
        }

        private void deleteItem_Click(object sender, EventArgs e)
        {
            if (Users_view.SelectedRows.Count == 1)
            {
                string CustomerID = Users_view.CurrentRow?.Cells[0]?.Value?.ToString() ?? "default value";

                DialogResult dialogResult = MessageBox.Show(this, $"آیا مایل به حذف حساب کابری با کد {CustomerID} هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                if (dialogResult == DialogResult.Yes)
                {
                    string url = $"http://localhost:5000/DeleteCustomers/{CustomerID}";

                    HttpClient client = new HttpClient();
                    var response = client.DeleteAsync(url).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        // remove row in table:
                        int rowIndex = Users_view.SelectedRows[0].Index;
                        Users_view.Rows.RemoveAt(rowIndex);

                        string textWarning = "عملیات با موفقیت انجام شد" + Environment.NewLine + $"دقت داشته باشید کد کابری {CustomerID} قابل استفاده نیست";
                        MessageBox.Show(this, textWarning, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                    else {
                        MessageBox.Show(this, "آیا مایل به حذف حساب کابری با کداختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                    }
                }
            }
        }

        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("table", "users"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<CustomersClass> ResultObject = JsonConvert.DeserializeObject<List<CustomersClass>>(Result);

            Table.Clear();
            for (int i = 0; i < ResultObject.Count; i++) {
                Table.Rows.Add(ResultObject[i].CustomerID, ResultObject[i].FirstName, ResultObject[i].LastName, ResultObject[i].Email, ResultObject[i].PhoneNumber, ResultObject[i].Address, ResultObject[i].City, ResultObject[i].State, ResultObject[i].PostalCode, ResultObject[i].Password);
            }
        }

        private void SearchInTable_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search.PerformClick();
            }
        }

        private void Users_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Users_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        private void Users_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Users_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
