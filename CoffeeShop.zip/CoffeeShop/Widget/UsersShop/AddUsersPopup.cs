﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.Widget.Users
{
    public partial class AddUsersPopup : Form
    {
        public AddUsersPopup()
        {
            InitializeComponent();
        }
        private void AddUsersPopup_Load(object sender, EventArgs e)
        {
            string[] stateReaded = File.ReadAllLines(Settings.PathFileStates);
            foreach (var File in stateReaded)
                States.Items.Add(File);
        }
        private void SaveData_Click(object sender, EventArgs e)
        {
            SendDataForSignUp(Firstname.Text, Lastname.Text, EmailBox.Text, Phone.Text, address.Text, States.Text.ToString(), "ایران", postalCode.Text, password.Text);
        }
        private void SendDataForSignUp(string FirstName, string LastName, string Email, string PhoneNumber, string Address, string City, string State, string PostalCode, string Password)
        {
            int CustomerID = Convert.ToInt32(File.ReadAllText(Settings.pathFileCustomerCode)) + 1;
            string url = "http://localhost:5000/Add_user";

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("CustomerID", CustomerID.ToString()));
            postData.Add(new KeyValuePair<string, string>("FirstName", FirstName));
            postData.Add(new KeyValuePair<string, string>("LastName", LastName));
            postData.Add(new KeyValuePair<string, string>("Email", Email));
            postData.Add(new KeyValuePair<string, string>("PhoneNumber", PhoneNumber));
            postData.Add(new KeyValuePair<string, string>("Address", Address));
            postData.Add(new KeyValuePair<string, string>("City", City));
            postData.Add(new KeyValuePair<string, string>("State", State));
            postData.Add(new KeyValuePair<string, string>("PostalCode", PostalCode));
            postData.Add(new KeyValuePair<string, string>("Password", Password));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                File.WriteAllText(Settings.pathFileCustomerCode, CustomerID.ToString());

                // remove text in text boxes:
                Firstname.Text = Lastname.Text = EmailBox.Text = Phone.Text = States.Text = address.Text = postalCode.Text = password.Text = null;

                DialogResult dialogResult = MessageBox.Show($"حساب کاربری شما با کد کاربری {CustomerID} با موفقیت ایجاد شد", "اطلاعیه", MessageBoxButtons.OK);
                if (dialogResult == DialogResult.OK)
                {
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClosePage_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
