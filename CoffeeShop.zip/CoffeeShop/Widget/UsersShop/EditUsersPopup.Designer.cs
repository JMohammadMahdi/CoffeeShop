﻿namespace CoffeeShop.Widget.Users
{
    partial class EditUsersPopup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditUsersPopup));
            this.IDGuide = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SaveData = new System.Windows.Forms.Button();
            this.ID = new System.Windows.Forms.TextBox();
            this.postalCode = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PostalCodeGuide = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.EmailGuide = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.EmailBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.PasswordGuide = new System.Windows.Forms.Label();
            this.Firstname = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.FirstnameGuide = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Lastname = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.LastnameGuide = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.AddressGuide = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.TextBox();
            this.States = new System.Windows.Forms.ComboBox();
            this.PhoneNumberGuide = new System.Windows.Forms.Label();
            this.StatesGuide = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ClosePage = new System.Windows.Forms.PictureBox();
            this.Users_viewGuide = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // IDGuide
            // 
            this.IDGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IDGuide.AutoSize = true;
            this.IDGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.IDGuide.Location = new System.Drawing.Point(360, 41);
            this.IDGuide.Name = "IDGuide";
            this.IDGuide.Size = new System.Drawing.Size(65, 24);
            this.IDGuide.TabIndex = 70;
            this.IDGuide.Text = "کدکاربری";
            this.IDGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.SaveData);
            this.panel1.Controls.Add(this.IDGuide);
            this.panel1.Controls.Add(this.ID);
            this.panel1.Controls.Add(this.postalCode);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.PostalCodeGuide);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.EmailGuide);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.EmailBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.PasswordGuide);
            this.panel1.Controls.Add(this.Firstname);
            this.panel1.Controls.Add(this.password);
            this.panel1.Controls.Add(this.FirstnameGuide);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.Lastname);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.LastnameGuide);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.address);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.AddressGuide);
            this.panel1.Controls.Add(this.Phone);
            this.panel1.Controls.Add(this.States);
            this.panel1.Controls.Add(this.PhoneNumberGuide);
            this.panel1.Controls.Add(this.StatesGuide);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(91, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(502, 637);
            this.panel1.TabIndex = 70;
            // 
            // SaveData
            // 
            this.SaveData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(12)))), ((int)(((byte)(5)))));
            this.SaveData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(184)))), ((int)(((byte)(99)))));
            this.SaveData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveData.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SaveData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.SaveData.Location = new System.Drawing.Point(146, 593);
            this.SaveData.Name = "SaveData";
            this.SaveData.Size = new System.Drawing.Size(208, 41);
            this.SaveData.TabIndex = 0;
            this.SaveData.Text = "ذخیره اطلاعات";
            this.SaveData.UseVisualStyleBackColor = false;
            this.SaveData.Click += new System.EventHandler(this.SaveData_Click);
            // 
            // ID
            // 
            this.ID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ID.Enabled = false;
            this.ID.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ID.Location = new System.Drawing.Point(101, 38);
            this.ID.Name = "ID";
            this.ID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ID.Size = new System.Drawing.Size(248, 31);
            this.ID.TabIndex = 69;
            // 
            // postalCode
            // 
            this.postalCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.postalCode.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.postalCode.Location = new System.Drawing.Point(101, 447);
            this.postalCode.Name = "postalCode";
            this.postalCode.PlaceholderText = " شامل 10رقم";
            this.postalCode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.postalCode.Size = new System.Drawing.Size(248, 31);
            this.postalCode.TabIndex = 50;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::CoffeeShop.Properties.Resources.user_two;
            this.pictureBox2.Location = new System.Drawing.Point(470, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // PostalCodeGuide
            // 
            this.PostalCodeGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PostalCodeGuide.AutoSize = true;
            this.PostalCodeGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PostalCodeGuide.Location = new System.Drawing.Point(360, 450);
            this.PostalCodeGuide.Name = "PostalCodeGuide";
            this.PostalCodeGuide.Size = new System.Drawing.Size(62, 24);
            this.PostalCodeGuide.TabIndex = 68;
            this.PostalCodeGuide.Text = "کد‌پستی";
            this.PostalCodeGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 20);
            this.label1.TabIndex = 41;
            this.label1.Text = "_________________________________________________________";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EmailGuide
            // 
            this.EmailGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EmailGuide.AutoSize = true;
            this.EmailGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EmailGuide.Location = new System.Drawing.Point(360, 184);
            this.EmailGuide.Name = "EmailGuide";
            this.EmailGuide.Size = new System.Drawing.Size(46, 24);
            this.EmailGuide.TabIndex = 67;
            this.EmailGuide.Text = "ایمیل";
            this.EmailGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(3, 223);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(351, 20);
            this.label5.TabIndex = 54;
            this.label5.Text = "_________________________________________________________";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EmailBox
            // 
            this.EmailBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EmailBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.EmailBox.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EmailBox.Location = new System.Drawing.Point(101, 181);
            this.EmailBox.Name = "EmailBox";
            this.EmailBox.PlaceholderText = " gmail.com@...";
            this.EmailBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.EmailBox.Size = new System.Drawing.Size(248, 31);
            this.EmailBox.TabIndex = 46;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(360, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 24);
            this.label2.TabIndex = 43;
            this.label2.Text = "اطلاعات کاربری";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PasswordGuide
            // 
            this.PasswordGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordGuide.AutoSize = true;
            this.PasswordGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordGuide.Location = new System.Drawing.Point(360, 530);
            this.PasswordGuide.Name = "PasswordGuide";
            this.PasswordGuide.Size = new System.Drawing.Size(62, 24);
            this.PasswordGuide.TabIndex = 66;
            this.PasswordGuide.Text = "رمز عبور";
            this.PasswordGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Firstname
            // 
            this.Firstname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Firstname.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Firstname.Location = new System.Drawing.Point(101, 87);
            this.Firstname.Name = "Firstname";
            this.Firstname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Firstname.Size = new System.Drawing.Size(248, 31);
            this.Firstname.TabIndex = 42;
            // 
            // password
            // 
            this.password.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.password.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.password.Location = new System.Drawing.Point(101, 527);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.PlaceholderText = " شامل حداقل 4کاراکتر";
            this.password.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.password.Size = new System.Drawing.Size(248, 31);
            this.password.TabIndex = 52;
            // 
            // FirstnameGuide
            // 
            this.FirstnameGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FirstnameGuide.AutoSize = true;
            this.FirstnameGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FirstnameGuide.Location = new System.Drawing.Point(360, 90);
            this.FirstnameGuide.Name = "FirstnameGuide";
            this.FirstnameGuide.Size = new System.Drawing.Size(28, 24);
            this.FirstnameGuide.TabIndex = 51;
            this.FirstnameGuide.Text = "نام";
            this.FirstnameGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::CoffeeShop.Properties.Resources.shield;
            this.pictureBox5.Location = new System.Drawing.Point(470, 485);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 32);
            this.pictureBox5.TabIndex = 65;
            this.pictureBox5.TabStop = false;
            // 
            // Lastname
            // 
            this.Lastname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lastname.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Lastname.Location = new System.Drawing.Point(101, 135);
            this.Lastname.Name = "Lastname";
            this.Lastname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Lastname.Size = new System.Drawing.Size(248, 31);
            this.Lastname.TabIndex = 44;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(383, 489);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 24);
            this.label7.TabIndex = 64;
            this.label7.Text = "احراز هویت";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LastnameGuide
            // 
            this.LastnameGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LastnameGuide.AutoSize = true;
            this.LastnameGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LastnameGuide.Location = new System.Drawing.Point(360, 138);
            this.LastnameGuide.Name = "LastnameGuide";
            this.LastnameGuide.Size = new System.Drawing.Size(91, 24);
            this.LastnameGuide.TabIndex = 53;
            this.LastnameGuide.Text = "نام خانوادگی";
            this.LastnameGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(3, 491);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(375, 20);
            this.label8.TabIndex = 63;
            this.label8.Text = "_____________________________________________________________";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(360, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 24);
            this.label4.TabIndex = 55;
            this.label4.Text = "اطلاعات تماس";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // address
            // 
            this.address.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.address.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.address.Location = new System.Drawing.Point(101, 399);
            this.address.Name = "address";
            this.address.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.address.Size = new System.Drawing.Size(248, 31);
            this.address.TabIndex = 49;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::CoffeeShop.Properties.Resources.phone_call;
            this.pictureBox3.Location = new System.Drawing.Point(470, 217);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 32);
            this.pictureBox3.TabIndex = 56;
            this.pictureBox3.TabStop = false;
            // 
            // AddressGuide
            // 
            this.AddressGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressGuide.AutoSize = true;
            this.AddressGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddressGuide.Location = new System.Drawing.Point(360, 402);
            this.AddressGuide.Name = "AddressGuide";
            this.AddressGuide.Size = new System.Drawing.Size(46, 24);
            this.AddressGuide.TabIndex = 62;
            this.AddressGuide.Text = "آدرس";
            this.AddressGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Phone
            // 
            this.Phone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Phone.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Phone.Location = new System.Drawing.Point(101, 258);
            this.Phone.Name = "Phone";
            this.Phone.PlaceholderText = " 09123456789";
            this.Phone.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Phone.Size = new System.Drawing.Size(248, 31);
            this.Phone.TabIndex = 47;
            // 
            // States
            // 
            this.States.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.States.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.States.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.States.FormattingEnabled = true;
            this.States.ItemHeight = 24;
            this.States.Location = new System.Drawing.Point(101, 350);
            this.States.Name = "States";
            this.States.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.States.Size = new System.Drawing.Size(248, 32);
            this.States.TabIndex = 48;
            // 
            // PhoneNumberGuide
            // 
            this.PhoneNumberGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PhoneNumberGuide.AutoSize = true;
            this.PhoneNumberGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PhoneNumberGuide.Location = new System.Drawing.Point(360, 261);
            this.PhoneNumberGuide.Name = "PhoneNumberGuide";
            this.PhoneNumberGuide.Size = new System.Drawing.Size(85, 24);
            this.PhoneNumberGuide.TabIndex = 57;
            this.PhoneNumberGuide.Text = "تلفن تماس";
            this.PhoneNumberGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // StatesGuide
            // 
            this.StatesGuide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.StatesGuide.AutoSize = true;
            this.StatesGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StatesGuide.Location = new System.Drawing.Point(360, 354);
            this.StatesGuide.Name = "StatesGuide";
            this.StatesGuide.Size = new System.Drawing.Size(47, 24);
            this.StatesGuide.TabIndex = 61;
            this.StatesGuide.Text = "استان";
            this.StatesGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(3, 308);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(351, 20);
            this.label6.TabIndex = 58;
            this.label6.Text = "_________________________________________________________";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::CoffeeShop.Properties.Resources.placeholder;
            this.pictureBox4.Location = new System.Drawing.Point(470, 302);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(32, 32);
            this.pictureBox4.TabIndex = 60;
            this.pictureBox4.TabStop = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(360, 306);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 24);
            this.label3.TabIndex = 59;
            this.label3.Text = "موقعیت مکانی";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ClosePage
            // 
            this.ClosePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClosePage.Image = ((System.Drawing.Image)(resources.GetObject("ClosePage.Image")));
            this.ClosePage.Location = new System.Drawing.Point(653, 9);
            this.ClosePage.Name = "ClosePage";
            this.ClosePage.Size = new System.Drawing.Size(32, 32);
            this.ClosePage.TabIndex = 83;
            this.ClosePage.TabStop = false;
            this.ClosePage.Click += new System.EventHandler(this.ClosePage_Click);
            // 
            // Users_viewGuide
            // 
            this.Users_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Users_viewGuide.AutoSize = true;
            this.Users_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Users_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Users_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Users_viewGuide.Location = new System.Drawing.Point(274, 14);
            this.Users_viewGuide.Name = "Users_viewGuide";
            this.Users_viewGuide.Size = new System.Drawing.Size(137, 28);
            this.Users_viewGuide.TabIndex = 82;
            this.Users_viewGuide.Text = "ویرایش اطلاعات";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.ClosePage);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(696, 766);
            this.panel2.TabIndex = 89;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label9.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label9.Location = new System.Drawing.Point(936, 704);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 28);
            this.label9.TabIndex = 85;
            this.label9.Text = "ویرایش محصول";
            // 
            // EditUsersPopup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(700, 770);
            this.Controls.Add(this.Users_viewGuide);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(700, 770);
            this.MinimumSize = new System.Drawing.Size(700, 770);
            this.Name = "EditUsersPopup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditUsersPopup";
            this.Load += new System.EventHandler(this.EditUsersPopup_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePage)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label IDGuide;
        private Panel panel1;
        private TextBox ID;
        private TextBox postalCode;
        private PictureBox pictureBox2;
        private Label PostalCodeGuide;
        private Label label1;
        private Label EmailGuide;
        private Label label5;
        private TextBox EmailBox;
        private Label label2;
        private Label PasswordGuide;
        private TextBox Firstname;
        private TextBox password;
        private Label FirstnameGuide;
        private PictureBox pictureBox5;
        private TextBox Lastname;
        private Label label7;
        private Label LastnameGuide;
        private Label label8;
        private Label label4;
        private TextBox address;
        private PictureBox pictureBox3;
        private Label AddressGuide;
        private TextBox Phone;
        private ComboBox States;
        private Label PhoneNumberGuide;
        private Label StatesGuide;
        private Label label6;
        private PictureBox pictureBox4;
        private Label label3;
        private PictureBox ClosePage;
        private Label Users_viewGuide;
        private Button SaveData;
        private Panel panel2;
        private Label label9;
    }
}