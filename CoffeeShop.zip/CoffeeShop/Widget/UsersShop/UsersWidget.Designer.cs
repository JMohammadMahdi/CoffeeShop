﻿namespace CoffeeShop.Widget
{
    partial class UsersWidget
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Users_viewGuide = new System.Windows.Forms.Label();
            this.Users_view = new System.Windows.Forms.DataGridView();
            this.SearchInTable = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Users_view)).BeginInit();
            this.SuspendLayout();
            // 
            // Users_viewGuide
            // 
            this.Users_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Users_viewGuide.AutoSize = true;
            this.Users_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Users_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Users_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Users_viewGuide.Location = new System.Drawing.Point(781, 30);
            this.Users_viewGuide.Name = "Users_viewGuide";
            this.Users_viewGuide.Size = new System.Drawing.Size(146, 28);
            this.Users_viewGuide.TabIndex = 79;
            this.Users_viewGuide.Text = "مشتریان فروشگاه";
            // 
            // Users_view
            // 
            this.Users_view.AllowUserToAddRows = false;
            this.Users_view.AllowUserToDeleteRows = false;
            this.Users_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Users_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Users_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Users_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Users_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Users_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Users_view.DefaultCellStyle = dataGridViewCellStyle2;
            this.Users_view.Location = new System.Drawing.Point(14, 67);
            this.Users_view.Name = "Users_view";
            this.Users_view.ReadOnly = true;
            this.Users_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Users_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Users_view.RowTemplate.Height = 25;
            this.Users_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Users_view.Size = new System.Drawing.Size(913, 398);
            this.Users_view.TabIndex = 83;
            this.Users_view.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Users_view_CellMouseDown);
            this.Users_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Users_view_RowPostPaint);
            this.Users_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Users_view_RowPrePaint);
            // 
            // SearchInTable
            // 
            this.SearchInTable.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SearchInTable.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SearchInTable.Location = new System.Drawing.Point(244, 26);
            this.SearchInTable.Multiline = true;
            this.SearchInTable.Name = "SearchInTable";
            this.SearchInTable.PlaceholderText = "  کاربر مورد نظر را جست و جو کنید";
            this.SearchInTable.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.SearchInTable.Size = new System.Drawing.Size(451, 30);
            this.SearchInTable.TabIndex = 84;
            this.SearchInTable.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SearchInTable_KeyDown);
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Window;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Image = global::CoffeeShop.Properties.Resources.search;
            this.Search.Location = new System.Drawing.Point(250, 28);
            this.Search.Margin = new System.Windows.Forms.Padding(0);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(25, 25);
            this.Search.TabIndex = 85;
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // UsersWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Controls.Add(this.Search);
            this.Controls.Add(this.SearchInTable);
            this.Controls.Add(this.Users_view);
            this.Controls.Add(this.Users_viewGuide);
            this.Name = "UsersWidget";
            this.Size = new System.Drawing.Size(939, 489);
            this.Load += new System.EventHandler(this.UsersWidget_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Users_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label Users_viewGuide;
        private DataGridView Users_view;
        private TextBox SearchInTable;
        private Button Search;
    }
}
