﻿using CoffeeShop.Widget.Products;
using CoffeeShop.Widget;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using CoffeeShop.Widget.Custoemrs;
using Newtonsoft.Json.Linq;
using System.Linq.Expressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using CoffeeShop.Widget.Custoemrs.Product_Detailes;
using CoffeeShop.Widget.Payment;
using System.Reflection;

namespace CoffeeShop
{
    public partial class Shop : Form
    {
        public Shop()
        {
            InitializeComponent();
        }
        string TodayDate = GetPersianDate(DateTime.Now);

        DataTable Products = new DataTable();
        DataTable OrderDetails = new DataTable();

        string Pages = "default";
        private void Shop_Load(object sender, EventArgs e)
        {
            if (userLoggedIn.FirstName != String.Empty && userLoggedIn.LastName != String.Empty)
                Username.Text = $"{userLoggedIn.FirstName} {userLoggedIn.LastName}";
            else
                Username.Text = "نام کاربری";

            string[] stateReaded = File.ReadAllLines(Settings.PathFileCategories);

            P_Category.Items.Add("همه‌ دسته‌ها");
            foreach (var File in stateReaded)
                if (File != "")
                    P_Category.Items.Add(File);

            P_Category.SelectedIndex = 0;

            // add date: 
            Date.Text = TodayDate;
            Pages = "default";

            AddDataToCartTable();
            AddDataToProductsTable();
        }
        private async void AddDataToProductsTable()
        {
            string Selecting_Products = "http://localhost:5000/GetProducts";

            Products.Columns.Add("کدمحصول", typeof(string));
            Products.Columns.Add("نام‌محصول", typeof(string));
            Products.Columns.Add("توضیحات", typeof(string));
            Products.Columns.Add("قیمت", typeof(string));
            Products.Columns.Add("آدرس تصویر", typeof(string));
            Products.Columns.Add("کددسته‌بندی", typeof(string));
            Products.Columns.Add("نام‌دسته‌بندی", typeof(string));

            Products_view.DataSource = Products;
            Products_view.Columns["آدرس تصویر"].Visible = false;
            Products_view.Columns["کددسته‌بندی"].Visible = false;
            Products_view.Columns["توضیحات"].Visible = false;

            Products_view.Columns["کدمحصول"].Width = 50;

            Products_view.Width = 1005;
            Products_view.Location = new System.Drawing.Point(0, 33);
            SaveData.Location = new System.Drawing.Point(398, 438);
            SaveData.Enabled = false;

            Products_view.Columns["قیمت"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);

            HttpClient client = new HttpClient();

            // Get: 
            string Result = await client.GetStringAsync(Selecting_Products);

            List<ProductsClass> All_Products = JsonConvert.DeserializeObject<List<ProductsClass>>(Result);

            for (int i = 0; i < All_Products.Count; i++) {
                Products.Rows.Add(All_Products[i].ProductID, All_Products[i].ProductName, All_Products[i].Description, All_Products[i].Price, All_Products[i].Image, All_Products[i].CategoryID, All_Products[i].CategoryName);
            }
        }
        private void AddDataToCartTable()
        {
            OrderDetails.Columns.Add("کدمحصول", typeof(string));
            OrderDetails.Columns.Add("نام‌محصول", typeof(string));
            OrderDetails.Columns.Add("تعداد", typeof(string));
            OrderDetails.Columns.Add("قیمت", typeof(string));
            OrderDetails.Columns.Add("مبلغ‌کل", typeof(string));

            Cart_view.DataSource = OrderDetails;
            Cart_view.Columns["کدمحصول"].Visible = false;
            Cart_view.Columns["تعداد"].Width = 50;

            Cart_view.Columns["قیمت"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);
            Cart_view.Columns["مبلغ‌کل"].DefaultCellStyle.Font = new Font("IRANSansXFaNum", 8, FontStyle.Bold);
        }
        private void UpdateTotalAmount()
        {
            int totalAmount = 0;
            foreach (DataGridViewRow row in Cart_view.Rows)
            {
                if (row.Cells["مبلغ‌کل"].Value != null && int.TryParse(row.Cells["مبلغ‌کل"].Value.ToString(), out int price))
                {
                    totalAmount += price;
                }
            }
            TotalAmount.Text = totalAmount.ToString();
        }
        private void Products_view_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // دریافت سطر انتخاب شده در جدول محصولات
            DataGridViewRow selectedRow = Products_view.Rows[e.RowIndex];

            // چک کردن مقدار سلول "نام‌محصول" انتخاب شده که خالی نباشد
            if (selectedRow.Cells["نام‌محصول"].Value != null)
            {
                string productName = selectedRow.Cells["نام‌محصول"].Value.ToString();
                decimal productPrice = Convert.ToDecimal(selectedRow.Cells["قیمت"].Value);

                // بررسی کردن اینکه آیا محصول قبلاً به سبد خرید اضافه شده است یا خیر
                DataRow[] existingProductRows = OrderDetails.Select("نام‌محصول = '" + productName + "'");
                if (existingProductRows.Length > 0)
                {
                    // اگر محصول قبلاً به سبد خرید اضافه شده است، تعداد آن را یکی افزایش دهید و مبلغ کل را با توجه به تعداد جدید محاسبه کنید
                    int newQuantity = Convert.ToInt32(existingProductRows[0]["تعداد"]) + 1;
                    decimal newTotalPrice = productPrice * newQuantity;
                    existingProductRows[0]["تعداد"] = newQuantity;
                    existingProductRows[0]["مبلغ‌کل"] = newTotalPrice.ToString();
                }
                else
                {
                    // اگر محصول قبلاً به سبد خرید اضافه نشده است، به جدول OrderDetails اضافه شود
                    DataRow newRow = OrderDetails.NewRow();
                    newRow["کدمحصول"] = selectedRow.Cells["کدمحصول"].Value.ToString(); // افزودن کد محصول به جدول سبد خرید
                    newRow["نام‌محصول"] = productName;
                    newRow["تعداد"] = 1;
                    newRow["قیمت"] = productPrice.ToString();
                    newRow["مبلغ‌کل"] = productPrice.ToString();
                    OrderDetails.Rows.Add(newRow);
                }
            }
            if (OrderDetails.Rows.Count > 0)
            {
                // size & location:
                Products_view.Width = 648;
                Products_view.Location = new System.Drawing.Point(357, 33);
                SaveData.Location = new System.Drawing.Point(577, 438);
                SaveData.Enabled = true;
                //show tables:
                Cart_viewGuide.Visible = true;
                Cart_view.Visible = true;
                RemoveCount.Visible = true;

                Products_view.AutoResizeColumn(0, DataGridViewAutoSizeColumnMode.AllCells);
            }
            UpdateTotalAmount();
        }


        private void RemoveCount_Click(object sender, EventArgs e)
        {
            // دریافت ردیف انتخاب شده از جدول Cart_view
            int rowIndex = Cart_view.SelectedRows[0].Index;

            // دریافت مقدار تعداد محصول مورد نظر از ستون "تعداد"
            int quantity = Convert.ToInt32(Cart_view.Rows[rowIndex].Cells["تعداد"].Value);

            // کاهش مقدار تعداد محصول مورد نظر
            quantity--;

            // اگر تعداد محصول برابر با صفر شد، ردیف مورد نظر را از جدول حذف می‌کنیم
            if (quantity == 0)
            {
                Cart_view.Rows.RemoveAt(rowIndex);
            }
            // در غیر این صورت، مقدار تعداد را در جدول به روزرسانی می‌کنیم و مبلغ کل را مجدداً محاسبه کرده و در جدول قرار می‌دهیم
            else
            {
                Cart_view.Rows[rowIndex].Cells["تعداد"].Value = quantity;

                // دریافت مقدار قیمت محصول از ستون "قیمت"
                int price = Convert.ToInt32(Cart_view.Rows[rowIndex].Cells["قیمت"].Value);

                // محاسبه مبلغ کل با توجه به تعداد محصول
                int totalPrice = price * quantity;

                // قرار دادن مبلغ کل در ستون "مبلغ"
                Cart_view.Rows[rowIndex].Cells["مبلغ‌کل"].Value = totalPrice.ToString();
            }

            if (OrderDetails.Rows.Count == 0)
            {
                // size & location:
                Products_view.Width = 1005;
                Products_view.Location = new System.Drawing.Point(0, 33);
                SaveData.Location = new System.Drawing.Point(398, 438);
                SaveData.Enabled = false;

                //show tables:
                Cart_viewGuide.Visible = false;
                Cart_view.Visible = false;
                RemoveCount.Visible = false;

                Products_view.Columns["کدمحصول"].Width = 50;
            }
            UpdateTotalAmount();
        }
        private void RemoveCount_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(this, "آیا مایل به خالی کردن سبدخرید خود هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            if (dialogResult == DialogResult.Yes)
            {
                OrderDetails.Rows.Clear();

                // size & location:
                Products_view.Width = 1005;
                Products_view.Location = new System.Drawing.Point(0, 33);
                SaveData.Location = new System.Drawing.Point(398, 438);
                SaveData.Enabled = false;

                //show tables:
                Cart_viewGuide.Visible = false;
                Cart_view.Visible = false;
                RemoveCount.Visible = false;
            }
            UpdateTotalAmount();
        }
        private void TotalAmount_TextChanged(object sender, EventArgs e)
        {
            if (TotalAmount.Text != string.Empty)
            {
                TotalAmount.Text = string.Format("{0:N0}", double.Parse(TotalAmount.Text.Replace(",", "")));
                TotalAmount.Select(TotalAmount.TextLength, 0);
            }
        }
        public static string GetPersianDate(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            int year = pc.GetYear(date);
            int month = pc.GetMonth(date);
            int day = pc.GetDayOfMonth(date);
            string persianDate = $"{year:0000}/{month:00}/{day:00}";

            return persianDate;
        }
        private async void SaveData_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(this, "آیا مایل به ثبت سفارش خود هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            if (dialogResult == DialogResult.Yes)
            {
                PaymentPage.ID = Convert.ToInt32(File.ReadAllText(Settings.pathFileFactorID)) + 1;

                List<RowData> rowsData = new List<RowData>();
                foreach (DataGridViewRow row in Cart_view.Rows)
                {
                    if (row.Cells["تعداد"].Value != null)
                    {
                        rowsData.Add(new RowData
                        {
                            ID = row.Cells["کدمحصول"]?.Value?.ToString() ?? "default value",
                            Name = row.Cells["نام‌محصول"]?.Value?.ToString() ?? "default value",
                            Count = row.Cells["تعداد"]?.Value?.ToString() ?? "default value",
                            Price = row.Cells["قیمت"]?.Value?.ToString() ?? "default value",
                            TotalAmount = row.Cells["مبلغ‌کل"]?.Value?.ToString() ?? "default value"
                        });
                    }
                }

                PaymentPage.CartData = rowsData;
                PaymentPage.Total = TotalAmount.Text.Replace(",", "");

                PaymentPageWidget paymentPageWidgetForm = new PaymentPageWidget();
                paymentPageWidgetForm.Show();
            }
        }
        private void RecentOrders_Click(object sender, EventArgs e)
        {
            CustomerOrderWidget customerOrderWidgetForm = new CustomerOrderWidget();

            Default_Page.Visible = false;

            if (this.Controls.Contains(customerOrderWidgetForm)) {
                this.Controls.Remove(customerOrderWidgetForm);
            }

            customerOrderWidgetForm.Location = new Point(190, 71);
            this.Controls.Add(customerOrderWidgetForm);
            customerOrderWidgetForm.BringToFront();

            Pages = "RecentOrders";
        }

        // add & remove page:
        public CustomerOrderWidget customerOrderWidgetForm = new CustomerOrderWidget();
        private void Home_Click(object sender, EventArgs e)
        {
            if (this.Controls.Contains(customerOrderWidgetForm)) {
                this.Controls.Remove(customerOrderWidgetForm);
            }

            Default_Page.Visible = true;
            Default_Page.BringToFront();

            Pages = "default";
        }

        private async void Search_Click(object sender, EventArgs e)
        {
            string SearchURL = "http://localhost:5000/Search";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("table", "products"));
            postData.Add(new KeyValuePair<string, string>("textSearch", SearchInTable.Text));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(SearchURL, content).Result;
            string Result = await response.Content.ReadAsStringAsync();

            List<ProductsClass> All_Products = JsonConvert.DeserializeObject<List<ProductsClass>>(Result);

            Products.Clear();
            for (int i = 0; i < All_Products.Count; i++) {
                Products.Rows.Add(All_Products[i].ProductID, All_Products[i].ProductName, All_Products[i].Description, All_Products[i].Price, All_Products[i].Image, All_Products[i].CategoryID, All_Products[i].CategoryName);
            }
        }

        private void SearchInTable_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search.PerformClick();
            }
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            if (Pages == "default")
            {
                // clear text of page:
                Date.Text = "----/--/--";

                // remove clomun
                Products.Rows.Clear();
                Products.Columns.Clear();
                OrderDetails.Rows.Clear();
                OrderDetails.Columns.Clear();

                Cart_viewGuide.Visible = false;
                Cart_view.Visible = false;
                RemoveCount.Visible = false;

                AddDataToCartTable();
                AddDataToProductsTable();
            }
            else if (Pages == "RecentOrders")
            {
                if (this.Controls.Contains(customerOrderWidgetForm)) {
                    this.Controls.Remove(customerOrderWidgetForm);
                }

                customerOrderWidgetForm.Location = new Point(190, 71);
                this.Controls.Add(customerOrderWidgetForm);
                customerOrderWidgetForm.BringToFront();
            }

            // add date: 
            Date.Text = TodayDate;
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F5)
            {
                // Call the method to handle the F5 key press
                HandleF5KeyPress();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void HandleF5KeyPress()
        {
            Refresh.PerformClick();
        }

        private void Products_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Products_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }
        private void Cart_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            Products_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(this, "آیا مایل به خروج از حساب کاربری هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            if (dialogResult == DialogResult.Yes)
            {
                Login loginForm = new Login();
                this.Hide();
                loginForm.ShowDialog();
            }
        }

        private void Products_view_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Products_view.ClearSelection(); // clear previous selections
                Products_view.Rows[e.RowIndex].Selected = true; // select the clicked row

                ContextMenuStrip recordMenu = new ContextMenuStrip();
                ToolStripMenuItem Detailes = new ToolStripMenuItem("جزئیات");

                Detailes.Font = new Font("IRANSansXFaNum", 9);

                Detailes.Click += new EventHandler(Detailes_Click);

                recordMenu.Items.Add(Detailes);

                recordMenu.Show(Cursor.Position);
            }
        }
        private void Detailes_Click(object sender, EventArgs e)
        {
            if (Products_view.SelectedRows.Count == 1)
            {
                saveProducts.ProductID = Products_view.CurrentRow?.Cells["کدمحصول"]?.Value?.ToString() ?? "default value";
                saveProducts.ProductName = Products_view.CurrentRow?.Cells["نام‌محصول"]?.Value?.ToString() ?? "default value";
                saveProducts.Description = Products_view.CurrentRow?.Cells["توضیحات"]?.Value?.ToString() ?? "default value";
                saveProducts.Image = Products_view.CurrentRow?.Cells["آدرس تصویر"]?.Value?.ToString() ?? "default value";

                ProductsDetailesWidget productsDetailesWidgetForm = new ProductsDetailesWidget();
                productsDetailesWidgetForm.Show();
            }
        }

        bool isFirstLoad = true;
        private async void P_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFirstLoad)
            {
                string SearchURL = "http://localhost:5000/Search";
                string name = (P_Category.Text == "همه‌ دسته‌ها") ? "" : P_Category.Text;

                HttpClient client = new HttpClient();

                // Post:
                var postData = new List<KeyValuePair<string, string>>();

                postData.Add(new KeyValuePair<string, string>("table", "products"));
                postData.Add(new KeyValuePair<string, string>("textSearch", name));
                HttpContent content = new FormUrlEncodedContent(postData);

                var response = client.PostAsync(SearchURL, content).Result;
                string Result = await response.Content.ReadAsStringAsync();
                List<ProductsClass> All_Products = JsonConvert.DeserializeObject<List<ProductsClass>>(Result);

                Products.Clear();
                for (int i = 0; i < All_Products.Count; i++)
                {
                    Products.Rows.Add(All_Products[i].ProductID, All_Products[i].ProductName, All_Products[i].Description, All_Products[i].Price, All_Products[i].Image, All_Products[i].CategoryID, All_Products[i].CategoryName);
                }
            }
            else {
                isFirstLoad = false;
            }
        }

        private void Products_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Products_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }

        private void Cart_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Cart_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
    }
}
