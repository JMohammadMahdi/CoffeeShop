﻿namespace CoffeeShop
{
    partial class Signup
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Signup));
            this.CoffeeWallper = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.TitlePage = new System.Windows.Forms.Label();
            this.Firstname = new System.Windows.Forms.TextBox();
            this.FirstnameGuide = new System.Windows.Forms.Label();
            this.LastnameGuide = new System.Windows.Forms.Label();
            this.Lastname = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PhoneNumberGuide = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.StatesGuide = new System.Windows.Forms.Label();
            this.States = new System.Windows.Forms.ComboBox();
            this.AddressGuide = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PasswordGuide = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.CreateAcount = new System.Windows.Forms.Button();
            this.lable9 = new System.Windows.Forms.Label();
            this.TransferToLoginPage = new System.Windows.Forms.Label();
            this.phoneEror = new System.Windows.Forms.PictureBox();
            this.EmailGuide = new System.Windows.Forms.Label();
            this.EmailBox = new System.Windows.Forms.TextBox();
            this.emailEror = new System.Windows.Forms.PictureBox();
            this.passwordEror = new System.Windows.Forms.PictureBox();
            this.postalCode = new System.Windows.Forms.TextBox();
            this.PostalCodeGuide = new System.Windows.Forms.Label();
            this.BoxesPanle = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.CoffeeWallper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneEror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailEror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordEror)).BeginInit();
            this.BoxesPanle.SuspendLayout();
            this.SuspendLayout();
            // 
            // CoffeeWallper
            // 
            resources.ApplyResources(this.CoffeeWallper, "CoffeeWallper");
            this.CoffeeWallper.Name = "CoffeeWallper";
            this.CoffeeWallper.TabStop = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::CoffeeShop.Properties.Resources.user_two;
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // TitlePage
            // 
            resources.ApplyResources(this.TitlePage, "TitlePage");
            this.TitlePage.Name = "TitlePage";
            // 
            // Firstname
            // 
            resources.ApplyResources(this.Firstname, "Firstname");
            this.Firstname.Name = "Firstname";
            // 
            // FirstnameGuide
            // 
            resources.ApplyResources(this.FirstnameGuide, "FirstnameGuide");
            this.FirstnameGuide.Name = "FirstnameGuide";
            // 
            // LastnameGuide
            // 
            resources.ApplyResources(this.LastnameGuide, "LastnameGuide");
            this.LastnameGuide.Name = "LastnameGuide";
            // 
            // Lastname
            // 
            resources.ApplyResources(this.Lastname, "Lastname");
            this.Lastname.Name = "Lastname";
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::CoffeeShop.Properties.Resources.phone_call;
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // PhoneNumberGuide
            // 
            resources.ApplyResources(this.PhoneNumberGuide, "PhoneNumberGuide");
            this.PhoneNumberGuide.Name = "PhoneNumberGuide";
            // 
            // Phone
            // 
            resources.ApplyResources(this.Phone, "Phone");
            this.Phone.Name = "Phone";
            this.Phone.TextChanged += new System.EventHandler(this.PhoneNumber_TextChanged);
            // 
            // pictureBox4
            // 
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::CoffeeShop.Properties.Resources.placeholder;
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // StatesGuide
            // 
            resources.ApplyResources(this.StatesGuide, "StatesGuide");
            this.StatesGuide.Name = "StatesGuide";
            // 
            // States
            // 
            resources.ApplyResources(this.States, "States");
            this.States.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.States.FormattingEnabled = true;
            this.States.Name = "States";
            // 
            // AddressGuide
            // 
            resources.ApplyResources(this.AddressGuide, "AddressGuide");
            this.AddressGuide.Name = "AddressGuide";
            // 
            // address
            // 
            resources.ApplyResources(this.address, "address");
            this.address.Name = "address";
            // 
            // pictureBox5
            // 
            resources.ApplyResources(this.pictureBox5, "pictureBox5");
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::CoffeeShop.Properties.Resources.shield;
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.TabStop = false;
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // PasswordGuide
            // 
            resources.ApplyResources(this.PasswordGuide, "PasswordGuide");
            this.PasswordGuide.Name = "PasswordGuide";
            // 
            // password
            // 
            resources.ApplyResources(this.password, "password");
            this.password.Name = "password";
            this.password.TextChanged += new System.EventHandler(this.Password_TextChanged);
            // 
            // CreateAcount
            // 
            resources.ApplyResources(this.CreateAcount, "CreateAcount");
            this.CreateAcount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(249)))), ((int)(((byte)(231)))));
            this.CreateAcount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CreateAcount.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(51)))), ((int)(((byte)(101)))));
            this.CreateAcount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.CreateAcount.Name = "CreateAcount";
            this.CreateAcount.UseVisualStyleBackColor = false;
            this.CreateAcount.Click += new System.EventHandler(this.CreateAcount_Click);
            // 
            // lable9
            // 
            resources.ApplyResources(this.lable9, "lable9");
            this.lable9.Name = "lable9";
            // 
            // TransferToLoginPage
            // 
            resources.ApplyResources(this.TransferToLoginPage, "TransferToLoginPage");
            this.TransferToLoginPage.AutoEllipsis = true;
            this.TransferToLoginPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TransferToLoginPage.ForeColor = System.Drawing.Color.DodgerBlue;
            this.TransferToLoginPage.Name = "TransferToLoginPage";
            this.TransferToLoginPage.UseCompatibleTextRendering = true;
            this.TransferToLoginPage.Click += new System.EventHandler(this.TransferToLoginPage_Click);
            // 
            // phoneEror
            // 
            resources.ApplyResources(this.phoneEror, "phoneEror");
            this.phoneEror.BackColor = System.Drawing.Color.Transparent;
            this.phoneEror.Image = global::CoffeeShop.Properties.Resources.multiply;
            this.phoneEror.Name = "phoneEror";
            this.phoneEror.TabStop = false;
            // 
            // EmailGuide
            // 
            resources.ApplyResources(this.EmailGuide, "EmailGuide");
            this.EmailGuide.Name = "EmailGuide";
            // 
            // EmailBox
            // 
            resources.ApplyResources(this.EmailBox, "EmailBox");
            this.EmailBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.EmailBox.Name = "EmailBox";
            this.EmailBox.TextChanged += new System.EventHandler(this.Email_TextChanged);
            // 
            // emailEror
            // 
            resources.ApplyResources(this.emailEror, "emailEror");
            this.emailEror.BackColor = System.Drawing.Color.Transparent;
            this.emailEror.Image = global::CoffeeShop.Properties.Resources.multiply;
            this.emailEror.Name = "emailEror";
            this.emailEror.TabStop = false;
            // 
            // passwordEror
            // 
            resources.ApplyResources(this.passwordEror, "passwordEror");
            this.passwordEror.BackColor = System.Drawing.Color.Transparent;
            this.passwordEror.Image = global::CoffeeShop.Properties.Resources.multiply;
            this.passwordEror.Name = "passwordEror";
            this.passwordEror.TabStop = false;
            // 
            // postalCode
            // 
            resources.ApplyResources(this.postalCode, "postalCode");
            this.postalCode.Name = "postalCode";
            // 
            // PostalCodeGuide
            // 
            resources.ApplyResources(this.PostalCodeGuide, "PostalCodeGuide");
            this.PostalCodeGuide.Name = "PostalCodeGuide";
            // 
            // BoxesPanle
            // 
            this.BoxesPanle.Controls.Add(this.pictureBox2);
            this.BoxesPanle.Controls.Add(this.label1);
            this.BoxesPanle.Controls.Add(this.postalCode);
            this.BoxesPanle.Controls.Add(this.label5);
            this.BoxesPanle.Controls.Add(this.PostalCodeGuide);
            this.BoxesPanle.Controls.Add(this.label2);
            this.BoxesPanle.Controls.Add(this.passwordEror);
            this.BoxesPanle.Controls.Add(this.Firstname);
            this.BoxesPanle.Controls.Add(this.emailEror);
            this.BoxesPanle.Controls.Add(this.FirstnameGuide);
            this.BoxesPanle.Controls.Add(this.EmailGuide);
            this.BoxesPanle.Controls.Add(this.Lastname);
            this.BoxesPanle.Controls.Add(this.EmailBox);
            this.BoxesPanle.Controls.Add(this.LastnameGuide);
            this.BoxesPanle.Controls.Add(this.phoneEror);
            this.BoxesPanle.Controls.Add(this.label4);
            this.BoxesPanle.Controls.Add(this.pictureBox3);
            this.BoxesPanle.Controls.Add(this.Phone);
            this.BoxesPanle.Controls.Add(this.PhoneNumberGuide);
            this.BoxesPanle.Controls.Add(this.PasswordGuide);
            this.BoxesPanle.Controls.Add(this.label6);
            this.BoxesPanle.Controls.Add(this.password);
            this.BoxesPanle.Controls.Add(this.label3);
            this.BoxesPanle.Controls.Add(this.pictureBox5);
            this.BoxesPanle.Controls.Add(this.pictureBox4);
            this.BoxesPanle.Controls.Add(this.label7);
            this.BoxesPanle.Controls.Add(this.StatesGuide);
            this.BoxesPanle.Controls.Add(this.label8);
            this.BoxesPanle.Controls.Add(this.States);
            this.BoxesPanle.Controls.Add(this.address);
            this.BoxesPanle.Controls.Add(this.AddressGuide);
            resources.ApplyResources(this.BoxesPanle, "BoxesPanle");
            this.BoxesPanle.Name = "BoxesPanle";
            // 
            // Signup
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Controls.Add(this.TransferToLoginPage);
            this.Controls.Add(this.lable9);
            this.Controls.Add(this.CreateAcount);
            this.Controls.Add(this.CoffeeWallper);
            this.Controls.Add(this.TitlePage);
            this.Controls.Add(this.BoxesPanle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Signup";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CoffeeWallper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneEror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailEror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordEror)).EndInit();
            this.BoxesPanle.ResumeLayout(false);
            this.BoxesPanle.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox CoffeeWallper;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox2;
        private Label TitlePage;
        private TextBox Firstname;
        private Label FirstnameGuide;
        private Label LastnameGuide;
        private TextBox Lastname;
        private PictureBox pictureBox3;
        private Label label4;
        private Label label5;
        private Label PhoneNumberGuide;
        private TextBox Phone;
        private PictureBox pictureBox4;
        private Label label3;
        private Label label6;
        private Label StatesGuide;
        private ComboBox States;
        private Label AddressGuide;
        private TextBox address;
        private PictureBox pictureBox5;
        private Label label7;
        private Label label8;
        private Label PasswordGuide;
        private TextBox password;
        private Button CreateAcount;
        private Label lable9;
        private Label TransferToLoginPage;
        private PictureBox phoneEror;
        private Label EmailGuide;
        private TextBox EmailBox;
        private PictureBox emailEror;
        private PictureBox passwordEror;
        private TextBox postalCode;
        private Label PostalCodeGuide;
        private Panel BoxesPanle;
    }
}