﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop
{
    internal class Opttion
    {
        public static string SeparateByCommas(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            var decimalSeparator = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            var parts = input.Split(new[] { decimalSeparator }, StringSplitOptions.None);

            var integerPart = parts[0];
            var fractionalPart = parts.Length > 1 ? decimalSeparator + parts[1] : "";

            var negative = integerPart.StartsWith("-");
            if (negative) integerPart = integerPart.Substring(1);

            var result = "";
            var count = 0;
            for (var i = integerPart.Length - 1; i >= 0; i--)
            {
                result = integerPart[i] + result;
                count++;
                if (count == 3 && i != 0)
                {
                    result = "," + result;
                    count = 0;
                }
            }

            if (negative) result = "-" + result;

            return result + fractionalPart;
        }
    }
}
