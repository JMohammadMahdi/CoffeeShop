﻿namespace CoffeeShop
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.CoffeeWallper = new System.Windows.Forms.PictureBox();
            this.TitlePage = new System.Windows.Forms.Label();
            this.UsernameGuide = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.PasswordGuide = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TransferToSignupPage = new System.Windows.Forms.Label();
            this.lable9 = new System.Windows.Forms.Label();
            this.LoginToAcount = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CoffeeWallper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // CoffeeWallper
            // 
            this.CoffeeWallper.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CoffeeWallper.Image = ((System.Drawing.Image)(resources.GetObject("CoffeeWallper.Image")));
            this.CoffeeWallper.Location = new System.Drawing.Point(602, 124);
            this.CoffeeWallper.Name = "CoffeeWallper";
            this.CoffeeWallper.Size = new System.Drawing.Size(420, 412);
            this.CoffeeWallper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.CoffeeWallper.TabIndex = 1;
            this.CoffeeWallper.TabStop = false;
            // 
            // TitlePage
            // 
            this.TitlePage.AutoSize = true;
            this.TitlePage.Font = new System.Drawing.Font("IRANSansXFaNum", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TitlePage.Location = new System.Drawing.Point(177, 14);
            this.TitlePage.Name = "TitlePage";
            this.TitlePage.Size = new System.Drawing.Size(160, 25);
            this.TitlePage.TabIndex = 7;
            this.TitlePage.Text = "ورود به حساب کاربری";
            this.TitlePage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // UsernameGuide
            // 
            this.UsernameGuide.AutoSize = true;
            this.UsernameGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameGuide.Location = new System.Drawing.Point(70, 265);
            this.UsernameGuide.Name = "UsernameGuide";
            this.UsernameGuide.Size = new System.Drawing.Size(119, 24);
            this.UsernameGuide.TabIndex = 20;
            this.UsernameGuide.Text = "تلفن / کد کاربری";
            this.UsernameGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // username
            // 
            this.username.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.username.Location = new System.Drawing.Point(206, 262);
            this.username.MaxLength = 13;
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(248, 31);
            this.username.TabIndex = 16;
            this.username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.username.WordWrap = false;
            // 
            // PasswordGuide
            // 
            this.PasswordGuide.AutoSize = true;
            this.PasswordGuide.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordGuide.Location = new System.Drawing.Point(127, 313);
            this.PasswordGuide.Name = "PasswordGuide";
            this.PasswordGuide.Size = new System.Drawing.Size(62, 24);
            this.PasswordGuide.TabIndex = 22;
            this.PasswordGuide.Text = "رمز عبور";
            this.PasswordGuide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // password
            // 
            this.password.Font = new System.Drawing.Font("IRANSansXFaNum ExtraBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.password.Location = new System.Drawing.Point(206, 310);
            this.password.Multiline = true;
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(248, 31);
            this.password.TabIndex = 21;
            this.password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.password.WordWrap = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::CoffeeShop.Properties.Resources.shield;
            this.pictureBox5.Location = new System.Drawing.Point(12, 198);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 32);
            this.pictureBox5.TabIndex = 31;
            this.pictureBox5.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(49, 202);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 24);
            this.label7.TabIndex = 30;
            this.label7.Text = "احراز هویت";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("IRANSansXFaNum", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(139, 204);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(375, 20);
            this.label8.TabIndex = 29;
            this.label8.Text = "_____________________________________________________________";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TransferToSignupPage
            // 
            this.TransferToSignupPage.AutoEllipsis = true;
            this.TransferToSignupPage.AutoSize = true;
            this.TransferToSignupPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TransferToSignupPage.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TransferToSignupPage.ForeColor = System.Drawing.Color.DodgerBlue;
            this.TransferToSignupPage.Location = new System.Drawing.Point(197, 452);
            this.TransferToSignupPage.Name = "TransferToSignupPage";
            this.TransferToSignupPage.Size = new System.Drawing.Size(60, 28);
            this.TransferToSignupPage.TabIndex = 34;
            this.TransferToSignupPage.Text = " ثبت نام ";
            this.TransferToSignupPage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TransferToSignupPage.UseCompatibleTextRendering = true;
            this.TransferToSignupPage.Click += new System.EventHandler(this.TransferToSignupPage_Click);
            // 
            // lable9
            // 
            this.lable9.AutoSize = true;
            this.lable9.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lable9.Location = new System.Drawing.Point(258, 455);
            this.lable9.Name = "lable9";
            this.lable9.Size = new System.Drawing.Size(137, 22);
            this.lable9.TabIndex = 35;
            this.lable9.Text = "حساب کاربری ندارید؟";
            this.lable9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LoginToAcount
            // 
            this.LoginToAcount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(249)))), ((int)(((byte)(231)))));
            this.LoginToAcount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoginToAcount.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(135)))), ((int)(((byte)(27)))));
            this.LoginToAcount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoginToAcount.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LoginToAcount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(135)))), ((int)(((byte)(27)))));
            this.LoginToAcount.Location = new System.Drawing.Point(120, 399);
            this.LoginToAcount.Name = "LoginToAcount";
            this.LoginToAcount.Size = new System.Drawing.Size(275, 50);
            this.LoginToAcount.TabIndex = 33;
            this.LoginToAcount.Text = "ورود به حساب";
            this.LoginToAcount.UseVisualStyleBackColor = false;
            this.LoginToAcount.Click += new System.EventHandler(this.LoginToAcount_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1034, 661);
            this.Controls.Add(this.TransferToSignupPage);
            this.Controls.Add(this.lable9);
            this.Controls.Add(this.LoginToAcount);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.PasswordGuide);
            this.Controls.Add(this.password);
            this.Controls.Add(this.UsernameGuide);
            this.Controls.Add(this.username);
            this.Controls.Add(this.TitlePage);
            this.Controls.Add(this.CoffeeWallper);
            this.MaximumSize = new System.Drawing.Size(1300, 700);
            this.MinimumSize = new System.Drawing.Size(1050, 700);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CoffeeWallper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox CoffeeWallper;
        private Label TitlePage;
        private Label UsernameGuide;
        private TextBox username;
        private Label PasswordGuide;
        private TextBox password;
        private PictureBox pictureBox5;
        private Label label7;
        private Label label8;
        private Label TransferToSignupPage;
        private Label lable9;
        private Button LoginToAcount;
    }
}