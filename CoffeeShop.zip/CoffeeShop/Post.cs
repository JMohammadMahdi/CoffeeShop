﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop
{
    public class CustomersClass
    {
        public string Address { get; set; }
        public string City { get; set; }
        public int CustomerID { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
        public string PostalCode { get; set; }
        public string State { get; set; }
    }
    public class ProductsClass
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public string Price { get; set; }
        public string Image { get; set; }
        public string CategoryName { get; set; }
        public int CategoryID { get; set; }
    }
    public class OrdersClass
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public string FullName { get; set; }
        public string OrderDate { get; set; }
        public int TotalAmount { get; set; }
        public string PaymentType { get; set; }
        public string Status { get; set; }
    }
    public class OrderDetailsClass
    {
        public string ProductID { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public int ItemDiscount { get; set; }
        public int ItemPrice { get; set; }
        public int ItemTotal { get; set; }
        public string ItemNotes { get; set; }
    }
    public class FactorClass
    {
        public static string OrderID = string.Empty;
        public static string CustomerOrder = string.Empty;
        public static string CustomerID = string.Empty;
        public static string OrderDate = string.Empty;
        public static string TotalFac = string.Empty;
        //public static string status = string.Empty;
    }
    public class CategoriesClass
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
        public string CategoryImage { get; set; }
    }
    public class BestProductsClass
    {
        public string ProductID { get; set; }
        public string ProductName { get; set; }
        public string Amount { get; set; }
    }
    public class BestCustomersClass
    {
        public string ProductID { get; set; }
        public string ProductName { get; set; }
        public string Amount { get; set; }
    }
    public class userLoggedIn
    {
        public static int CustomerID = 0;
        public static string FirstName = string.Empty;
        public static string LastName = string.Empty;
        public static string Email = string.Empty;
        public static string PhoneNumber = string.Empty;
        public static string Address = string.Empty;
        public static string City = string.Empty;
        public static string State = string.Empty;
        public static string PostalCode = string.Empty;
        public static string Password = string.Empty;
    }
    public class EditCustomers
    {
        public static string CustomerID = string.Empty;
        public static string FirstName = string.Empty;
        public static string LastName = string.Empty;
        public static string Email = string.Empty;
        public static string PhoneNumber = string.Empty;
        public static string Address = string.Empty;
        public static string City = string.Empty;
        public static string State = string.Empty;
        public static string PostalCode = string.Empty;
        public static string Password = string.Empty;
    }
    public class saveProducts
    {
        public static string ProductID = string.Empty;
        public static string ProductName = string.Empty;
        public static string Description = string.Empty;
        public static string Price = string.Empty;
        public static string Image = string.Empty;
        public static string CategoryID = string.Empty;
        public static string CategoryName = string.Empty;
    }
    public class saveCustomer   // save customer data for add order
    {
        public static string CustomerID = string.Empty;
        public static string FullName = string.Empty;
        public static string Address = string.Empty;
        public static string Phone = string.Empty;
    }
    public class EditCategories
    {
        public static string CategoryID = string.Empty;
        public static string CategoryName = string.Empty;
        public static string CategoryDescription = string.Empty;
        public static string CategoryImage = string.Empty;
    }
    public class RowData
    {
        public string ID { get; set; }
        public string Name{ get; set; }
        public string Count { get; set; }
        public string Price { get; set; }
        public string TotalAmount { get; set; }
    }
    public class PaymentPage
    {
        public static List<RowData> CartData = new List<RowData>();
        public static int ID = 0;
        public static string Total = string.Empty;
    }
}
