﻿namespace CoffeeShop
{
    partial class Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Management));
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.Home = new System.Windows.Forms.ToolStripMenuItem();
            this.UsersManager_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.ProductsManager_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.OrdersManager_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.CategoriesManager_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.Date = new System.Windows.Forms.Label();
            this.BackgrondData = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.AllInvoices = new System.Windows.Forms.Label();
            this.FactorToDay = new System.Windows.Forms.Label();
            this.AllInvoices_Guide = new System.Windows.Forms.Label();
            this.FactorToDay_Guide = new System.Windows.Forms.Label();
            this.Factor_Guide = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.ProductsCounting = new System.Windows.Forms.Label();
            this.ProductsCounting_Guide = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.UsersCounting = new System.Windows.Forms.Label();
            this.UsersCounting_Guide = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Refresh = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.BestCustomers_view = new System.Windows.Forms.DataGridView();
            this.BestSellingProduct_view = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.TotalInvoices = new System.Windows.Forms.Label();
            this.Default_Page = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.NewFactor = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BestCustomers_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BestSellingProduct_view)).BeginInit();
            this.Default_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // Menu
            // 
            this.Menu.AutoSize = false;
            this.Menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.Menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Menu.Dock = System.Windows.Forms.DockStyle.None;
            this.Menu.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Menu.GripMargin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Home,
            this.NewFactor,
            this.UsersManager_menu,
            this.ProductsManager_menu,
            this.OrdersManager_menu,
            this.CategoriesManager_menu});
            this.Menu.Location = new System.Drawing.Point(8, 9);
            this.Menu.Name = "Menu";
            this.Menu.Padding = new System.Windows.Forms.Padding(0);
            this.Menu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.Menu.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Menu.Size = new System.Drawing.Size(1366, 50);
            this.Menu.TabIndex = 13;
            this.Menu.Text = "Menu";
            // 
            // Home
            // 
            this.Home.AutoSize = false;
            this.Home.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(90, 50);
            this.Home.Text = "خانه";
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // UsersManager_menu
            // 
            this.UsersManager_menu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.UsersManager_menu.Name = "UsersManager_menu";
            this.UsersManager_menu.Size = new System.Drawing.Size(90, 50);
            this.UsersManager_menu.Text = "مشتریان";
            this.UsersManager_menu.Click += new System.EventHandler(this.UsersManager_menu_Click);
            // 
            // ProductsManager_menu
            // 
            this.ProductsManager_menu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.ProductsManager_menu.Name = "ProductsManager_menu";
            this.ProductsManager_menu.Size = new System.Drawing.Size(102, 50);
            this.ProductsManager_menu.Text = "محصولات";
            this.ProductsManager_menu.Click += new System.EventHandler(this.ProductsManager_menu_Click);
            // 
            // OrdersManager_menu
            // 
            this.OrdersManager_menu.BackColor = System.Drawing.Color.Transparent;
            this.OrdersManager_menu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.OrdersManager_menu.Name = "OrdersManager_menu";
            this.OrdersManager_menu.Size = new System.Drawing.Size(92, 50);
            this.OrdersManager_menu.Text = "سفارشات";
            this.OrdersManager_menu.Click += new System.EventHandler(this.OrdersManager_menu_Click);
            // 
            // CategoriesManager_menu
            // 
            this.CategoriesManager_menu.AutoSize = false;
            this.CategoriesManager_menu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.CategoriesManager_menu.Name = "CategoriesManager_menu";
            this.CategoriesManager_menu.Size = new System.Drawing.Size(125, 46);
            this.CategoriesManager_menu.Text = "دسته بندی‌ها";
            this.CategoriesManager_menu.Click += new System.EventHandler(this.CategoriesManager_menu_Click);
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.Date.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Date.ForeColor = System.Drawing.Color.White;
            this.Date.Location = new System.Drawing.Point(63, 18);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(82, 28);
            this.Date.TabIndex = 16;
            this.Date.Text = "----/--/--";
            this.Date.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BackgrondData
            // 
            this.BackgrondData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.BackgrondData.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BackgrondData.Location = new System.Drawing.Point(0, 72);
            this.BackgrondData.Name = "BackgrondData";
            this.BackgrondData.Padding = new System.Windows.Forms.Padding(0, 100, 0, 0);
            this.BackgrondData.Size = new System.Drawing.Size(1385, 489);
            this.BackgrondData.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label7.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(584, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 168);
            this.label7.TabIndex = 24;
            this.label7.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AllInvoices
            // 
            this.AllInvoices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AllInvoices.BackColor = System.Drawing.SystemColors.Control;
            this.AllInvoices.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AllInvoices.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.AllInvoices.Location = new System.Drawing.Point(764, 125);
            this.AllInvoices.Name = "AllInvoices";
            this.AllInvoices.Size = new System.Drawing.Size(60, 28);
            this.AllInvoices.TabIndex = 30;
            this.AllInvoices.Text = "?";
            this.AllInvoices.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FactorToDay
            // 
            this.FactorToDay.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.FactorToDay.BackColor = System.Drawing.SystemColors.Control;
            this.FactorToDay.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FactorToDay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.FactorToDay.Location = new System.Drawing.Point(830, 125);
            this.FactorToDay.Name = "FactorToDay";
            this.FactorToDay.Size = new System.Drawing.Size(60, 28);
            this.FactorToDay.TabIndex = 29;
            this.FactorToDay.Text = "?";
            this.FactorToDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AllInvoices_Guide
            // 
            this.AllInvoices_Guide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AllInvoices_Guide.AutoSize = true;
            this.AllInvoices_Guide.BackColor = System.Drawing.SystemColors.Control;
            this.AllInvoices_Guide.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AllInvoices_Guide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.AllInvoices_Guide.Location = new System.Drawing.Point(778, 82);
            this.AllInvoices_Guide.Name = "AllInvoices_Guide";
            this.AllInvoices_Guide.Size = new System.Drawing.Size(33, 28);
            this.AllInvoices_Guide.TabIndex = 28;
            this.AllInvoices_Guide.Text = "کل";
            this.AllInvoices_Guide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FactorToDay_Guide
            // 
            this.FactorToDay_Guide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.FactorToDay_Guide.AutoSize = true;
            this.FactorToDay_Guide.BackColor = System.Drawing.SystemColors.Control;
            this.FactorToDay_Guide.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FactorToDay_Guide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.FactorToDay_Guide.Location = new System.Drawing.Point(836, 82);
            this.FactorToDay_Guide.Name = "FactorToDay_Guide";
            this.FactorToDay_Guide.Size = new System.Drawing.Size(49, 28);
            this.FactorToDay_Guide.TabIndex = 27;
            this.FactorToDay_Guide.Text = "امروز";
            this.FactorToDay_Guide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Factor_Guide
            // 
            this.Factor_Guide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Factor_Guide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Factor_Guide.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Factor_Guide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Factor_Guide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(215)))));
            this.Factor_Guide.Location = new System.Drawing.Point(652, 26);
            this.Factor_Guide.Name = "Factor_Guide";
            this.Factor_Guide.Size = new System.Drawing.Size(252, 44);
            this.Factor_Guide.TabIndex = 25;
            this.Factor_Guide.Text = "فاکتور";
            this.Factor_Guide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("IRANSansXFaNum", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.label14.Location = new System.Drawing.Point(652, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(252, 142);
            this.label14.TabIndex = 26;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProductsCounting
            // 
            this.ProductsCounting.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ProductsCounting.BackColor = System.Drawing.SystemColors.Control;
            this.ProductsCounting.Font = new System.Drawing.Font("IRANSansXFaNum", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ProductsCounting.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.ProductsCounting.Location = new System.Drawing.Point(390, 106);
            this.ProductsCounting.Name = "ProductsCounting";
            this.ProductsCounting.Size = new System.Drawing.Size(92, 27);
            this.ProductsCounting.TabIndex = 36;
            this.ProductsCounting.Text = "?";
            this.ProductsCounting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProductsCounting_Guide
            // 
            this.ProductsCounting_Guide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ProductsCounting_Guide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.ProductsCounting_Guide.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ProductsCounting_Guide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ProductsCounting_Guide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(215)))));
            this.ProductsCounting_Guide.Location = new System.Drawing.Point(340, 26);
            this.ProductsCounting_Guide.Name = "ProductsCounting_Guide";
            this.ProductsCounting_Guide.Size = new System.Drawing.Size(195, 44);
            this.ProductsCounting_Guide.TabIndex = 31;
            this.ProductsCounting_Guide.Text = "محصولات";
            this.ProductsCounting_Guide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("IRANSansXFaNum", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.label8.Location = new System.Drawing.Point(339, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(195, 142);
            this.label8.TabIndex = 32;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // UsersCounting
            // 
            this.UsersCounting.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UsersCounting.BackColor = System.Drawing.SystemColors.Control;
            this.UsersCounting.Font = new System.Drawing.Font("IRANSansXFaNum", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.UsersCounting.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.UsersCounting.Location = new System.Drawing.Point(83, 105);
            this.UsersCounting.Name = "UsersCounting";
            this.UsersCounting.Size = new System.Drawing.Size(92, 28);
            this.UsersCounting.TabIndex = 43;
            this.UsersCounting.Text = "?";
            this.UsersCounting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // UsersCounting_Guide
            // 
            this.UsersCounting_Guide.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UsersCounting_Guide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.UsersCounting_Guide.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UsersCounting_Guide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.UsersCounting_Guide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(215)))));
            this.UsersCounting_Guide.Location = new System.Drawing.Point(32, 26);
            this.UsersCounting_Guide.Name = "UsersCounting_Guide";
            this.UsersCounting_Guide.Size = new System.Drawing.Size(195, 44);
            this.UsersCounting_Guide.TabIndex = 38;
            this.UsersCounting_Guide.Text = "کاربران";
            this.UsersCounting_Guide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.BackColor = System.Drawing.SystemColors.Control;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("IRANSansXFaNum", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.label22.Location = new System.Drawing.Point(32, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(195, 142);
            this.label22.TabIndex = 39;
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label30.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(276, 13);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 168);
            this.label30.TabIndex = 56;
            this.label30.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(184)))), ((int)(((byte)(99)))));
            this.pictureBox1.Image = global::CoffeeShop.Properties.Resources.calendar;
            this.pictureBox1.Location = new System.Drawing.Point(22, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.TabIndex = 57;
            this.pictureBox1.TabStop = false;
            // 
            // Refresh
            // 
            this.Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Refresh.Image = global::CoffeeShop.Properties.Resources.RefreshServer;
            this.Refresh.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Refresh.Location = new System.Drawing.Point(19, 79);
            this.Refresh.Margin = new System.Windows.Forms.Padding(10);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(57, 63);
            this.Refresh.TabIndex = 79;
            this.Refresh.Tag = "";
            this.Refresh.Text = "بروزرسانی";
            this.Refresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label2.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label2.Image = global::CoffeeShop.Properties.Resources.employees;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label2.Location = new System.Drawing.Point(213, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(254, 37);
            this.label2.TabIndex = 80;
            this.label2.Text = "با ارزش ترین مشتریان";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BestCustomers_view
            // 
            this.BestCustomers_view.AllowUserToAddRows = false;
            this.BestCustomers_view.AllowUserToDeleteRows = false;
            this.BestCustomers_view.AllowUserToOrderColumns = true;
            this.BestCustomers_view.AllowUserToResizeColumns = false;
            this.BestCustomers_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BestCustomers_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BestCustomers_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.BestCustomers_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BestCustomers_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.BestCustomers_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BestCustomers_view.DefaultCellStyle = dataGridViewCellStyle8;
            this.BestCustomers_view.Location = new System.Drawing.Point(32, 262);
            this.BestCustomers_view.Name = "BestCustomers_view";
            this.BestCustomers_view.ReadOnly = true;
            this.BestCustomers_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BestCustomers_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.BestCustomers_view.RowTemplate.Height = 25;
            this.BestCustomers_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BestCustomers_view.Size = new System.Drawing.Size(433, 200);
            this.BestCustomers_view.TabIndex = 81;
            this.BestCustomers_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.BestCustomers_view_RowPostPaint);
            this.BestCustomers_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.BestSellingProduct_view_RowPrePaint);
            // 
            // BestSellingProduct_view
            // 
            this.BestSellingProduct_view.AllowUserToAddRows = false;
            this.BestSellingProduct_view.AllowUserToDeleteRows = false;
            this.BestSellingProduct_view.AllowUserToOrderColumns = true;
            this.BestSellingProduct_view.AllowUserToResizeColumns = false;
            this.BestSellingProduct_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BestSellingProduct_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BestSellingProduct_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.BestSellingProduct_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BestSellingProduct_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.BestSellingProduct_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BestSellingProduct_view.DefaultCellStyle = dataGridViewCellStyle11;
            this.BestSellingProduct_view.Location = new System.Drawing.Point(471, 262);
            this.BestSellingProduct_view.Name = "BestSellingProduct_view";
            this.BestSellingProduct_view.ReadOnly = true;
            this.BestSellingProduct_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BestSellingProduct_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.BestSellingProduct_view.RowTemplate.Height = 25;
            this.BestSellingProduct_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BestSellingProduct_view.Size = new System.Drawing.Size(433, 200);
            this.BestSellingProduct_view.TabIndex = 82;
            this.BestSellingProduct_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.BestSellingProduct_view_RowPostPaint);
            this.BestSellingProduct_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.BestSellingProduct_view_RowPrePaint);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label3.Location = new System.Drawing.Point(673, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 28);
            this.label3.TabIndex = 83;
            this.label3.Text = "جمع کل";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalInvoices
            // 
            this.TotalInvoices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TotalInvoices.BackColor = System.Drawing.SystemColors.Control;
            this.TotalInvoices.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalInvoices.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.TotalInvoices.Location = new System.Drawing.Point(660, 125);
            this.TotalInvoices.Name = "TotalInvoices";
            this.TotalInvoices.Size = new System.Drawing.Size(98, 28);
            this.TotalInvoices.TabIndex = 84;
            this.TotalInvoices.Text = "?";
            this.TotalInvoices.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Default_Page
            // 
            this.Default_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Default_Page.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Default_Page.Controls.Add(this.label4);
            this.Default_Page.Controls.Add(this.BestSellingProduct_view);
            this.Default_Page.Controls.Add(this.BestCustomers_view);
            this.Default_Page.Controls.Add(this.label2);
            this.Default_Page.Controls.Add(this.AllInvoices);
            this.Default_Page.Controls.Add(this.AllInvoices_Guide);
            this.Default_Page.Controls.Add(this.TotalInvoices);
            this.Default_Page.Controls.Add(this.ProductsCounting_Guide);
            this.Default_Page.Controls.Add(this.ProductsCounting);
            this.Default_Page.Controls.Add(this.label3);
            this.Default_Page.Controls.Add(this.FactorToDay_Guide);
            this.Default_Page.Controls.Add(this.FactorToDay);
            this.Default_Page.Controls.Add(this.Factor_Guide);
            this.Default_Page.Controls.Add(this.label7);
            this.Default_Page.Controls.Add(this.label14);
            this.Default_Page.Controls.Add(this.label30);
            this.Default_Page.Controls.Add(this.UsersCounting);
            this.Default_Page.Controls.Add(this.UsersCounting_Guide);
            this.Default_Page.Controls.Add(this.label22);
            this.Default_Page.Controls.Add(this.label8);
            this.Default_Page.Location = new System.Drawing.Point(223, 72);
            this.Default_Page.Name = "Default_Page";
            this.Default_Page.Size = new System.Drawing.Size(939, 489);
            this.Default_Page.TabIndex = 85;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label4.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label4.Image = global::CoffeeShop.Properties.Resources.best_seller;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(630, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(274, 37);
            this.label4.TabIndex = 85;
            this.label4.Text = "پر فروش ترین محصولات";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Exit
            // 
            this.Exit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Exit.Location = new System.Drawing.Point(19, 471);
            this.Exit.Margin = new System.Windows.Forms.Padding(10);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(57, 63);
            this.Exit.TabIndex = 113;
            this.Exit.Tag = "";
            this.Exit.Text = "خروج";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // NewFactor
            // 
            this.NewFactor.Name = "NewFactor";
            this.NewFactor.Size = new System.Drawing.Size(116, 50);
            this.NewFactor.Text = "فاکتور جدید";
            this.NewFactor.Click += new System.EventHandler(this.NewFactor_Click);
            // 
            // Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1385, 561);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.Default_Page);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BackgrondData);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.Menu);
            this.MainMenuStrip = this.Menu;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1401, 600);
            this.MinimumSize = new System.Drawing.Size(1401, 600);
            this.Name = "Management";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Management";
            this.Load += new System.EventHandler(this.Management_Load);
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BestCustomers_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BestSellingProduct_view)).EndInit();
            this.Default_Page.ResumeLayout(false);
            this.Default_Page.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MenuStrip Menu;
        private ToolStripMenuItem UsersManager_menu;
        private ToolStripMenuItem ProductsManager_menu;
        private ToolStripMenuItem OrdersManager_menu;
        private ToolStripMenuItem CategoriesManager_menu;
        private Label Date;
        private Label BackgrondData;
        private Label label7;
        private Label AllInvoices;
        private Label FactorToDay;
        private Label AllInvoices_Guide;
        private Label FactorToDay_Guide;
        private Label Factor_Guide;
        private Label label14;
        private Label ProductsCounting;
        private Label ProductsCounting_Guide;
        private Label label8;
        private Label UsersCounting;
        private Label UsersCounting_Guide;
        private Label label22;
        private Label label30;
        private PictureBox pictureBox1;
        private Button Refresh;
        private Label label2;
        private DataGridView BestCustomers_view;
        private DataGridView BestSellingProduct_view;
        private Label label3;
        private Label TotalInvoices;
        private Panel Default_Page;
        private ToolStripMenuItem Home;
        private Label label4;
        private Button Exit;
        private ToolStripMenuItem NewFactor;
    }
}