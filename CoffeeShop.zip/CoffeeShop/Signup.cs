﻿using CoffeeShop.Widget;
using Microsoft.VisualBasic.Logging;

namespace CoffeeShop
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] stateReaded = File.ReadAllLines(Settings.PathFileStates);
            foreach (var File in stateReaded)
                States.Items.Add(File);
        }

        private void TransferToLoginPage_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            this.Hide();
            loginForm.Show();
        }

        bool[] validity = new bool[3];
        private bool CheckInformation(string checkStatus)
        {

            // email check:
            if (checkStatus == "email" || checkStatus == "ChekAll")
            {
                string emailCheck = "";

                if (EmailBox.TextLength > 10)
                    emailCheck = EmailBox.Text.Substring(EmailBox.TextLength - 10);

                if (!(emailCheck == "@gmail.com" && EmailBox.TextLength > 10))
                {
                    emailEror.Visible = true;
                    emailEror.Image = Properties.Resources.multiply;
                    validity[0] = false;
                } else {
                    emailEror.Image = Properties.Resources.accept;
                    validity[0] = true;
                }
            }

            // tellphone check:
            else if (checkStatus == "tell" || checkStatus == "ChekAll")
            {
                string tellCheck = "";

                if (Phone.TextLength > 0)
                    tellCheck = Phone.Text.Substring(0, 1);

                if (!(tellCheck == "0" && Phone.TextLength == 11))
                {
                    phoneEror.Visible = true;
                    phoneEror.Image = Properties.Resources.multiply;
                    validity[1] = false;

                } else {
                    phoneEror.Image = Properties.Resources.accept;
                    validity[1] = true;
                }
            }

            // password check:
            else if (checkStatus == "pass" || checkStatus == "ChekAll")
            {
                if (!(password.TextLength >= 4))
                {
                    passwordEror.Visible = true;
                    passwordEror.Image = Properties.Resources.multiply;
                    validity[2] = false;
                } else {
                    passwordEror.Image = Properties.Resources.accept;
                    validity[2] = true;
                }
            }

            if (validity[0] && validity[1] && validity[2])
            {
                return true;
            } else {
                return false;
            }
        }
        private void Email_TextChanged(object sender, EventArgs e)
        {
            CheckInformation("email");
        }
        private void PhoneNumber_TextChanged(object sender, EventArgs e)
        {
            CheckInformation("tell");
        }
        private void Password_TextChanged(object sender, EventArgs e)
        {
            CheckInformation("pass");
        }

        private void CreateAcount_Click(object sender, EventArgs e)
        {
            // data checked:
            bool valid = CheckInformation("ChekAll");

            if (Firstname.TextLength > 2 && Lastname.TextLength > 2 && States.SelectedItem != null && address.TextLength > 0 && valid)
            {
                SendDataForSignUp(Firstname.Text, Lastname.Text, EmailBox.Text, Phone.Text, address.Text, States.SelectedItem.ToString(), "ایران", postalCode.Text, password.Text);
            }

        }
        private void SendDataForSignUp(string FirstName, string LastName, string Email, string PhoneNumber, string Address, string City, string State, string PostalCode, string Password)
        {
            int CustomerID = Convert.ToInt32(File.ReadAllText(Settings.pathFileCustomerCode)) + 1;
            string url = "http://localhost:5000/Add_user";

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("CustomerID", CustomerID.ToString()));
            postData.Add(new KeyValuePair<string, string>("FirstName", FirstName));
            postData.Add(new KeyValuePair<string, string>("LastName", LastName));
            postData.Add(new KeyValuePair<string, string>("Email", Email));
            postData.Add(new KeyValuePair<string, string>("PhoneNumber", PhoneNumber));
            postData.Add(new KeyValuePair<string, string>("Address", Address));
            postData.Add(new KeyValuePair<string, string>("City", City));
            postData.Add(new KeyValuePair<string, string>("State", State));
            postData.Add(new KeyValuePair<string, string>("PostalCode", PostalCode));
            postData.Add(new KeyValuePair<string, string>("Password", Password));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                File.WriteAllText(Settings.pathFileCustomerCode, CustomerID.ToString());

                // remove text in text boxes:
                Firstname.Text = Lastname.Text = EmailBox.Text = Phone.Text = States.Text = address.Text = postalCode.Text = password.Text = null;
                // visible Hide For Eror Lables
                emailEror.Visible = phoneEror.Visible = passwordEror.Visible = false;

                DialogResult dialogResult = MessageBox.Show(this, $"حساب کاربری شما با کد کاربری {CustomerID} با موفقیت ایجاد شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
                if (dialogResult == DialogResult.OK)
                {
                    Login loginForm = new Login();
                    this.Hide();
                    loginForm.Show();
                }
            } else {
                MessageBox.Show(this, "اختلال در ارتباط با سرور لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

            }
        }
    }
}