﻿namespace CoffeeShop
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.Products_view = new System.Windows.Forms.DataGridView();
            this.Search_Panel = new System.Windows.Forms.Panel();
            this.Search = new System.Windows.Forms.Button();
            this.SearchInTable = new System.Windows.Forms.TextBox();
            this.Products_viewGuide = new System.Windows.Forms.Label();
            this.Cart_view = new System.Windows.Forms.DataGridView();
            this.SaveData = new System.Windows.Forms.Button();
            this.Cart_viewGuide = new System.Windows.Forms.Label();
            this.RemoveCount = new System.Windows.Forms.PictureBox();
            this.Default_Page = new System.Windows.Forms.Panel();
            this.TotalAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Username = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.Home = new System.Windows.Forms.ToolStripMenuItem();
            this.RecentOrders = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Date = new System.Windows.Forms.Label();
            this.Refresh = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.P_Category = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Products_view)).BeginInit();
            this.Search_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cart_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RemoveCount)).BeginInit();
            this.Default_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Products_view
            // 
            this.Products_view.AllowUserToAddRows = false;
            this.Products_view.AllowUserToDeleteRows = false;
            this.Products_view.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Products_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Products_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Products_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Products_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Products_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Products_view.DefaultCellStyle = dataGridViewCellStyle2;
            this.Products_view.Location = new System.Drawing.Point(357, 32);
            this.Products_view.Name = "Products_view";
            this.Products_view.ReadOnly = true;
            this.Products_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Products_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Products_view.RowTemplate.Height = 25;
            this.Products_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Products_view.Size = new System.Drawing.Size(648, 401);
            this.Products_view.TabIndex = 1;
            this.Products_view.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Products_view_CellDoubleClick);
            this.Products_view.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Products_view_CellMouseDown);
            this.Products_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Products_view_RowPostPaint);
            this.Products_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Products_view_RowPrePaint);
            // 
            // Search_Panel
            // 
            this.Search_Panel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Search_Panel.Controls.Add(this.Search);
            this.Search_Panel.Controls.Add(this.SearchInTable);
            this.Search_Panel.Location = new System.Drawing.Point(575, 19);
            this.Search_Panel.Name = "Search_Panel";
            this.Search_Panel.Size = new System.Drawing.Size(367, 30);
            this.Search_Panel.TabIndex = 97;
            // 
            // Search
            // 
            this.Search.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Search.BackColor = System.Drawing.SystemColors.Window;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Image = global::CoffeeShop.Properties.Resources.search;
            this.Search.Location = new System.Drawing.Point(6, 2);
            this.Search.Margin = new System.Windows.Forms.Padding(0);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(25, 25);
            this.Search.TabIndex = 98;
            this.Search.TabStop = false;
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // SearchInTable
            // 
            this.SearchInTable.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SearchInTable.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SearchInTable.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SearchInTable.Location = new System.Drawing.Point(0, 0);
            this.SearchInTable.Multiline = true;
            this.SearchInTable.Name = "SearchInTable";
            this.SearchInTable.PlaceholderText = "  محصول مورد نظر را جست و جو کنید";
            this.SearchInTable.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.SearchInTable.Size = new System.Drawing.Size(367, 30);
            this.SearchInTable.TabIndex = 97;
            this.SearchInTable.TabStop = false;
            this.SearchInTable.WordWrap = false;
            this.SearchInTable.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SearchInTable_KeyDown);
            // 
            // Products_viewGuide
            // 
            this.Products_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Products_viewGuide.AutoSize = true;
            this.Products_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Products_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Products_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Products_viewGuide.Location = new System.Drawing.Point(862, 1);
            this.Products_viewGuide.Name = "Products_viewGuide";
            this.Products_viewGuide.Size = new System.Drawing.Size(140, 28);
            this.Products_viewGuide.TabIndex = 98;
            this.Products_viewGuide.Text = "لیست محصولات";
            // 
            // Cart_view
            // 
            this.Cart_view.AllowUserToAddRows = false;
            this.Cart_view.AllowUserToDeleteRows = false;
            this.Cart_view.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Cart_view.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Cart_view.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.Cart_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Cart_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.Cart_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Cart_view.DefaultCellStyle = dataGridViewCellStyle5;
            this.Cart_view.Location = new System.Drawing.Point(0, 32);
            this.Cart_view.Name = "Cart_view";
            this.Cart_view.ReadOnly = true;
            this.Cart_view.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("IRANSansXFaNum", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Cart_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Cart_view.RowTemplate.Height = 25;
            this.Cart_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Cart_view.Size = new System.Drawing.Size(351, 401);
            this.Cart_view.TabIndex = 99;
            this.Cart_view.Visible = false;
            this.Cart_view.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.Cart_view_RowPostPaint);
            this.Cart_view.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.Cart_view_RowPrePaint);
            // 
            // SaveData
            // 
            this.SaveData.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SaveData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(183)))), ((int)(((byte)(10)))));
            this.SaveData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.SaveData.FlatAppearance.BorderSize = 0;
            this.SaveData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveData.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SaveData.ForeColor = System.Drawing.Color.White;
            this.SaveData.Location = new System.Drawing.Point(577, 438);
            this.SaveData.Name = "SaveData";
            this.SaveData.Size = new System.Drawing.Size(208, 41);
            this.SaveData.TabIndex = 100;
            this.SaveData.Text = "ثبت و ادامه";
            this.SaveData.UseVisualStyleBackColor = false;
            this.SaveData.Click += new System.EventHandler(this.SaveData_Click);
            // 
            // Cart_viewGuide
            // 
            this.Cart_viewGuide.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Cart_viewGuide.AutoSize = true;
            this.Cart_viewGuide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.Cart_viewGuide.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cart_viewGuide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Cart_viewGuide.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Cart_viewGuide.Location = new System.Drawing.Point(265, 1);
            this.Cart_viewGuide.Name = "Cart_viewGuide";
            this.Cart_viewGuide.Size = new System.Drawing.Size(86, 28);
            this.Cart_viewGuide.TabIndex = 101;
            this.Cart_viewGuide.Text = "سبد خرید";
            this.Cart_viewGuide.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Cart_viewGuide.Visible = false;
            // 
            // RemoveCount
            // 
            this.RemoveCount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.RemoveCount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RemoveCount.Image = global::CoffeeShop.Properties.Resources.remove;
            this.RemoveCount.Location = new System.Drawing.Point(319, 442);
            this.RemoveCount.Name = "RemoveCount";
            this.RemoveCount.Size = new System.Drawing.Size(32, 32);
            this.RemoveCount.TabIndex = 102;
            this.RemoveCount.TabStop = false;
            this.RemoveCount.Visible = false;
            this.RemoveCount.Click += new System.EventHandler(this.RemoveCount_Click);
            this.RemoveCount.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.RemoveCount_MouseDoubleClick);
            // 
            // Default_Page
            // 
            this.Default_Page.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Default_Page.Controls.Add(this.TotalAmount);
            this.Default_Page.Controls.Add(this.label2);
            this.Default_Page.Controls.Add(this.RemoveCount);
            this.Default_Page.Controls.Add(this.Cart_viewGuide);
            this.Default_Page.Controls.Add(this.SaveData);
            this.Default_Page.Controls.Add(this.Products_viewGuide);
            this.Default_Page.Controls.Add(this.Cart_view);
            this.Default_Page.Controls.Add(this.Products_view);
            this.Default_Page.Location = new System.Drawing.Point(190, 78);
            this.Default_Page.Name = "Default_Page";
            this.Default_Page.Size = new System.Drawing.Size(1005, 486);
            this.Default_Page.TabIndex = 104;
            // 
            // TotalAmount
            // 
            this.TotalAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TotalAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.TotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TotalAmount.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalAmount.Location = new System.Drawing.Point(140, 443);
            this.TotalAmount.Name = "TotalAmount";
            this.TotalAmount.ReadOnly = true;
            this.TotalAmount.Size = new System.Drawing.Size(167, 29);
            this.TotalAmount.TabIndex = 105;
            this.TotalAmount.Text = "0";
            this.TotalAmount.TextChanged += new System.EventHandler(this.TotalAmount_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label2.Font = new System.Drawing.Font("IRANSansXFaNum", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.label2.Location = new System.Drawing.Point(3, 443);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 28);
            this.label2.TabIndex = 103;
            this.label2.Text = "(تومان) جمع‌کل: ";
            // 
            // Username
            // 
            this.Username.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.Username.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Username.ForeColor = System.Drawing.Color.White;
            this.Username.Location = new System.Drawing.Point(409, 20);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(160, 28);
            this.Username.TabIndex = 105;
            this.Username.Text = "محمد مهدی جلالی";
            this.Username.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.pictureBox1.Image = global::CoffeeShop.Properties.Resources.edit;
            this.pictureBox1.Location = new System.Drawing.Point(371, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.TabIndex = 106;
            this.pictureBox1.TabStop = false;
            // 
            // Menu
            // 
            this.Menu.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Menu.AutoSize = false;
            this.Menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.Menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Menu.Dock = System.Windows.Forms.DockStyle.None;
            this.Menu.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Menu.GripMargin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Home,
            this.RecentOrders});
            this.Menu.Location = new System.Drawing.Point(190, 9);
            this.Menu.Name = "Menu";
            this.Menu.Padding = new System.Windows.Forms.Padding(0);
            this.Menu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.Menu.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Menu.Size = new System.Drawing.Size(1005, 50);
            this.Menu.TabIndex = 108;
            this.Menu.Text = "Menu";
            // 
            // Home
            // 
            this.Home.AutoSize = false;
            this.Home.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.Home.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(90, 50);
            this.Home.Text = "خانه";
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // RecentOrders
            // 
            this.RecentOrders.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(61)))));
            this.RecentOrders.Name = "RecentOrders";
            this.RecentOrders.Size = new System.Drawing.Size(125, 50);
            this.RecentOrders.Text = "سفارشات‌اخیر";
            this.RecentOrders.Click += new System.EventHandler(this.RecentOrders_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.pictureBox2.Image = global::CoffeeShop.Properties.Resources.calendar;
            this.pictureBox2.Location = new System.Drawing.Point(211, 18);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.TabIndex = 110;
            this.pictureBox2.TabStop = false;
            // 
            // Date
            // 
            this.Date.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(197)))), ((int)(((byte)(55)))));
            this.Date.Font = new System.Drawing.Font("IRANSansXFaNum DemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Date.ForeColor = System.Drawing.Color.White;
            this.Date.Location = new System.Drawing.Point(252, 20);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(82, 28);
            this.Date.TabIndex = 109;
            this.Date.Text = "----/--/--";
            this.Date.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Refresh
            // 
            this.Refresh.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Refresh.Image = global::CoffeeShop.Properties.Resources.RefreshServer;
            this.Refresh.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Refresh.Location = new System.Drawing.Point(19, 110);
            this.Refresh.Margin = new System.Windows.Forms.Padding(10);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(57, 63);
            this.Refresh.TabIndex = 111;
            this.Refresh.Tag = "";
            this.Refresh.Text = "بروزرسانی";
            this.Refresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // Exit
            // 
            this.Exit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit.Font = new System.Drawing.Font("IRANSansXFaNum", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Exit.Location = new System.Drawing.Point(19, 448);
            this.Exit.Margin = new System.Windows.Forms.Padding(10);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(57, 63);
            this.Exit.TabIndex = 112;
            this.Exit.Tag = "";
            this.Exit.Text = "خروج";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // P_Category
            // 
            this.P_Category.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.P_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.P_Category.Font = new System.Drawing.Font("IRANSansXFaNum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.P_Category.FormattingEnabled = true;
            this.P_Category.ItemHeight = 24;
            this.P_Category.Location = new System.Drawing.Point(1201, 110);
            this.P_Category.Name = "P_Category";
            this.P_Category.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.P_Category.Size = new System.Drawing.Size(172, 32);
            this.P_Category.TabIndex = 113;
            this.P_Category.SelectedIndexChanged += new System.EventHandler(this.P_Category_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.label1.Font = new System.Drawing.Font("IRANSansXFaNum", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(108)))), ((int)(((byte)(100)))));
            this.label1.Location = new System.Drawing.Point(1296, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 22);
            this.label1.TabIndex = 106;
            this.label1.Text = "دسته بندی";
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(233)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1385, 576);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.P_Category);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.Search_Panel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.Default_Page);
            this.MinimumSize = new System.Drawing.Size(1401, 615);
            this.Name = "Shop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shop";
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Products_view)).EndInit();
            this.Search_Panel.ResumeLayout(false);
            this.Search_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cart_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RemoveCount)).EndInit();
            this.Default_Page.ResumeLayout(false);
            this.Default_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView Products_view;
        private Panel Search_Panel;
        private Label Products_viewGuide;
        private DataGridView Cart_view;
        private Button SaveData;
        private Label Cart_viewGuide;
        private PictureBox RemoveCount;
        private Panel Default_Page;
        private Label label2;
        private TextBox TotalAmount;
        private Label Username;
        private PictureBox pictureBox1;
        private MenuStrip Menu;
        private ToolStripMenuItem Home;
        private ToolStripMenuItem RecentOrders;
        private PictureBox pictureBox2;
        private Label Date;
        private Button Refresh;
        private Button Search;
        private TextBox SearchInTable;
        private Button Exit;
        private ComboBox P_Category;
        private Label label1;
    }
}