﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Xml.Linq;
using Newtonsoft.Json;
using System.Web;

namespace CoffeeShop
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void TransferToSignupPage_Click(object sender, EventArgs e)
        {
            Signup signupForm = new Signup();
            this.Hide();
            signupForm.Show();
        }
        private void Login_Load(object sender, EventArgs e)
        {
            username.Padding = new Padding(0, 10, 0, 10);
        }
        private void LoginToAcount_Click(object sender, EventArgs e)
        {
            string[] ManagerUserPass = File.ReadAllLines(Settings.pathFileManegerAcount);
            if (username.Text == ManagerUserPass[0] && password.Text == ManagerUserPass[1])
            {
                string text = "مدیریت عزیز ورود شما با موفقیت انجام شد";
                MessageBox.Show(this, text, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                Management managementForm = new Management();
                this.Hide();
                managementForm.Show();
            } else {
                SendDataInDB(username.Text, password.Text);
            }


        }
        private async void SendDataInDB(string Username, string Password)
        {
            string url = "http://localhost:5000/Get_data";
            string[] ManagerUserPass = File.ReadAllLines(Settings.pathFileManegerAcount);

            HttpClient client = new HttpClient();
            var postData = new List<KeyValuePair<string, string>>();

            postData.Add(new KeyValuePair<string, string>("Username", username.Text));
            postData.Add(new KeyValuePair<string, string>("Password", password.Text));

            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(url, content).Result;
            string encodedString = await response.Content.ReadAsStringAsync();

            List<CustomersClass> customers = JsonConvert.DeserializeObject<List<CustomersClass>>(encodedString);
            if (customers.Count > 0) {
                if ((username.Text == customers[0].CustomerID.ToString() || username.Text == customers[0].PhoneNumber) && password.Text == customers[0].Password)
                {
                    MessageBox.Show(this, $"{customers[0].FirstName} عزیز ورود شما با موفقیت انجام شد", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));

                    // save user informatin logged in
                    userLoggedIn.CustomerID = customers[0].CustomerID;
                    userLoggedIn.FirstName = customers[0].FirstName;
                    userLoggedIn.LastName = customers[0].LastName;
                    userLoggedIn.Email = customers[0].Email;
                    userLoggedIn.PhoneNumber = customers[0].PhoneNumber;
                    userLoggedIn.Address = customers[0].Address;
                    userLoggedIn.City = customers[0].City;
                    userLoggedIn.State = customers[0].State;
                    userLoggedIn.PostalCode = customers[0].PostalCode;
                    userLoggedIn.Password = customers[0].Password;

                    Shop shopForm = new Shop();
                    this.Hide();
                    shopForm.Show();
                }
            } else {
                MessageBox.Show(this, $"اطلاعات وارده شده صحیح نیست، لطفا دوباره تلاش کنید", "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            }
        }
    }
}
