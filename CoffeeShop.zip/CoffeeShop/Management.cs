﻿using CoffeeShop.Widget;
using CoffeeShop.Widget.Categories;
using CoffeeShop.Widget.Orders;
using CoffeeShop.Widget.Products;
using Microsoft.VisualBasic.ApplicationServices;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CoffeeShop
{
    public partial class Management : Form
    {
        public Management()
        {
            InitializeComponent();
        }
        string TodayDate = GetPersianDate(DateTime.Now);

        DataTable TableOFProducts = new DataTable();
        DataTable TableOFCustomers = new DataTable();
        string Pages = string.Empty;


        UsersWidget usersWidgetForm = new UsersWidget();
        ProductsWidget productsWidgetForm = new ProductsWidget();
        OrdersWidget ordersWidgetForm = new OrdersWidget();
        CategoriesWidget CategoriesWidgetForm = new CategoriesWidget();
        private async void Management_Load(object sender, EventArgs e)
        {
            usersWidgetForm.Location = new Point(223, 72);
            this.Controls.Add(usersWidgetForm);
            // --
            productsWidgetForm.Location = new Point(223, 72);
            this.Controls.Add(productsWidgetForm);
            // --
            ordersWidgetForm.Location = new Point(223, 72);
            this.Controls.Add(ordersWidgetForm);
            // --
            CategoriesWidgetForm.Location = new Point(223, 72);
            this.Controls.Add(CategoriesWidgetForm);

            usersWidgetForm.Visible = productsWidgetForm.Visible = ordersWidgetForm.Visible = CategoriesWidgetForm.Visible = false;

            RefreshData();
            AddDataToDefalutTable();

            // add date: 
            Date.Text = TodayDate;
            Pages = "default";
        }
        private void Refresh_Click(object sender, EventArgs e)
        {
            UsersWidget NEWusersWidgetForm = new UsersWidget();
            ProductsWidget NEWproductsWidgetForm = new ProductsWidget();
            OrdersWidget NEWordersWidgetForm = new OrdersWidget();
            CategoriesWidget NEWCategoriesWidgetForm = new CategoriesWidget();

            if (Pages == "default") {
                // clear text of page:
                Date.Text = "----/--/--";
                FactorToDay.Text = AllInvoices.Text = TotalInvoices.Text = ProductsCounting.Text = UsersCounting.Text = "_";

                // remove clomun
                TableOFProducts.Rows.Clear();
                TableOFProducts.Columns.Clear();
                TableOFCustomers.Rows.Clear();
                TableOFCustomers.Columns.Clear();

                RefreshData();
                AddDataToDefalutTable();
            }
            else if (Pages == "users") {

                if (this.Controls.Contains(usersWidgetForm)) {
                    this.Controls.Remove(usersWidgetForm);
                }

                NEWusersWidgetForm.Location = new Point(223, 72);
                this.Controls.Add(NEWusersWidgetForm);
                NEWusersWidgetForm.BringToFront();
            } 
            else if (Pages == "products") {
                if (this.Controls.Contains(productsWidgetForm)) {
                    this.Controls.Remove(productsWidgetForm);
                }

                NEWproductsWidgetForm.Location = new Point(223, 72);
                this.Controls.Add(NEWproductsWidgetForm);
                NEWproductsWidgetForm.BringToFront();
            }
            else if (Pages == "orders")
            {
                if (this.Controls.Contains(ordersWidgetForm)) {
                    this.Controls.Remove(ordersWidgetForm);
                }

                NEWordersWidgetForm.Location = new Point(223, 72);
                this.Controls.Add(NEWordersWidgetForm);
                NEWordersWidgetForm.BringToFront();
            }
            else if (Pages == "categories")
            {
                if (this.Controls.Contains(CategoriesWidgetForm)) {
                    this.Controls.Remove(CategoriesWidgetForm);
                }

                NEWCategoriesWidgetForm.Location = new Point(223, 72);
                this.Controls.Add(NEWCategoriesWidgetForm);
                NEWCategoriesWidgetForm.BringToFront();
            }

            // add date: 
            Date.Text = TodayDate;
        }
        private async void RefreshData()
        {
            string Counting_Orders = "http://localhost:5000/Counting_Orders";
            string Counting_OrdersToday = "http://localhost:5000/Counting_OrdersToday";
            string Counting_Products = "http://localhost:5000/Counting_Products";
            string Counting_Customers = "http://localhost:5000/Counting_Customers";
            string Counting_TotalOfInvoices = "http://localhost:5000/TotalOfInvoices";

            HttpClient client = new HttpClient();

            // Post:
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("Date", TodayDate));
            HttpContent content = new FormUrlEncodedContent(postData);

            var response = client.PostAsync(Counting_OrdersToday, content).Result;
            string Count_OrdersToday = await response.Content.ReadAsStringAsync();

            // Get:
            string Count_Orders = await client.GetStringAsync(Counting_Orders);
            string Count_Products = await client.GetStringAsync(Counting_Products);
            string Count_Customers = await client.GetStringAsync(Counting_Customers);
            string TotalOfInvoices = await client.GetStringAsync(Counting_TotalOfInvoices);

            TotalOfInvoices = Opttion.SeparateByCommas(TotalOfInvoices);

            AllInvoices.Text = Count_Orders;
            FactorToDay.Text = Count_OrdersToday;
            ProductsCounting.Text = Count_Products;
            UsersCounting.Text = Count_Customers;
            TotalInvoices.Text = TotalOfInvoices;
        }
        private async void AddDataToDefalutTable()
        {
            string Counting_BestSaleProductBYNumber = "http://localhost:5000/BestSellingProductByCountSale";
            string Counting_BestCustomers = "http://localhost:5000/BestCustomers";

            TableOFProducts.Columns.Add("کد محصول", typeof(string));
            TableOFProducts.Columns.Add("نام محصول", typeof(string));
            TableOFProducts.Columns.Add("تعداد فروش محصول", typeof(string));

            TableOFCustomers.Columns.Add("کد مشتری", typeof(string));
            TableOFCustomers.Columns.Add("نام مشتری", typeof(string));
            TableOFCustomers.Columns.Add("جمع کل سفارشات", typeof(string));

            BestSellingProduct_view.DataSource = TableOFProducts;
            BestCustomers_view.DataSource = TableOFCustomers;

            HttpClient client = new HttpClient();

            // Get: 
            string BestSaleProductBYNumber = await client.GetStringAsync(Counting_BestSaleProductBYNumber);
            string BestCustomers = await client.GetStringAsync(Counting_BestCustomers);

            List<BestProductsClass> BestOFProducts = JsonConvert.DeserializeObject<List<BestProductsClass>>(BestSaleProductBYNumber);
            List<BestCustomersClass> BestOFCustomers = JsonConvert.DeserializeObject<List<BestCustomersClass>>(BestCustomers);

            for (int i = 0; i < BestOFProducts.Count; i++) {
                TableOFProducts.Rows.Add(BestOFProducts[i].ProductID, BestOFProducts[i].ProductName, BestOFProducts[i].Amount);
            }
            for (int i = 0; i < BestOFCustomers.Count; i++) {
                TableOFCustomers.Rows.Add(BestOFCustomers[i].ProductID, BestOFCustomers[i].ProductName, $"{BestOFCustomers[i].Amount} تومان");
            }
        }
        public static string GetPersianDate(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            int year = pc.GetYear(date);
            int month = pc.GetMonth(date);
            int day = pc.GetDayOfMonth(date);
            string persianDate = $"{year:0000}/{month:00}/{day:00}";

            return persianDate;
        }

        private void Home_Click(object sender, EventArgs e)
        {
            Pages = "default";
            Default_Page.Visible = true;
            Default_Page.BringToFront();
        }
        private void UsersManager_menu_Click(object sender, EventArgs e)
        {
            Default_Page.Visible = false;

            productsWidgetForm.Visible = ordersWidgetForm.Visible = CategoriesWidgetForm.Visible = false;
            usersWidgetForm.Visible = true;
            usersWidgetForm.BringToFront();

            Pages = "users";
        }
        private void ProductsManager_menu_Click(object sender, EventArgs e)
        {
            Default_Page.Visible = false;

            usersWidgetForm.Visible = ordersWidgetForm.Visible = CategoriesWidgetForm.Visible = false;
            productsWidgetForm.Visible = true;
            productsWidgetForm.BringToFront();

            Pages = "products";
        }
        private void OrdersManager_menu_Click(object sender, EventArgs e)
        {
            Default_Page.Visible = false;

            usersWidgetForm.Visible = productsWidgetForm.Visible = CategoriesWidgetForm.Visible = false;
            ordersWidgetForm.Visible = true;
            ordersWidgetForm.BringToFront();

            Pages = "orders";
        }
        private void CategoriesManager_menu_Click(object sender, EventArgs e)
        {
            Default_Page.Visible = false;

            usersWidgetForm.Visible = productsWidgetForm.Visible = ordersWidgetForm.Visible = false;
            CategoriesWidgetForm.Visible = true;
            CategoriesWidgetForm.BringToFront();

            Pages = "categories";
        }
        private void NewFactor_Click(object sender, EventArgs e)
        {
            AddOrderWidget addOrderWidgetForm = new AddOrderWidget();
            addOrderWidgetForm.Show();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F5)
            {
                // Call the method to handle the F5 key press
                HandleF5KeyPress();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void HandleF5KeyPress()
        {
            Refresh.PerformClick();
        }

        private void BestSellingProduct_view_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            BestSellingProduct_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
            BestCustomers_view.Rows[e.RowIndex].DefaultCellStyle.BackColor = (e.RowIndex % 2 == 0) ? Color.FromArgb(255, 255, 255) : Color.FromArgb(200, 219, 228);
        }
        private void BestSellingProduct_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(BestSellingProduct_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
        private void BestCustomers_view_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(BestCustomers_view.RowHeadersDefaultCellStyle.ForeColor))
            {
                string rowIndex = (e.RowIndex + 1).ToString();
                int width = TextRenderer.MeasureText(rowIndex, e.InheritedRowStyle.Font).Width;
                int x = e.RowBounds.Right - width - 14;
                int y = e.RowBounds.Location.Y + 4;
                e.Graphics.DrawString(rowIndex, e.InheritedRowStyle.Font, b, x, y);
            }
        }
        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(this, "آیا مایل به خروج حساب مدیریت هستید؟", "اطلاعیه", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading));
            if (dialogResult == DialogResult.Yes)
            {
                Login loginForm = new Login();
                this.Hide();
                loginForm.ShowDialog();
            }
        }
    }
}
