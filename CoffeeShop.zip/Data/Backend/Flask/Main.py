from flask import Flask, request
from flask_cors import CORS
import json
import sqlite3

app = Flask(__name__)
CORS(app)


@app.route('/Add_user', methods=['POST'])
def Add_user():
    CustomerID = request.form['CustomerID']
    FirstName = request.form['FirstName']
    LastName = request.form['LastName']
    Email = request.form['Email']
    PhoneNumber = request.form['PhoneNumber']
    Address = request.form['Address']
    City = request.form['City']
    State = request.form['State']
    PostalCode = request.form['PostalCode']
    Password = request.form['Password']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute("INSERT INTO Customers (CustomerID, FirstName,LastName,Email,PhoneNumber,Address,City,State,PostalCode, Password) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (CustomerID, FirstName, LastName, Email, PhoneNumber, Address, City, State, PostalCode, Password))

    conn.commit()
    conn.close()
    return 'customer Added successfully!'


@app.route('/Get_data', methods=['POST'])
def Get_data():
    Username = request.form['Username']
    Password = request.form['Password']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT * FROM Customers WHERE (CustomerID = '{Username}' OR PhoneNumber = '{Username}' ) AND Password = '{Password}'")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'CustomerID': row[0],
            'FirstName': row[1],
            'LastName': row[2],
            'Email': row[3],
            'PhoneNumber': row[4],
            'Address': row[5],
            'City': row[6],
            'State': row[7],
            'PostalCode': row[8],
            'Password': row[9],
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/Counting_OrdersToday', methods=['POST'])
def Counting_OrdersToday():
    Date = request.form['Date']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT count(*) As CountToDay FROM Orders WHERE OrderDate = '{Date}' AND Status = 'تایید'")
    count = Connect.fetchall()

    return str(count[0][0])


@app.route('/Counting_Orders', methods=['GET'])
def Counting_Orders():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT count(*) as Count FROM Orders WHERE Status = 'تایید'")
    count = Connect.fetchall()

    return str(count[0][0])


@app.route('/Counting_Products', methods=['GET'])
def Counting_Products():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT count(*) AS Count FROM Products")
    count = Connect.fetchall()

    return str(count[0][0])


@app.route('/Counting_Customers', methods=['GET'])
def Counting_Customers():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT count(*) as Count FROM Customers")
    count = Connect.fetchall()

    return str(count[0][0])


@app.route('/TotalOfInvoices', methods=['GET'])
def TotalOfInvoices():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT sum(TotalAmount) As TotalOfInvoices FROM Orders WHERE Status = 'تایید'")
    count = Connect.fetchall()

    return str(count[0][0])


@app.route('/BestSellingProductByCountSale', methods=['GET'])
def BestSellingProductByCountSale():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT Products.ProductID, Products.ProductName, sum(OrderDetails.Quantity) AS CountSaleBYnumber FROM Products INNER JOIN OrderDetails ON Products.ProductID = OrderDetails.ProductID GROUP BY Products.ProductID ORDER BY CountSaleBYnumber DESC LIMIT 3")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'ProductID': row[0],
            'ProductName': row[1],
            'Amount': row[2],
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/BestCustomers', methods=['GET'])
def BestCustomers():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT Customers.CustomerID, (Customers.FirstName ||' '|| Customers.LastName) AS FullName, sum(Orders.TotalAmount) AS Amount FROM Customers INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerOrder GROUP BY Customers.CustomerID ORDER BY Amount DESC LIMIT 3")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'ProductID': row[0],
            'ProductName': row[1],
            'Amount': row[2],
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/GetCustomers', methods=['GET'])
def GetCustomers():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT * FROM Customers")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'CustomerID': row[0],
            'FirstName': row[1],
            'LastName': row[2],
            'Email': row[3],
            'PhoneNumber': row[4],
            'Address': row[5],
            'City': row[6],
            'State': row[7],
            'PostalCode': row[8],
            'Password': row[9]
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data

@app.route('/UpdateCustomers', methods=['PUT'])
def UpdateCustomers():
    CustomerID = request.form['CustomerID']
    FirstName = request.form['FirstName']
    LastName = request.form['LastName']
    Email = request.form['Email']
    PhoneNumber = request.form['PhoneNumber']
    Address = request.form['Address']
    City = request.form['City']
    State = request.form['State']
    PostalCode = request.form['PostalCode']
    Password = request.form['Password']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"UPDATE Customers SET CustomerID = {CustomerID}, FirstName = '{FirstName}', LastName = '{LastName}', Email = '{Email}', PhoneNumber = '{PhoneNumber}', Address = '{Address}', City = '{City}', State = '{State}', PostalCode = '{PostalCode}', Password = '{Password}' WHERE CustomerID = {CustomerID}")

    conn.commit()
    conn.close()
    return 'customer Update successfully!'


@app.route('/DeleteCustomers/<CustomerID>', methods=['DELETE'])
def DeleteCustomers(CustomerID):
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"DELETE FROM Customers WHERE CustomerID = {CustomerID}")

    conn.commit()
    conn.close()
    return 'customer Deleted successfully!'


@app.route('/GetProducts', methods=['GET'])
def GetProducts():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT Products.ProductID, Products.ProductName, Products.Description, Products.Price, Products.Image, Products.CategoryID, Categories.CategoryName FROM Products INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'ProductID': row[0],
            'ProductName': row[1],
            'Description': row[2],
            'Price': row[3],
            'Image': row[4],
            'CategoryID': row[5],
            'CategoryName': row[6]
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/Search', methods=['POST'])
def Search():
    table = request.form['table']
    text = request.form['textSearch']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()

    if table == "products":
        Connect.execute(
            f"SELECT Products.ProductID, Products.ProductName, Products.Description, Products.Price, Products.Image, Products.CategoryID, Categories.CategoryName FROM Products INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID WHERE ProductID LIKE '{text}%' OR ProductName LIKE '%{text}%' OR CategoryName LIKE '%{text}%'")

    if table == "users":
        Connect.execute(
            f"SELECT * FROM Customers WHERE FirstName LIKE '%{text}%' OR LastName LIKE '%{text}%' OR Email LIKE '{text}%' OR PhoneNumber LIKE '{text}%' OR CustomerID LIKE '{text}'")

    if table == "orders":
        Status = request.form['Status']
        Connect.execute(
            f"SELECT OrderID, Customers.FirstName || ' ' || Customers.LastName AS FullName, OrderDate, TotalAmount, PaymentType, Status FROM Orders INNER JOIN Customers ON Orders.CustomerOrder = Customers.CustomerID WHERE (FullName LIKE '%{text}%' OR orderID LIKE '{text}' OR OrderDate LIKE '{text}%') AND Status = '{Status}'")

    if table == "categories":
        Connect.execute(
            f"SELECT * FROM Categories WHERE CategoryID LIKE '{text}%' OR CategoryName LIKE '%{text}%'")

    rows = Connect.fetchall()

    data = []

    if table == "products":
        for row in rows:
            data.append({
                'ProductID': row[0],
                'ProductName': row[1],
                'Description': row[2],
                'Price': row[3],
                'Image': row[4],
                'CategoryID': row[5],
                'CategoryName': row[6]
            })

    if table == "users":
        for row in rows:
            data.append({
                'CustomerID': row[0],
                'FirstName': row[1],
                'LastName': row[2],
                'Email': row[3],
                'PhoneNumber': row[4],
                'Address': row[5],
                'City': row[6],
                'State': row[7],
                'PostalCode': row[8],
                'Password': row[9]
            })
    if table == "orders":
        for row in rows:
            data.append({
                'OrderID': row[0],
                'FullName': row[1],
                'OrderDate': row[2],
                'TotalAmount': row[3],
                'PaymentType': row[4],
                'Status': row[5]
            })

    if table == "categories":
        for row in rows:
            data.append({
                'CategoryID': row[0],
                'CategoryName': row[1],
                'CategoryDescription': row[2],
                'CategoryImage': row[3]
            })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/UpdateProducts', methods=['PUT'])
def UpdateProducts():
    ProductID = request.form['ProductID']
    ProductName = request.form['ProductName']
    Description = request.form['Description']
    Price = request.form['Price']
    Image = request.form['Image']
    CategoryID = request.form['CategoryID']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"UPDATE Products SET ProductName = '{ProductName}', Description = '{Description}', Price = '{Price}', Image = '{Image}', CategoryID = '{CategoryID}' WHERE ProductID = {ProductID}")

    conn.commit()
    conn.close()
    return 'Product Update successfully!'


@app.route('/DeleteProducts/<ProductID>', methods=['DELETE'])
def DeleteProducts(ProductID):
    # ProductID = request.form['ProductID']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"DELETE FROM Products WHERE ProductID = {ProductID}")

    conn.commit()
    conn.close()
    return 'product Deleted successfully!'


@app.route('/Add_Product', methods=['POST'])
def Add_Product():
    ProductID = request.form['ProductID']
    ProductName = request.form['ProductName']
    Description = request.form['Description']
    Price = request.form['Price']
    Image = request.form['Image']
    CategoryID = request.form['CategoryID']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"INSERT INTO Products(ProductID, ProductName, Description, Price, Image, CategoryID) VALUES ({ProductID}, '{ProductName}', '{Description}', '{Price}', '{Image}', {CategoryID})")

    conn.commit()
    conn.close()
    return 'product Deleted successfully!'


@app.route('/GetOrders', methods=['POST'])
def GetOrders():
    Status = request.form['Status']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT OrderID, Customers.CustomerID, Customers.FirstName || ' ' || Customers.LastName AS FullName, OrderDate, TotalAmount, PaymentType, Status FROM Orders INNER JOIN Customers ON Orders.CustomerOrder = Customers.CustomerID WHERE Status = '{Status}'")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'OrderID': row[0],
            'CustomerID': row[1],
            'FullName': row[2],
            'OrderDate': row[3],
            'TotalAmount': row[4],
            'PaymentType': row[5],
            'Status': row[6]
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


# set status order: true / false
@app.route('/SetStatusOrders', methods=['PUT'])
def SetStatusOrders():
    OrderID = request.form['OrderID']
    Status = request.form['Status']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"UPDATE Orders SET Status = '{Status}' WHERE Orders.OrderID = '{OrderID}'")
    Connect.execute(
        f"UPDATE OrderDetails SET ItemStatus = '{Status}' WHERE OrderID = '{OrderID}'")

    conn.commit()
    conn.close()
    return 'Product Update successfully!'


@app.route('/UpdateOrders', methods=['PUT', 'GET'])
def UpdateOrders():
    json_str = request.form['Cart']
    json_object = json.loads(json_str)

    OrderID = request.form['OrderID']
    CustomerID = request.form['CustomerID']
    TotalAmount = request.form['TotalAmount']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()

    # ثبت تغییرات کلی فاکتور مثل: جمع‌کل، کد‌مشتری، کدفاکتور
    Connect.execute(
        f"UPDATE Orders SET TotalAmount = {TotalAmount}, CustomerOrder = {CustomerID} WHERE OrderID = {OrderID}")

    # حذف همه رکورد های جدول OrderDetails مربوط به شماره فاکتور موردنظر
    Connect.execute(
        f"DELETE FROM OrderDetails WHERE OrderDetails.OrderID = {OrderID}")

    for product in json_object:
        ProductID = product["ID"]
        Quantity = product["Count"]
        ItemPrice = product["Price"]
        ItemTotal = product["TotalAmount"]

        # ایجاد OrderDetails جدید براساس کالاهای جدید!
        Connect.execute(
            f"INSERT INTO OrderDetails (OrderID, ProductID, Quantity, ItemPrice, ItemDiscount, ItemTotal, ItemStatus) VALUES ({OrderID}, {ProductID}, {Quantity}, '{ItemPrice}', '0', '{ItemTotal}', 'تایید')")

    conn.commit()
    conn.close()
    return ".سفارش با موفقیت ویرایش شد"


@app.route('/GetOrderDetails', methods=['POST'])
def GetOrderDetails():
    OrderID = request.form['OrderID']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT Products.ProductID , Products.ProductName, OrderDetails.Quantity, OrderDetails.ItemDiscount, OrderDetails.ItemPrice, OrderDetails.ItemTotal, OrderDetails.ItemNotes FROM OrderDetails INNER JOIN Products ON OrderDetails.ProductID = Products.ProductID WHERE OrderDetails.OrderID = {OrderID}")

    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'ProductID': row[0],
            'ProductName': row[1],
            'Quantity': row[2],
            'ItemDiscount': row[3],
            'ItemPrice': row[4],
            'ItemTotal': row[5],
            'ItemNotes': row[6]
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data

# AddFactor process:


@app.route('/AddOrder', methods=['POST'])
def AddOrder():
    json_str = request.form['Cart']
    json_object = json.loads(json_str)

    OrderID = request.form['OrderID']
    CustomerOrder = request.form['CustomerOrder']
    OrderDate = request.form['OrderDate']
    TotalAmount = request.form['TotalAmount']
    PaymentType = 'درگاه‌ پرداخت اینترنتی'
    Status = 'بررسی'

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()

    Connect.execute(
        f"INSERT INTO Orders (OrderID, CustomerOrder, OrderDate, TotalAmount, PaymentType, Status) VALUES ({OrderID}, {CustomerOrder}, '{OrderDate}', '{TotalAmount}', '{PaymentType}', '{Status}')")

    for product in json_object:
        ProductID = product["ID"]
        Quantity = product["Count"]
        ItemPrice = product["Price"]
        ItemTotal = product["TotalAmount"]

        Connect.execute(
            f"INSERT INTO OrderDetails (OrderID, ProductID, Quantity, ItemPrice, ItemDiscount, ItemTotal, ItemStatus) VALUES ({OrderID}, {ProductID}, {Quantity}, '{ItemPrice}', '0', '{ItemTotal}', '{Status}')")

    conn.commit()
    conn.close()
    return 'Order Added successfully!'


@app.route('/ShowCustomerOrders', methods=['POST'])
def ShowCustomerOrders():
    CustomerID = request.form['CustomerID']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"SELECT OrderID, Customers.FirstName || ' ' || Customers.LastName AS FullName, OrderDate, TotalAmount, PaymentType, Status FROM Orders INNER JOIN Customers ON Orders.CustomerOrder = Customers.CustomerID WHERE Orders.CustomerOrder = {CustomerID}")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'OrderID': row[0],
            'FullName': row[1],
            'OrderDate': row[2],
            'TotalAmount': row[3],
            'PaymentType': row[4],
            'Status': row[5]
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/GetCategories', methods=['GET'])
def GetCategories():
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"SELECT * FROM Categories")
    rows = Connect.fetchall()

    data = []
    for row in rows:
        data.append({
            'CategoryID': row[0],
            'CategoryName': row[1],
            'CategoryDescription': row[2],
            'CategoryImage': row[3]
        })

    conn.commit()
    conn.close()

    data = json.dumps(data)
    return data


@app.route('/AddCategories', methods=['POST'])
def AddCategories():
    CategoryID = request.form['CategoryID']
    CategoryName = request.form['CategoryName']
    CategoryDescription = request.form['CategoryDescription']
    CategoryImage = request.form['CategoryImage']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()

    Connect.execute(
        f"INSERT INTO Categories (CategoryID, CategoryName, CategoryDescription, CategoryImage) VALUES ({CategoryID}, '{CategoryName}', '{CategoryDescription}', '{CategoryImage}')")

    conn.commit()
    conn.close()
    return 'Categories Added successfully!'


@app.route('/UpdateCategories', methods=['PUT'])
def UpdateCategories():
    CategoryID = request.form['CategoryID']
    CategoryName = request.form['CategoryName']
    CategoryDescription = request.form['CategoryDescription']
    CategoryImage = request.form['CategoryImage']

    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(
        f"UPDATE Categories SET CategoryID = {CategoryID}, CategoryName = '{CategoryName}', CategoryDescription = '{CategoryDescription}', CategoryImage = '{CategoryImage}' WHERE CategoryID = {CategoryID}")

    conn.commit()
    conn.close()
    return 'Product Update successfully!'


@app.route('/DeleteCategories/<CategoryID>', methods=['DELETE'])
def DeleteCategories(CategoryID):
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()
    Connect.execute(f"DELETE FROM Categories WHERE CategoryID = {CategoryID}")

    conn.commit()
    conn.close()
    return 'categories Deleted successfully!'


@app.route('/DeleteOrders/<OrderID>', methods=['DELETE'])
def DeleteOrders(OrderID):
    conn = sqlite3.connect('DataBase.db')
    Connect = conn.cursor()

    Connect = conn.execute(
        f"DELETE FROM OrderDetails WHERE OrderDetails.OrderID = {OrderID}")
    Connect = conn.execute(
        f"DELETE FROM Orders WHERE Orders.OrderID = {OrderID}")

    conn.commit()
    conn.close()
    return 'order Deleted successfully!'


if __name__ == '__main__':
    app.run(debug=True)
